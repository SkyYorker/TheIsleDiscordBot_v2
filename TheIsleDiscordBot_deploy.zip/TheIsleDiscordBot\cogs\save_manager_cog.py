"""
Discord команды для управления файлами сохранений The Isle
"""

import discord
from discord.ext import commands
# Option будет доступен после патча в main.py
try:
    from discord.app_commands import Option
except ImportError:
    from discord.ext.commands import Option
from utils.save_file_manager import save_integration, DinosaurStats, DinosaurData
from database.crud import PlayerDinoCRUD, DonationCRUD
import logging

logger = logging.getLogger(__name__)


class SaveManagerCog(commands.Cog):
    """Команды управления сохранениями"""
    
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(
        name="heal",
        description="Лечение динозавра"
    )
    async def heal_dinosaur(
        self, 
        ctx: discord.ApplicationContext,
        full_heal: Option(
            bool, 
            description="Полное лечение (дороже)", 
            default=False
        )
    ):
        """Лечение динозавра игрока"""
        await ctx.defer()
        
        try:
            # Проверяем, есть ли у игрока достаточно TC
            tk_balance = await DonationCRUD.get_tk(ctx.author.id)
            
            heal_cost = 100 if full_heal else 50  # Стоимость лечения
            
            if tk_balance < heal_cost:
                embed = discord.Embed(
                    title="❌ Недостаточно TC",
                    description=f"Для лечения нужно {heal_cost} TC, у вас {tk_balance} TC",
                    color=discord.Color.red()
                )
                await ctx.followup.send(embed=embed, ephemeral=True)
                return
            
            # Выполняем лечение
            success, message = await save_integration.handle_heal_request(ctx.author.id, full_heal)
            
            if success:
                # Списываем TC
                await DonationCRUD.update_tk(ctx.author.id, -heal_cost)
                
                embed = discord.Embed(
                    title="🩹 Лечение выполнено",
                    description=f"{message}\nСписано {heal_cost} TC",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка лечения",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in heal command: {e}")
            embed = discord.Embed(
                title="❌ Системная ошибка",
                description="Произошла ошибка при обработке команды",
                color=discord.Color.red()
            )
            await ctx.followup.send(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="boost_growth",
        description="Увеличение роста динозавра"
    )
    async def boost_growth(
        self,
        ctx: discord.ApplicationContext,
        amount: Option(
            float,
            description="Количество роста (0.1 = 10%)",
            min_value=0.01,
            max_value=0.5,
            default=0.1
        )
    ):
        """Увеличение роста динозавра"""
        await ctx.defer()
        
        try:
            # Проверяем баланс TC
            tk_balance = await DonationCRUD.get_tk(ctx.author.id)
            growth_cost = int(amount * 1000)  # 100 TC за 10% роста
            
            if tk_balance < growth_cost:
                embed = discord.Embed(
                    title="❌ Недостаточно TC",
                    description=f"Для увеличения роста на {amount*100:.1f}% нужно {growth_cost} TC, у вас {tk_balance} TC",
                    color=discord.Color.red()
                )
                await ctx.followup.send(embed=embed, ephemeral=True)
                return
            
            # Выполняем увеличение роста
            success, message = await save_integration.handle_growth_boost(ctx.author.id, amount)
            
            if success:
                # Списываем TC
                await DonationCRUD.update_tk(ctx.author.id, -growth_cost)
                
                embed = discord.Embed(
                    title="📈 Рост увеличен",
                    description=f"{message}\nСписано {growth_cost} TC",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in boost_growth command: {e}")
            embed = discord.Embed(
                title="❌ Системная ошибка",
                description="Произошла ошибка при обработке команды",
                color=discord.Color.red()
            )
            await ctx.followup.send(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="create_dino",
        description="Создать нового динозавра"
    )
    async def create_dinosaur(
        self,
        ctx: discord.ApplicationContext,
        species: Option(
            str,
            description="Вид динозавра",
            choices=[
                "BP_Triceratops_C",
                "BP_Carnotaurus_C", 
                "BP_Dilophosaurus_C",
                "BP_Stegosaurus_C",
                "BP_Ceratosaurus_C",
                "BP_Maiasaura_C"
            ]
        ),
        health: Option(
            float,
            description="Здоровье (0.0-1.0)",
            min_value=0.0,
            max_value=1.0,
            default=1.0
        ),
        growth: Option(
            float,
            description="Рост (0.0-1.0)",
            min_value=0.0,
            max_value=1.0,
            default=0.1
        )
    ):
        """Создание нового динозавра"""
        await ctx.defer()
        
        try:
            # Проверяем баланс TC (создание динозавра дорого)
            tk_balance = await DonationCRUD.get_tk(ctx.author.id)
            creation_cost = 500  # Стоимость создания динозавра
            
            if tk_balance < creation_cost:
                embed = discord.Embed(
                    title="❌ Недостаточно TC",
                    description=f"Для создания динозавра нужно {creation_cost} TC, у вас {tk_balance} TC",
                    color=discord.Color.red()
                )
                await ctx.followup.send(embed=embed, ephemeral=True)
                return
            
            # Создаем статы динозавра
            stats = DinosaurStats(
                health=health,
                hunger=1.0,
                thirst=1.0,
                growth=growth,
                stamina=1.0
            )
            
            # Выполняем создание
            success, message = await save_integration.handle_dino_creation(ctx.author.id, species, stats)
            
            if success:
                # Списываем TC
                await DonationCRUD.update_tk(ctx.author.id, -creation_cost)
                
                # Получаем название динозавра для отображения
                species_names = {
                    "BP_Triceratops_C": "Трицератопс",
                    "BP_Carnotaurus_C": "Карнотавр",
                    "BP_Dilophosaurus_C": "Дилофозавр",
                    "BP_Stegosaurus_C": "Стегозавр",
                    "BP_Ceratosaurus_C": "Цератозавр",
                    "BP_Maiasaura_C": "Майязавр"
                }
                
                species_name = species_names.get(species, species)
                
                embed = discord.Embed(
                    title="🦕 Динозавр создан",
                    description=(
                        f"Создан {species_name}\n"
                        f"Здоровье: {health*100:.1f}%\n"
                        f"Рост: {growth*100:.1f}%\n"
                        f"Списано {creation_cost} TC"
                    ),
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка создания",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in create_dino command: {e}")
            embed = discord.Embed(
                title="❌ Системная ошибка",
                description="Произошла ошибка при создании динозавра",
                color=discord.Color.red()
            )
            await ctx.followup.send(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="dino_stats",
        description="Посмотреть статы текущего динозавра"
    )
    async def view_dino_stats(self, ctx: discord.ApplicationContext):
        """Просмотр статов динозавра"""
        await ctx.defer()
        
        try:
            # Получаем Steam ID игрока
            player = await PlayerDinoCRUD.get_player_info(ctx.author.id)
            if not player or not player.get("player", {}).get("steam_id"):
                embed = discord.Embed(
                    title="❌ Игрок не найден",
                    description="Привяжите Steam аккаунт для использования этой функции",
                    color=discord.Color.red()
                )
                await ctx.followup.send(embed=embed, ephemeral=True)
                return
            
            steam_id = player["player"]["steam_id"]
            
            # Читаем данные сохранения
            from utils.save_file_manager import save_manager
            save_data = save_manager.read_player_save(steam_id)
            
            if not save_data:
                embed = discord.Embed(
                    title="❌ Файл сохранения не найден",
                    description="Сначала зайдите на сервер и создайте персонажа",
                    color=discord.Color.red()
                )
                await ctx.followup.send(embed=embed, ephemeral=True)
                return
            
            # Отображаем статы
            stats = save_data["stats"]
            dino_info = save_data["dinosaur"]
            
            # Получаем название вида
            species_names = {
                "BP_Triceratops_C": "🦕 Трицератопс",
                "BP_Carnotaurus_C": "🦖 Карнотавр",
                "BP_Dilophosaurus_C": "🦕 Дилофозавр",
                "BP_Stegosaurus_C": "🦕 Стегозавр",
                "BP_Ceratosaurus_C": "🦖 Цератозавр",
                "BP_Maiasaura_C": "🦕 Майязавр"
            }
            
            species_name = species_names.get(dino_info["species"], f"🦕 {dino_info['species']}")
            
            embed = discord.Embed(
                title="📊 Статы динозавра",
                description=f"**{species_name}**",
                color=discord.Color.blue()
            )
            
            # Добавляем полосы прогресса для статов
            for stat_name, value in stats.items():
                if stat_name in ["health", "hunger", "thirst", "growth", "stamina"]:
                    percentage = value * 100
                    bar_length = 10
                    filled_length = int(bar_length * value)
                    bar = "█" * filled_length + "░" * (bar_length - filled_length)
                    
                    stat_names = {
                        "health": "❤️ Здоровье",
                        "hunger": "🍖 Голод", 
                        "thirst": "💧 Жажда",
                        "growth": "📈 Рост",
                        "stamina": "⚡ Выносливость"
                    }
                    
                    stat_display = stat_names.get(stat_name, stat_name.title())
                    embed.add_field(
                        name=stat_display,
                        value=f"`{bar}` {percentage:.1f}%",
                        inline=False
                    )
            
            embed.set_footer(text=f"Steam ID: {steam_id}")
            
            await ctx.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in dino_stats command: {e}")
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось получить статы динозавра",
                color=discord.Color.red()
            )
            await ctx.followup.send(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(SaveManagerCog(bot))