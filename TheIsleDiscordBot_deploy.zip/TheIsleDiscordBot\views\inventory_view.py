import json
import logging
from typing import List, Dict, Any, Optional

import discord
from discord.ui import View, Select, Button, Modal
try:
    from discord.ui import InputText
except ImportError:
    from discord.ui import TextInput as InputText

from database.crud import InventoryCRUD, ItemCRUD, DonationCRUD
from utils.scripts import give_nutrients, give_food, buy_dino, check_max_limit_dino, get_all_dinos, restore_dino_script, del_dino
from data.dinosaurus import find_name_by_class, DINOSAURS, CATEGORY_EMOJIS

logger = logging.getLogger(__name__)


class ItemUseModal(Modal):
    def __init__(self, item_name: str, inventory_id: int):
        custom_id = f"item_use_modal_{inventory_id}"
        super().__init__(title=f"Использование: {item_name}", custom_id=custom_id)
        self.inventory_id = inventory_id
        
        self.confirm_text = InputText(
            label="Введите 'ПОДТВЕРДИТЬ' для использования предмета",
            placeholder="ПОДТВЕРДИТЬ",
            required=True,
            max_length=20
        )
        self.add_item(self.confirm_text)

    async def callback(self, interaction: discord.Interaction):
        # Получаем значение с fallback на self.children
        confirm_value = self.confirm_text.value
        if not confirm_value and self.children:
            confirm_value = self.children[0].value
            logger.debug(f"[ItemUseModal] Использован fallback через self.children[0].value: {confirm_value}")
        
        # Проверка на None/пустое значение
        if not confirm_value or (isinstance(confirm_value, str) and confirm_value.strip() == ""):
            logger.warning(f"[ItemUseModal] Пустое значение подтверждения для пользователя {interaction.user.id}. confirm_value={confirm_value}")
            await interaction.response.send_message(
                "❌ Пожалуйста, введите 'ПОДТВЕРДИТЬ' для использования предмета.", 
                ephemeral=True
            )
            return
        
        logger.debug(f"[ItemUseModal] Получено значение подтверждения: {confirm_value} (тип: {type(confirm_value)})")
        
        if confirm_value.upper().strip() != "ПОДТВЕРДИТЬ":
            logger.warning(f"[ItemUseModal] Неверное подтверждение: {confirm_value}")
            await interaction.response.send_message(
                "❌ Неверное подтверждение. Введите 'ПОДТВЕРДИТЬ'", 
                ephemeral=True
            )
            return
        
        success = await InventoryCRUD.use_item(self.inventory_id, interaction.user.id)
        if success:
            embed = discord.Embed(
                title="✅ Предмет использован",
                description="Предмет успешно использован в игре!",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось использовать предмет. Возможно, он уже использован.",
                color=discord.Color.red()
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)


def filter_dinos_by_category(dinos: List[Dict[str, Any]], category: str) -> List[Dict[str, Any]]:
    return [
        d for d in dinos
        if DINOSAURS.get(find_name_by_class(d["dino_class"]), {}).get("category") == category
    ]


class InventoryView(View):
    def __init__(self, main_menu_embed: discord.Embed, main_menu_view):
        super().__init__(timeout=None)
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        self.selected_item: Optional[Dict[str, Any]] = None
        self.inventory_items: List[Dict[str, Any]] = []
        self.dinosaurs: List[Dict[str, Any]] = []
        self.active_tab: str = "items"  # "items" или "dinosaurs"
        self.selected_dino: Optional[str] = None
        self.selected_category: Optional[str] = None
        self.dinos_in_cat: List[Dict[str, Any]] = []
        self.dino_state: str = "category"  # "category", "dino", "empty", "empty_category"

    async def load_data(self, discord_id: int):
        """Загружает данные инвентаря и динозавров"""
        self.inventory_items = await InventoryCRUD.get_player_inventory(discord_id, unused_only=True)
        # Фильтруем только не-динозавров для вкладки предметов
        self.inventory_items = [item for item in self.inventory_items if item.get('item_type') != 'dinosaur']
        
        # Загружаем динозавров из dino_storage
        dinosaurs_result = await get_all_dinos(discord_id)
        if isinstance(dinosaurs_result, tuple):
            self.dinosaurs = []
        else:
            self.dinosaurs = dinosaurs_result
        
        await self.update_view()
    
    async def load_inventory(self, discord_id: int):
        """Алиас для обратной совместимости"""
        await self.load_data(discord_id)

    async def update_view(self):
        """Обновляет интерфейс в зависимости от активной вкладки"""
        self.clear_items()
        
        if self.active_tab == "items":
            await self._build_items_view()
        else:
            await self._build_dinosaurs_view()

    async def _build_items_view(self):
        """Строит интерфейс для вкладки предметов"""
        # Показываем select menu только если есть предметы
        if self.inventory_items:
            # Создаем select menu для предметов
            options = []
            for item in self.inventory_items[:25]:  # Discord limit
                label = f"{item['item_name']} (x{item['quantity']})"
                description = item['item_description'][:100] if item['item_description'] else ""
                options.append(discord.SelectOption(
                    label=label,
                    value=str(item['inventory_id']),
                    description=description
                ))
            
            if options:
                self.item_select = Select(
                    placeholder="📋 Выберите предмет из инвентаря",
                    options=options,
                    custom_id="select_item",
                    row=0
                )
                self.add_item(self.item_select)
        
        # Кнопки управления
        self.add_item(Button(
            label="Использовать предмет",
            style=discord.ButtonStyle.green,
            custom_id="use_item",
            disabled=not self.inventory_items,
            row=1
        ))
        
        self.add_item(Button(
            label="Удалить предмет",
            style=discord.ButtonStyle.red,
            custom_id="remove_item",
            disabled=not self.inventory_items,
            row=1
        ))
        
        # Кнопки вкладок и навигации
        # Показываем кнопку "Динозавры" только если есть динозавры
        if len(self.dinosaurs) > 0:
            self.add_item(Button(
                label="🦖 Динозавры",
                style=discord.ButtonStyle.blurple,
                custom_id="tab_dinosaurs",
                row=2
            ))
        
        self.add_item(Button(
            label="Обновить",
            style=discord.ButtonStyle.blurple,
            custom_id="refresh_inventory",
            row=2
        ))
        
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.grey,
            custom_id="back_to_menu",
            row=2
        ))

    async def _build_dinosaurs_view(self):
        """Строит интерфейс для вкладки динозавров"""
        if not self.dinosaurs:
            self.dino_state = "empty"
            self.add_item(Button(
                label="Нет динозавров",
                style=discord.ButtonStyle.grey,
                disabled=True,
                row=0
            ))
        elif self.dino_state == "category":
            # Показываем категории
            category_counts = {category: 0 for category in CATEGORY_EMOJIS.keys()}
            for d in self.dinosaurs:
                category = DINOSAURS.get(find_name_by_class(d["dino_class"]), {}).get("category")
                if category in category_counts:
                    category_counts[category] += 1

            for label, emoji in CATEGORY_EMOJIS.items():
                count = category_counts.get(label, 0)
                disabled = count == 0
                self.add_item(Button(
                    label=f"{label} ({count} шт.)",
                    style=discord.ButtonStyle.blurple,
                    emoji=emoji,
                    custom_id=f"category_{label}",
                    disabled=disabled,
                    row=0
                ))
        elif self.dino_state == "dino":
            # Показываем список динозавров в выбранной категории
            options = []
            saved_dino_class = ""
            for dino in self.dinosaurs[:25]:
                dino_name = find_name_by_class(dino["dino_class"])
                if DINOSAURS[dino_name]["category"] != self.selected_category:
                    continue
                id = dino["id"]
                growth = dino["growth"]
                hunger = dino["hunger"]
                thirst = dino["thirst"]
                health = dino["health"]
                if str(id) == self.selected_dino:
                    saved_dino_class = dino_name
                label = f"({id}) {dino_name} (Рост {growth}%, Голод: {hunger}%, Жажда: {thirst}%, HP: {health}%)"
                options.append(discord.SelectOption(label=label, value=str(id)))
            
            if options:
                placeholder = (
                    f"Выбрано: {saved_dino_class}"
                    if saved_dino_class
                    else "Выберите динозавра для активации"
                )
                self.dino_select = Select(
                    placeholder=placeholder,
                    options=options,
                    custom_id="select_dino",
                    row=0
                )
                self.add_item(self.dino_select)
            
            self.activate_button = Button(
                label="Активировать",
                style=discord.ButtonStyle.green,
                custom_id="activate_dino",
                disabled=self.selected_dino is None,
                row=1
            )
            self.add_item(self.activate_button)
            
            self.add_item(Button(
                label="Удалить",
                style=discord.ButtonStyle.red,
                custom_id="delete_dino",
                disabled=self.selected_dino is None,
                row=1
            ))
            
            self.add_item(Button(
                label="Назад",
                style=discord.ButtonStyle.red,
                custom_id="go_back_dino",
                row=2
            ))
        
        # Кнопки вкладок и навигации
        self.add_item(Button(
            label="📦 Предметы",
            style=discord.ButtonStyle.blurple,
            custom_id="tab_items",
            row=3
        ))
        
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.grey,
            custom_id="back_to_menu",
            row=3
        ))

    @property
    def embed(self) -> discord.Embed:
        if self.active_tab == "items":
            return self._get_items_embed()
        else:
            return self._get_dinosaurs_embed()

    def _get_items_embed(self) -> discord.Embed:
        """Создает embed для вкладки предметов"""
        # Проверяем, есть ли вообще что-то в инвентаре (предметы или динозавры)
        has_items = len(self.inventory_items) > 0
        has_dinosaurs = len(self.dinosaurs) > 0
        
        if not has_items and not has_dinosaurs:
            # Полностью пустой инвентарь
            embed = discord.Embed(
                title="🎒 Инвентарь пуст",
                description="У вас пока нет предметов в инвентаре.\n\n💡 Покупайте предметы в **Главное меню → Магазин**!",
                color=discord.Color.orange()
            )
            embed.set_footer(text="Предметы появятся здесь после покупки")
            return embed
        
        if not has_items:
            # Нет предметов, но есть динозавры
            embed = discord.Embed(
                title="🎒 Ваш инвентарь - Предметы",
                description=f"**Предметов:** 0\n\n"
                           f"🦖 **У вас есть {len(self.dinosaurs)} динозавров!**\n"
                           f"Переключитесь на вкладку **Динозавры**, чтобы активировать их в игру.\n\n"
                           f"💡 Покупайте предметы в **Главное меню → Магазин**!",
                color=discord.Color.blue()
            )
            embed.set_footer(text="Используйте кнопку 'Динозавры' для просмотра ваших динозавров")
            return embed
        
        # Подсчитываем общее количество предметов
        total_items = sum(item['quantity'] for item in self.inventory_items)
        
        # Формируем описание с информацией о предметах и динозаврах
        description = f"**Предметов:** {total_items} шт. ({len(self.inventory_items)} уникальных)"
        if has_dinosaurs:
            description += f"\n🦖 **Динозавров:** {len(self.dinosaurs)} шт."
            description += f"\n\n💡 Переключитесь на вкладку **Динозавры**, чтобы активировать их в игру."
        
        embed = discord.Embed(
            title="🎒 Ваш инвентарь - Предметы",
            description=description,
            color=discord.Color.blue()
        )
        
        # Если выбран предмет, показываем его детали
        if self.selected_item:
            item_type = self.selected_item.get('item_type', '')
            item_name = self.selected_item.get('item_name', 'Неизвестно')
            
            type_emoji = {
                'nutrients': '💊',
                'food_water': '🍖',
                'currency': '💰',
                'special': '⭐'
            }.get(item_type, '📦')
            
            embed.add_field(
                name=f"{type_emoji} Выбран: {item_name}",
                value="Готов к использованию",
                inline=False
            )
        
        # Группируем предметы по типам
        items_by_type = {}
        for item in self.inventory_items:
            item_type = item['item_type']
            if item_type not in items_by_type:
                items_by_type[item_type] = []
            items_by_type[item_type].append(item)
        
        # Русские названия типов с эмодзи
        type_names = {
            'nutrients': '💊 Пополнение нутриентов',
            'food_water': '🍖 Пополнение еды и воды',
            'currency': '💰 Валюта',
            'special': '⭐ Особые'
        }
        
        # Отображаем предметы по типам с общим количеством
        for item_type, items in items_by_type.items():
            type_name = type_names.get(item_type, f'📦 {item_type.title()}')
            
            # Подсчитываем общее количество предметов этого типа
            total_quantity = sum(item['quantity'] for item in items)
            
            # Формируем строку с названием типа и количеством
            items_text = f"**{total_quantity} шт.**"
            
            embed.add_field(
                name=type_name,
                value=items_text,
                inline=True
            )
        
        if self.selected_item:
            embed.set_footer(text="💡 Нажмите 'Использовать предмет' для применения эффекта")
        else:
            embed.set_footer(text="📋 Выберите предмет из списка выше для просмотра деталей")
        
        return embed

    def _get_dinosaurs_embed(self) -> discord.Embed:
        """Создает embed для вкладки динозавров"""
        if self.dino_state == "empty":
            return discord.Embed(
                title="🦖 Коллекция пуста",
                description="У вас нет сохранённых динозавров.\n\n"
                            "Вы можете купить динозавра в нашем магазине или сохранить через игру на "
                            "сервере!",
                color=discord.Color.orange()
            )
        elif self.dino_state == "category":
            return discord.Embed(
                title="🦖 Ваш инвентарь - Динозавры",
                description="Выберите категорию динозавров для активации в игру.",
                color=discord.Color.blue()
            )
        elif self.dino_state == "empty_category":
            return discord.Embed(
                title=f"🦖 Нет динозавров категории: {self.selected_category}",
                description="В этой категории нет сохранённых динозавров.",
                color=discord.Color.orange()
            )
        else:
            # Состояние "dino" - показываем выбранного динозавра и правила
            embed = discord.Embed(
                title=f"🦖 Динозавры категории: {self.selected_category}",
                description="""*Перед активацией динозавра, пожалуйста, ознакомьтесь с правилами ниже:*
### 📋 **Правила активации**
> `1️⃣` Находитесь на сервере во время активации строго на том виде динозавра, которого вы хотите вырастить.
> `2️⃣` В игре выберите нужного динозавра и появитесь на острове и **выберите первую мутацию.**
> `3️⃣` Переместитесь в безопасное место. 
> `4️⃣` Нажмите кнопку активации. **Внимание:** во время активации ваш динозавр **не должен есть/пить/нюхать/сидеть/лежать.** Вы можете идти, бежать, стоять. В противном случае рост не сработает.

### ✅ После активации:
> - **Ваш динозавр будет выращен до 99%** в случае, если активирован слот со взрослым динозавром. Если динозавр из слота был сохранён с ростом меньше, то вы получите ровно тот рост, который был сохранён.
> - Вам необходимо **сразу** выбрать вторую мутацию (пока рост ещё 99%), а после достижения **100% роста можно будет выбрать третью.**
> - В течение 2 минут **запрещено** нападать на других игроков.
> - Рост, голод, жажда динозавра будет изменены.
> - **Мутации динозавра не сохраняются.** """,
                color=discord.Color.dark_green()
            )
            
            # Если выбран динозавр, показываем его статистику
            if self.selected_dino:
                for dino in self.dinosaurs:
                    if str(dino["id"]) == self.selected_dino:
                        dino_name = find_name_by_class(dino["dino_class"])
                        embed.add_field(
                            name="🦖 Выбранный динозавр",
                            value=f"**{dino_name}** (ID: {dino['id']})",
                            inline=False
                        )
                        embed.add_field(
                            name="📊 Статистика",
                            value=f"Рост: {dino['growth']}%\nЗдоровье: {dino['health']}%\nГолод: {dino['hunger']}%\nЖажда: {dino['thirst']}%",
                            inline=True
                        )
                        break
            
            embed.set_footer(text="⚠️ Следуйте правилам для успешной активации динозавра")
            return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        # Переключение вкладок
        if custom_id == "tab_items":
            self.active_tab = "items"
            self.selected_item = None
            await self.update_view()
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
        
        elif custom_id == "tab_dinosaurs":
            self.active_tab = "dinosaurs"
            self.dino_state = "category"
            self.selected_dino = None
            self.selected_category = None
            await self.update_view()
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
        
        # Обработка вкладки предметов
        if self.active_tab == "items":
            return await self._handle_items_interaction(interaction, custom_id)
        
        # Обработка вкладки динозавров
        else:
            return await self._handle_dinosaurs_interaction(interaction, custom_id)

    async def _handle_items_interaction(self, interaction: discord.Interaction, custom_id: str) -> bool:
        """Обрабатывает взаимодействия на вкладке предметов"""
        if custom_id == "select_item":
            self.selected_item = next(
                (item for item in self.inventory_items 
                 if str(item['inventory_id']) == interaction.data["values"][0]),
                None
            )
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
            
        elif custom_id == "use_item":
            if not self.selected_item:
                await interaction.response.send_message(
                    "❌ Сначала выберите предмет!", ephemeral=True
                )
                return False
            
            # Проверяем тип предмета и применяем эффект
            item_type = self.selected_item['item_type']
            game_data = self.selected_item.get('game_data')
            
            # Для предметов, требующих модального окна, отправляем его сразу
            if item_type not in ['nutrients', 'food_water']:
                modal = ItemUseModal(
                    self.selected_item['item_name'],
                    self.selected_item['inventory_id']
                )
                await interaction.response.send_modal(modal)
                return False
            
            # Откладываем ответ для длительных операций
            await interaction.response.defer(ephemeral=True)
            
            if item_type == 'nutrients' and game_data:
                try:
                    data = json.loads(game_data)
                    success, error = await give_nutrients(interaction.user.id)
                    if success:
                        await InventoryCRUD.use_item(self.selected_item['inventory_id'], interaction.user.id)
                        embed = discord.Embed(
                            title="✅ Нутриенты применены",
                            description="Нутриенты успешно применены к вашему динозавру!",
                            color=discord.Color.green()
                        )
                    else:
                        error_msg = error or "Не удалось применить нутриенты"
                        embed = discord.Embed(
                            title="❌ Ошибка",
                            description=f"{error_msg}\n\nУбедитесь, что вы находитесь в игре и онлайн на сервере.",
                            color=discord.Color.red()
                        )
                except Exception as e:
                    logger.error(f"[InventoryView] Ошибка применения нутриентов: {e}", exc_info=True)
                    embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Ошибка применения нутриентов: {str(e)}\n\nУбедитесь, что вы находитесь в игре и онлайн на сервере.",
                        color=discord.Color.red()
                    )
                await interaction.followup.send(embed=embed, ephemeral=True)
                await self.load_data(interaction.user.id)
                await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
                return False
            
            elif item_type == 'food_water' and game_data:
                try:
                    data = json.loads(game_data)
                    success, error = await give_food(interaction.user.id)
                    if success:
                        await InventoryCRUD.use_item(self.selected_item['inventory_id'], interaction.user.id)
                        embed = discord.Embed(
                            title="✅ Еда и вода применены",
                            description="Еда и вода успешно применены к вашему динозавру!",
                            color=discord.Color.green()
                        )
                    else:
                        error_msg = error or "Не удалось применить еду/воду"
                        embed = discord.Embed(
                            title="❌ Ошибка",
                            description=f"{error_msg}\n\nУбедитесь, что вы находитесь в игре и онлайн на сервере.",
                            color=discord.Color.red()
                        )
                except Exception as e:
                    logger.error(f"[InventoryView] Ошибка применения еды/воды: {e}", exc_info=True)
                    embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Ошибка применения еды/воды: {str(e)}\n\nУбедитесь, что вы находитесь в игре и онлайн на сервере.",
                        color=discord.Color.red()
                    )
                await interaction.followup.send(embed=embed, ephemeral=True)
                await self.load_data(interaction.user.id)
                await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
                return False
            
        elif custom_id == "remove_item":
            if not self.selected_item:
                await interaction.response.send_message(
                    "❌ Сначала выберите предмет!", ephemeral=True
                )
                return False
            
            await InventoryCRUD.remove_item_from_inventory(self.selected_item['inventory_id'], interaction.user.id)
            await interaction.response.defer()
            await self.load_data(interaction.user.id)
            await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
            return False
        
        elif custom_id == "refresh_inventory":
            await interaction.response.defer()
            await self.load_data(interaction.user.id)
            await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
            return False
        
        elif custom_id == "back_to_menu":
            await interaction.response.edit_message(embed=self.main_menu_embed, view=self.main_menu_view)
            return False
        
        return False

    async def _handle_dinosaurs_interaction(self, interaction: discord.Interaction, custom_id: str) -> bool:
        """Обрабатывает взаимодействия на вкладке динозавров"""
        if custom_id and custom_id.startswith("category_"):
            category = custom_id.replace("category_", "")
            self.selected_category = category
            self.dino_state = "dino"
            self.selected_dino = None
            self.dinos_in_cat = filter_dinos_by_category(self.dinosaurs, category)
            if not self.dinos_in_cat:
                self.dino_state = "empty_category"
            await self.update_view()
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
        
        elif custom_id == "select_dino":
            self.selected_dino = interaction.data["values"][0]
            await self.update_view()
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
        
        elif custom_id == "activate_dino":
            if not self.selected_dino:
                await interaction.response.send_message(
                    "Сначала выберите динозавра!",
                    ephemeral=True
                )
                return False
            
            # Показываем wait embed
            wait_embed = discord.Embed(
                title="⏳ Пожалуйста, подождите",
                description="Происходит активация выбранного динозавра...\nЭто может занять несколько секунд.",
                color=discord.Color.blurple()
            )
            await interaction.response.edit_message(
                embed=wait_embed,
                view=None
            )
            
            # Активируем динозавра
            result = await restore_dino_script(interaction.user.id, int(self.selected_dino))
            
            if result is True:
                # Находим данные динозавра
                saved_dino_class = "Неизвестно"
                dino_data = None
                for dino in self.dinosaurs:
                    dino_name = find_name_by_class(dino["dino_class"])
                    if str(dino["id"]) == self.selected_dino:
                        saved_dino_class = dino_name
                        dino_data = dino
                        break
                
                # Создаем embed с детальной информацией
                embed = discord.Embed(
                    title="✅ Динозавр активирован в игру",
                    description=f"Динозавр **{saved_dino_class}** успешно активирован!",
                    color=discord.Color.green()
                )
                
                # Добавляем статистику динозавра
                if dino_data:
                    embed.add_field(
                        name="🦖 Динозавр",
                        value=saved_dino_class,
                        inline=True
                    )
                    embed.add_field(
                        name="📊 Рост",
                        value=f"{dino_data.get('growth', 0)}%",
                        inline=True
                    )
                    embed.add_field(
                        name="💚 Здоровье",
                        value=f"{dino_data.get('health', 0)}%",
                        inline=True
                    )
                    embed.add_field(
                        name="🍖 Голод",
                        value=f"{dino_data.get('hunger', 0)}%",
                        inline=True
                    )
                    embed.add_field(
                        name="💧 Жажда",
                        value=f"{dino_data.get('thirst', 0)}%",
                        inline=True
                    )
                
                embed.set_footer(text="Только вы видите это сообщение")
                
                # Создаем View с кнопками
                from views.dinosaurs import DinoActivationSuccessView
                success_view = DinoActivationSuccessView(
                    original_embed=self.main_menu_embed,
                    original_view=self.main_menu_view
                )
                
                await interaction.followup.edit_message(
                    interaction.message.id,
                    embed=embed,
                    view=success_view,
                    content=None
                )
            else:
                reason = result[1] if isinstance(result, tuple) and len(result) > 1 else "Не удалось активировать динозавра."
                embed = discord.Embed(
                    title="❌ Ошибка активации",
                    description=reason,
                    color=discord.Color.red()
                )
                
                # Кнопки навигации при ошибке
                error_view = View(timeout=None)
                error_view.add_item(Button(
                    label="Назад",
                    style=discord.ButtonStyle.red,
                    custom_id="go_back_error",
                    row=0
                ))
                error_view.add_item(Button(
                    label="Главное меню",
                    style=discord.ButtonStyle.grey,
                    custom_id="go_main_menu_error",
                    row=0
                ))
                
                async def error_interaction_check(interaction: discord.Interaction) -> bool:
                    custom_id = interaction.data.get("custom_id")
                    if custom_id == "go_back_error":
                        self.dino_state = "category"
                        self.selected_dino = None
                        self.selected_category = None
                        await self.update_view()
                        await interaction.response.edit_message(embed=self.embed, view=self)
                    elif custom_id == "go_main_menu_error":
                        from views.main_menu import MainMenuView
                        from utils.steam_api import steam_api
                        steam_data = await steam_api.get_steam_data(interaction.user.id)
                        view = MainMenuView(steam_data, interaction.user.id)
                        await view.update_player_data(interaction.user.id)
                        await interaction.response.edit_message(embed=view.embed, view=view, content=None)
                    return False
                
                error_view.interaction_check = error_interaction_check
                
                await interaction.followup.edit_message(
                    interaction.message.id,
                    embed=embed,
                    view=error_view,
                    content=None
                )
            return False
        
        elif custom_id == "delete_dino":
            if not self.selected_dino:
                await interaction.response.send_message(
                    "Сначала выберите динозавра!",
                    ephemeral=True
                )
                return False
            
            result = await del_dino(interaction.user.id, int(self.selected_dino))
            if not result or (isinstance(result, tuple) and not result[0]):
                reason = result[1] if isinstance(result, tuple) and len(result) > 1 else "Не удалось удалить динозавра."
                embed = discord.Embed(
                    title="❌ Ошибка удаления",
                    description=reason,
                    color=discord.Color.red()
                )
                await interaction.response.edit_message(embed=embed, view=None, content=None)
                return False
            
            await interaction.response.edit_message(
                embed=None,
                view=None,
                content=f"Динозавр {self.selected_dino} успешно удален!"
            )
            await self.load_data(interaction.user.id)
            await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
            return False
        
        elif custom_id == "go_back_dino":
            self.dino_state = "category"
            self.selected_dino = None
            self.selected_category = None
            await self.update_view()
            await interaction.response.edit_message(embed=self.embed, view=self)
            return False
        
        elif custom_id == "back_to_menu":
            await interaction.response.edit_message(embed=self.main_menu_embed, view=self.main_menu_view)
            return False
        
        return False
