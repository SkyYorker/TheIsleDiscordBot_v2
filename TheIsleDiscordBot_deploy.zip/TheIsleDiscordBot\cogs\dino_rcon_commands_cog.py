"""
RCON команды для динозавров - интеграция с Discord ботом
Основано на анализе PAK файлов The Isle + рабочий save file метод
"""

import discord
from discord.ext import commands
try:
    from rcon.source import rcon
except ImportError:
    rcon = None
    import logging
    logging.warning("Модуль rcon не установлен. RCON команды будут недоступны.")
import asyncio
from typing import Optional, Dict, Tuple, Any
import logging
from sqlalchemy.orm import sessionmaker
from database.models import Players
from database import get_session
from database.crud import RoleBonusCRUD
try:
    from hunger_restorer import HungerRestorer
except ImportError:
    HungerRestorer = None
    import logging
    logging.warning("Модуль hunger_restorer не найден. Функции восстановления голода будут недоступны.")
try:
    from enhanced_save_commands import EnhancedSaveCommands
except ImportError:
    EnhancedSaveCommands = None
    import logging
    logging.warning("Модуль enhanced_save_commands не найден. Расширенные команды будут недоступны.")
from utils.scripts import give_nutrients, get_current_dino
from utils.clicker_api import restore_dino, set_nutrients
import os

logger = logging.getLogger(__name__)

class DinoRconCommandsCog(commands.Cog):
    """Cog для RCON команд динозавров"""
    
    def __init__(self, bot):
        self.bot = bot
        # Настройки RCON из анализа
        self.rcon_host = "92.38.222.15"
        self.rcon_port = 24904
        self.rcon_password = "TPKNEV3"
        
        # Инициализируем рабочий hunger restorer
        self.hunger_restorer = HungerRestorer() if HungerRestorer else None
        
        # Инициализируем Enhanced Save Commands из PAK анализа
        self.enhanced_commands = EnhancedSaveCommands() if EnhancedSaveCommands else None
        
        # Конфигурация бонусов по ролям
        # ID канала 1 для Первопроходец (можно настроить через переменную окружения)
        self.channel_1_id = int(os.getenv("CHANNEL_1_ID", "0"))  # Установите нужный ID канала
        
        # Найденные команды из PAK анализа
        self.discovered_commands = {
            "hunger_restoration": [
                "feed {player}",
                "sethunger {player} 100",
                "sethunger {player} 1.0",
                "setdinostat {player} hunger 100",
                "setstat {player} hunger 100"
            ],
            "health_restoration": [
                "heal {player}",
                "sethealth {player} 100",
                "god {player}"
            ],
            "admin_commands": [
                "teleport {player} {x} {y} {z}",
                "fly {player}",
                "broadcast \"{message}\"",
                "save"
            ]
        }
    
    async def execute_rcon_command(self, command: str) -> Optional[str]:
        """Выполнение RCON команды с обработкой ошибок"""
        if rcon is None:
            raise ImportError("Модуль rcon не установлен. Установите его командой: pip install rcon")
        try:
            response = await rcon(
                command,
                host=self.rcon_host,
                port=self.rcon_port,
                passwd=self.rcon_password
            )
            return response
        except Exception as e:
            logger.error(f"RCON command failed: {command} - {e}")
            return None
    
    async def restore_hunger_via_savefile(self, steam_id: str, target_value: float = 1.0) -> Dict:
        """Восстановление голода через save файл (рабочий метод)"""
        if not self.hunger_restorer:
            return {
                "success": False,
                "error": "Модуль hunger_restorer не доступен"
            }
        try:
            # Ищем save файл игрока
            save_file = self.hunger_restorer.find_player_save_file(steam_id)
            
            if not save_file:
                return {
                    "success": False, 
                    "error": f"Save файл для Steam ID {steam_id} не найден"
                }
            
            # Восстанавливаем голод
            result = self.hunger_restorer.restore_hunger(save_file, target_value)
            return result
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Ошибка при восстановлении голода: {e}"
            }
    
    @commands.command(name="feed_dino", aliases=["restore_hunger", "feed"])
    async def feed_dinosaur(self, ctx, target_player: Optional[str] = None):
        """
        Восстанавливает голод динозавра
        
        Использование:
        !feed_dino - восстанавливает голод вашего динозавра
        !feed_dino PlayerName - восстанавливает голод указанного игрока (только для админов)
        
        Бонусы по ролям:
        - Первопроходец: 1 бесплатное кормление в неделю (только на канале 1)
        - Nitro Booster: 2 бесплатных кормления в неделю
        """
        
        # Определяем целевого игрока
        is_self_feeding = target_player is None
        
        if is_self_feeding:
            # Получаем Steam ID пользователя для save файла
            steam_id = await self.get_player_steam_id(ctx.author.id)
            if not steam_id:
                await ctx.send("❌ Ваш Steam аккаунт не привязан к боту. Используйте команду привязки аккаунта.")
                return
            
            # Пробуем RCON команды сначала
            steam_name = await self.get_player_steam_name(ctx.author.id)
            if steam_name:
                target_player = steam_name
            
            # Проверяем бонусы по ролям только для самокормления
            role_bonus_info = await self.check_role_bonus(ctx)
            is_free_feeding = role_bonus_info["is_free"]
            bonus_role = role_bonus_info["role_name"]
            bonus_error = role_bonus_info.get("error")
            
            # Если есть ошибка с бонусом (например, лимит исчерпан или неправильный канал), показываем её
            if bonus_error and bonus_role:
                await ctx.send(f"❌ {bonus_error}")
                return
            
            # Проверяем права для обычного использования (если не бесплатно)
            if not is_free_feeding:
                if not any(role.name in ["Admin", "Moderator", "PLUS", "PREMIUM", "SUPREME"] for role in ctx.author.roles):
                    await ctx.send("❌ У вас нет прав для использования этой команды. Нужна подписка или роль Первопроходец/Nitro Booster.")
                    return
        else:
            # Проверяем права на восстановление голода другим игрокам
            if not any(role.name in ["Admin", "Moderator"] for role in ctx.author.roles):
                await ctx.send("❌ У вас нет прав для восстановления голода другим игрокам.")
                return
            is_free_feeding = False
            bonus_role = None
        
        # Создаем embed для красивого отображения
        embed = discord.Embed(
            title="🍖 Восстановление голода динозавра",
            description=f"Попытка восстановить голод для игрока: **{target_player}**",
            color=discord.Color.orange()
        )
        
        # Добавляем информацию о бонусе, если используется бесплатное кормление
        if is_free_feeding and bonus_role:
            current_uses = await RoleBonusCRUD.get_weekly_usage_count(ctx.author.id, bonus_role)
            max_uses = 1 if bonus_role == "Первопроходец" else 2
            embed.add_field(
                name="🎁 Бесплатное кормление",
                value=f"Роль: **{bonus_role}**\nИспользовано: {current_uses}/{max_uses} на эту неделю",
                inline=False
            )
        
        message = await ctx.send(embed=embed)
        
        # Пробуем различные команды восстановления голода
        success = False
        used_command = ""
        response = ""
        
        # Сначала пробуем RCON команды
        if target_player:
            for command_template in self.discovered_commands["hunger_restoration"]:
                command = command_template.format(player=target_player)
                
                embed.add_field(
                    name="🔧 RCON команда",
                    value=f"`{command}`",
                    inline=False
                )
                await message.edit(embed=embed)
                
                result = await self.execute_rcon_command(command)
                
                if result is not None:
                    success = True
                    used_command = command
                    response = result
                    break
                
                await asyncio.sleep(1)  # Пауза между попытками
        
        # Если RCON не сработал, используем save файл метод
        if not success and target_player is None:  # Только для самого пользователя
            embed.clear_fields()
            embed.add_field(
                name="🔧 Использование save файл метода",
                value="RCON команды недоступны, используем модификацию save файла...",
                inline=False
            )
            await message.edit(embed=embed)
            
            steam_id = await self.get_player_steam_id(ctx.author.id)
            if steam_id:
                save_result = await self.restore_hunger_via_savefile(steam_id)
                
                if save_result["success"]:
                    success = True
                    used_command = "Save file modification"
                    response = save_result["message"]
                else:
                    response = save_result.get("error", "Неизвестная ошибка")
        
        # Обновляем embed с результатом
        embed.clear_fields()
        
        if success:
            embed.color = discord.Color.green()
            embed.add_field(
                name="✅ Команда выполнена успешно",
                value=f"**Команда:** `{used_command}`\n**Ответ сервера:** {response[:100]}{'...' if len(response) > 100 else ''}",
                inline=False
            )
            
            # Записываем использование бонуса, если это было бесплатное кормление
            if is_free_feeding and bonus_role:
                await RoleBonusCRUD.record_bonus_usage(ctx.author.id, bonus_role)
                embed.add_field(
                    name="🎁 Бонус использован",
                    value=f"Бесплатное кормление от роли **{bonus_role}** засчитано",
                    inline=False
                )
            
            # Логируем успешное выполнение
            logger.info(f"Hunger restored for {target_player} by {ctx.author} using command: {used_command}")
            
        else:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Не удалось выполнить команду",
                value="Попробованы все доступные команды восстановления голода, но ни одна не сработала.",
                inline=False
            )
            
            # Предлагаем альтернативы
            embed.add_field(
                name="💡 Альтернативные методы",
                value="• Используйте команду `!edit_dino` для модификации save файла\n• Обратитесь к администратору сервера\n• Используйте внутриигровую еду",
                inline=False
            )
        
        await message.edit(embed=embed)
    
    @commands.command(name="heal_dino", aliases=["restore_health", "heal"])
    @commands.has_any_role("Admin", "Moderator", "PLUS", "PREMIUM", "SUPREME")
    async def heal_dinosaur(self, ctx, target_player: Optional[str] = None):
        """
        Восстанавливает здоровье динозавра
        
        Использование:
        !heal_dino - восстанавливает здоровье вашего динозавра
        !heal_dino PlayerName - восстанавливает здоровье указанного игрока (только для админов)
        """
        
        # Определяем целевого игрока
        if target_player is None:
            steam_name = await self.get_player_steam_name(ctx.author.id)
            if not steam_name:
                await ctx.send("❌ Ваш Steam аккаунт не привязан к боту.")
                return
            target_player = steam_name
        else:
            if not any(role.name in ["Admin", "Moderator"] for role in ctx.author.roles):
                await ctx.send("❌ У вас нет прав для восстановления здоровья другим игрокам.")
                return
        
        embed = discord.Embed(
            title="❤️ Восстановление здоровья динозавра",
            description=f"Восстановление здоровья для игрока: **{target_player}**",
            color=discord.Color.red()
        )
        
        # Пробуем команды восстановления здоровья
        for command_template in self.discovered_commands["health_restoration"]:
            command = command_template.format(player=target_player)
            result = await self.execute_rcon_command(command)
            
            if result is not None:
                embed.color = discord.Color.green()
                embed.add_field(
                    name="✅ Здоровье восстановлено",
                    value=f"**Команда:** `{command}`\n**Ответ:** {result}",
                    inline=False
                )
                await ctx.send(embed=embed)
                return
        
        embed.add_field(
            name="❌ Не удалось восстановить здоровье",
            value="Попробуйте использовать команду `!edit_dino` для модификации save файла.",
            inline=False
        )
        await ctx.send(embed=embed)
    
    @commands.command(name="restore_all", aliases=["full_restore", "restore_dino", "full_heal"])
    @commands.has_any_role("Admin", "Moderator", "PLUS", "PREMIUM", "SUPREME")
    async def restore_all_stats(self, ctx, target_player: Optional[str] = None):
        """
        Полностью восстанавливает все характеристики динозавра через Clicker API:
        - Здоровье (HP)
        - Голод
        - Жажда
        - Нутриенты (белки, углеводы, жиры)
        
        Использование:
        !restore_all - восстанавливает все характеристики вашего динозавра
        !restore_all PlayerName - восстанавливает все характеристики указанного игрока (только для админов)
        
        Примечание: Рост динозавра сохраняется текущим, не изменяется.
        """
        
        # Определяем целевого игрока (для Clicker API нужен steam_id, не имя)
        discord_id = ctx.author.id
        steam_id = None
        
        if target_player is None:
            # Восстанавливаем свои характеристики
            steam_id = await self.get_player_steam_id(ctx.author.id)
            if not steam_id:
                await ctx.send("❌ Ваш Steam аккаунт не привязан к боту. Используйте команду привязки аккаунта.")
                return
        else:
            # Проверяем права на восстановление другим игрокам
            if not any(role.name in ["Admin", "Moderator"] for role in ctx.author.roles):
                await ctx.send("❌ У вас нет прав для восстановления характеристик другим игрокам.")
                return
            
            # Для других игроков нужно получить steam_id по имени через RCON
            # Это сложнее, поэтому пока ограничимся только своими характеристиками
            await ctx.send("❌ Восстановление других игроков через Clicker API требует их steam_id. Используйте команду `/restore_dino` в админ-панели.")
            return
        
        embed = discord.Embed(
            title="🔄 Полное восстановление динозавра",
            description=f"Восстановление всех характеристик через Clicker API для: **{steam_id}**",
            color=discord.Color.gold()
        )
        
        embed.add_field(
            name="📋 Восстанавливаемые характеристики",
            value="• ❤️ Здоровье (HP) - 100\n• 🍖 Голод - 100\n• 💧 Жажда - 100\n• 🥩 Нутриенты (белки, углеводы, жиры) - 100",
            inline=False
        )
        
        message = await ctx.send(embed=embed)
        
        success_count = 0
        total_operations = 4  # Здоровье, голод, жажда, нутриенты
        errors = []
        
        # 1. Получаем текущий рост динозавра, чтобы не менять его
        try:
            current_dino = await get_current_dino(discord_id)
            if isinstance(current_dino, tuple):
                error_msg = current_dino[1]
                await ctx.send(f"❌ Не удалось получить данные динозавра: {error_msg}")
                return
            
            # Сохраняем текущий рост (в процентах 0-100)
            current_growth = int(current_dino.growth * 100) if current_dino.growth else 0
            embed.add_field(
                name="ℹ️ Информация",
                value=f"Текущий рост сохранен: {current_growth}%",
                inline=False
            )
            await message.edit(embed=embed)
        except Exception as e:
            logger.error(f"Failed to get current dino: {e}")
            current_growth = 0  # Используем 0 если не удалось получить
        
        await asyncio.sleep(0.5)
        
        # 2. Восстанавливаем основные характеристики через Clicker API (здоровье, голод, жажда)
        try:
            result = await restore_dino(
                steam_id,
                growth=current_growth,  # Сохраняем текущий рост
                hunger=100,  # Максимальный голод
                thirst=100,  # Максимальная жажда
                health=100  # Максимальное здоровье
            )
            
            if isinstance(result, dict) and result.get("success"):
                success_count += 3  # Здоровье, голод, жажда
                embed.add_field(
                    name="✅ Основные характеристики восстановлены",
                    value="Здоровье, голод и жажда установлены на максимум через Clicker API",
                    inline=False
                )
            else:
                error_msg = result.get("message", "Неизвестная ошибка") if isinstance(result, dict) else "Ошибка API"
                errors.append(f"Восстановление характеристик: {error_msg}")
                embed.add_field(
                    name="⚠️ Ошибка восстановления характеристик",
                    value=f"Ошибка: {error_msg}",
                    inline=False
                )
        except Exception as e:
            logger.error(f"Clicker API restore_dino failed: {e}")
            errors.append(f"Восстановление характеристик: {str(e)}")
            embed.add_field(
                name="⚠️ Ошибка Clicker API",
                value=f"Ошибка: {str(e)[:100]}",
                inline=False
            )
        
        await message.edit(embed=embed)
        await asyncio.sleep(0.5)
        
        # 3. Выдаем нутриенты через Clicker API
        try:
            nutrients_result = await set_nutrients(steam_id, 100.0, 100.0, 100.0)
            
            if isinstance(nutrients_result, dict) and nutrients_result.get("success"):
                success_count += 1
                embed.add_field(
                    name="✅ Нутриенты выданы",
                    value="Белки, углеводы и жиры установлены на максимум через Clicker API",
                    inline=False
                )
            else:
                error_msg = nutrients_result.get("message", "Неизвестная ошибка") if isinstance(nutrients_result, dict) else "Ошибка API"
                errors.append(f"Нутриенты: {error_msg}")
                embed.add_field(
                    name="⚠️ Нутриенты не выданы",
                    value=f"Ошибка: {error_msg}",
                    inline=False
                )
        except Exception as e:
            logger.error(f"Clicker API set_nutrients failed: {e}")
            errors.append(f"Нутриенты: {str(e)}")
            embed.add_field(
                name="⚠️ Ошибка выдачи нутриентов",
                value=f"Ошибка: {str(e)[:100]}",
                inline=False
            )
        
        # Финальное сообщение
        embed.clear_fields()
        if success_count == total_operations:
            embed.color = discord.Color.green()
            embed.add_field(
                name="✅ Восстановление завершено успешно",
                value=f"**Успешно восстановлено:** {success_count}/{total_operations} характеристик\n\n"
                      f"✅ Здоровье (HP) - 100\n"
                      f"✅ Голод - 100\n"
                      f"✅ Жажда - 100\n"
                      f"✅ Нутриенты (белки, углеводы, жиры) - 100\n\n"
                      f"Рост сохранен: {current_growth}%",
                inline=False
            )
        elif success_count > 0:
            embed.color = discord.Color.orange()
            embed.add_field(
                name="⚠️ Частичное восстановление",
                value=f"**Восстановлено:** {success_count}/{total_operations} характеристик\n\n"
                      f"{'✅' if success_count >= 3 else '❌'} Основные характеристики (здоровье, голод, жажда)\n"
                      f"{'✅' if success_count == 4 else '❌'} Нутриенты\n\n"
                      f"**Ошибки:**\n" + "\n".join(f"• {e}" for e in errors[:3]),
                inline=False
            )
        else:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Восстановление не удалось",
                value=f"**Ошибки:**\n" + "\n".join(f"• {e}" for e in errors[:5]) + "\n\n"
                      f"Проверьте:\n"
                      f"• Игрок должен быть онлайн на сервере\n"
                      f"• Настройки Clicker API в .env файле\n"
                      f"• Попробуйте использовать команды отдельно",
                inline=False
            )
        
        await message.edit(embed=embed)
    
    @commands.command(name="tp_player", aliases=["teleport"])
    @commands.has_any_role("Admin", "Moderator")
    async def teleport_player(self, ctx, player_name: str, x: float, y: float, z: float):
        """
        Телепортирует игрока в указанные координаты
        
        Использование: !tp_player PlayerName 1000 2000 500
        """
        
        command = f"teleport {player_name} {x} {y} {z}"
        
        embed = discord.Embed(
            title="🚀 Телепортация игрока",
            description=f"Телепортируем **{player_name}** в координаты ({x}, {y}, {z})",
            color=discord.Color.blue()
        )
        
        result = await self.execute_rcon_command(command)
        
        if result is not None:
            embed.color = discord.Color.green()
            embed.add_field(
                name="✅ Телепортация выполнена",
                value=f"**Команда:** `{command}`\n**Ответ:** {result}",
                inline=False
            )
        else:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка телепортации",
                value="Не удалось выполнить команду телепортации.",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="server_save", aliases=["save_world"])
    @commands.has_any_role("Admin")
    async def save_server(self, ctx):
        """Сохраняет состояние сервера"""
        
        embed = discord.Embed(
            title="💾 Сохранение сервера",
            description="Выполняется сохранение состояния сервера...",
            color=discord.Color.blue()
        )
        
        message = await ctx.send(embed=embed)
        
        result = await self.execute_rcon_command("save")
        
        if result is not None:
            embed.color = discord.Color.green()
            embed.description = "✅ Сервер успешно сохранен!"
            embed.add_field(
                name="Ответ сервера",
                value=result[:200] if result else "Сохранение выполнено",
                inline=False
            )
        else:
            embed.color = discord.Color.red()
            embed.description = "❌ Не удалось сохранить сервер"
        
        await message.edit(embed=embed)
    
    @commands.command(name="list_online", aliases=["online_players", "who"])
    async def list_online_players(self, ctx):
        """Показывает список игроков онлайн"""
        
        embed = discord.Embed(
            title="👥 Игроки онлайн",
            description="Получение списка игроков...",
            color=discord.Color.blue()
        )
        
        message = await ctx.send(embed=embed)
        
        result = await self.execute_rcon_command("listplayers")
        
        if result is not None:
            embed.color = discord.Color.green()
            
            # Парсим список игроков
            players = []
            lines = result.split('\n')
            for line in lines:
                line = line.strip()
                if line and not line.startswith('Players') and len(line) > 3:
                    players.append(line)
            
            if players:
                embed.description = f"**Игроков онлайн: {len(players)}**"
                embed.add_field(
                    name="Список игроков",
                    value='\n'.join(f"• {player}" for player in players[:10]),  # Показываем максимум 10
                    inline=False
                )
                
                if len(players) > 10:
                    embed.add_field(
                        name="И еще...",
                        value=f"+ {len(players) - 10} игроков",
                        inline=False
                    )
            else:
                embed.description = "**Игроков онлайн: 0**"
                embed.add_field(
                    name="Сервер пуст",
                    value="На сервере нет игроков",
                    inline=False
                )
        else:
            embed.color = discord.Color.red()
            embed.description = "❌ Не удалось получить список игроков"
        
        await message.edit(embed=embed)
    
    @commands.command(name="broadcast_server", aliases=["announce"])
    @commands.has_any_role("Admin", "Moderator")
    async def broadcast_message(self, ctx, *, message: str):
        """
        Отправляет сообщение всем игрокам на сервере
        
        Использование: !broadcast_server Привет всем!
        """
        
        command = f'broadcast "{message}"'
        
        embed = discord.Embed(
            title="📢 Объявление на сервере",
            description=f"Отправляем сообщение: **{message}**",
            color=discord.Color.gold()
        )
        
        result = await self.execute_rcon_command(command)
        
        if result is not None:
            embed.color = discord.Color.green()
            embed.add_field(
                name="✅ Сообщение отправлено",
                value=f"Все игроки на сервере получили ваше сообщение",
                inline=False
            )
        else:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка отправки",
                value="Не удалось отправить сообщение на сервер",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="rcon_help")
    async def rcon_help(self, ctx):
        """Показывает доступные RCON команды"""
        
        embed = discord.Embed(
            title="🔧 Доступные RCON команды",
            description="Команды основаны на анализе PAK файлов The Isle",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="🍖 Команды для динозавров",
            value="• `!restore_all` - **полное восстановление всех характеристик через Clicker API** (HP, голод, жажда, нутриенты)\n• `!feed_dino [игрок]` - восстановить голод\n• `!heal_dino [игрок]` - восстановить здоровье\n• `!dino_god [true/false]` - режим бога (неуязвимость)\n• `!dino_fly [true/false]` - режим полета",
            inline=False
        )
        
        embed.add_field(
            name="🚀 Админские команды",
            value="• `!tp_player игрок x y z` - телепортация\n• `!enhanced_tp x y z [игрок]` - PAK-style телепорт\n• `!broadcast_server сообщение` - объявление\n• `!server_save` - сохранить сервер",
            inline=False
        )
        
        embed.add_field(
            name="👥 Информационные команды",
            value="• `!list_online` - список игроков онлайн",
            inline=False
        )
        
        embed.add_field(
            name="💡 Примечания",
            value="• Команды для других игроков доступны только админам\n• PAK-style команды: RCON + save fallback\n• Основано на анализе PAK файлов The Isle\n• Все команды логируются",
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="dino_god", aliases=["god_mode"])
    @commands.has_any_role("Admin", "Moderator", "PLUS", "PREMIUM", "SUPREME")
    async def dino_god_mode(self, ctx, enable: str = "true"):
        """
        Включает режим бога для динозавра (неуязвимость)
        Основано на команде 'god' найденной в PAK файлах
        
        Использование: !dino_god true/false
        """
        
        steam_id = await self.get_player_steam_id(ctx.author.id)
        if not steam_id:
            await ctx.send("❌ Ваш Steam аккаунт не привязан к боту.")
            return
        
        save_file = self.hunger_restorer.find_player_save_file(steam_id)
        if not save_file:
            await ctx.send("❌ Save файл не найден.")
            return
        
        god_enabled = enable.lower() in ["true", "1", "on", "да"]
        
        embed = discord.Embed(
            title="🛡️ Режим бога динозавра",
            description=f"{'Включаем' if god_enabled else 'Выключаем'} режим бога...",
            color=discord.Color.gold()
        )
        
        message = await ctx.send(embed=embed)
        
        # Сначала пробуем RCON
        steam_name = await self.get_player_steam_name(ctx.author.id)
        if steam_name:
            god_command = f"god {steam_name}" if god_enabled else f"god {steam_name} false"
            rcon_result = await self.execute_rcon_command(god_command)
            
            if rcon_result is not None:
                embed.color = discord.Color.green()
                embed.add_field(
                    name="✅ Режим бога активирован через RCON",
                    value=f"Команда: `{god_command}`\nОтвет: {rcon_result}",
                    inline=False
                )
                await message.edit(embed=embed)
                return
        
        # Fallback на save файл
        if not self.enhanced_commands:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка",
                value="Модуль enhanced_save_commands не доступен",
                inline=False
            )
            await message.edit(embed=embed)
            return
        
        try:
            success = self.enhanced_commands.god_mode(save_file, god_enabled)
            
            if success:
                embed.color = discord.Color.green()
                embed.add_field(
                    name="✅ Режим бога активирован через save файл",
                    value="Максимальные характеристики установлены",
                    inline=False
                )
            else:
                embed.color = discord.Color.red()
                embed.add_field(
                    name="❌ Ошибка активации режима бога",
                    value="Не удалось изменить характеристики",
                    inline=False
                )
        except Exception as e:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка",
                value=f"Произошла ошибка: {e}",
                inline=False
            )
        
        await message.edit(embed=embed)
    
    @commands.command(name="dino_fly", aliases=["fly_mode"])
    @commands.has_any_role("Admin", "Moderator", "PLUS", "PREMIUM", "SUPREME")
    async def dino_fly_mode(self, ctx, enable: str = "true"):
        """
        Включает режим полета для динозавра (бесконечная выносливость)
        Основано на команде 'fly' найденной в PAK файлах
        
        Использование: !dino_fly true/false
        """
        
        steam_id = await self.get_player_steam_id(ctx.author.id)
        if not steam_id:
            await ctx.send("❌ Ваш Steam аккаунт не привязан к боту.")
            return
        
        save_file = self.hunger_restorer.find_player_save_file(steam_id)
        if not save_file:
            await ctx.send("❌ Save файл не найден.")
            return
        
        fly_enabled = enable.lower() in ["true", "1", "on", "да"]
        
        embed = discord.Embed(
            title="🦅 Режим полета динозавра",
            description=f"{'Включаем' if fly_enabled else 'Выключаем'} режим полета...",
            color=discord.Color.blue()
        )
        
        message = await ctx.send(embed=embed)
        
        # Сначала пробуем RCON
        steam_name = await self.get_player_steam_name(ctx.author.id)
        if steam_name:
            fly_command = f"fly {steam_name}" if fly_enabled else f"fly {steam_name} false"
            rcon_result = await self.execute_rcon_command(fly_command)
            
            if rcon_result is not None:
                embed.color = discord.Color.green()
                embed.add_field(
                    name="✅ Режим полета активирован через RCON",
                    value=f"Команда: `{fly_command}`\nОтвет: {rcon_result}",
                    inline=False
                )
                await message.edit(embed=embed)
                return
        
        # Fallback на save файл
        if not self.enhanced_commands:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка",
                value="Модуль enhanced_save_commands не доступен",
                inline=False
            )
            await message.edit(embed=embed)
            return
        
        try:
            success = self.enhanced_commands.fly_mode(save_file, fly_enabled)
            
            if success:
                embed.color = discord.Color.green()
                embed.add_field(
                    name="✅ Режим полета активирован через save файл",
                    value="Бесконечная выносливость установлена",
                    inline=False
                )
            else:
                embed.color = discord.Color.red()
                embed.add_field(
                    name="❌ Ошибка активации режима полета",
                    value="Не удалось изменить выносливость",
                    inline=False
                )
        except Exception as e:
            embed.color = discord.Color.red()
            embed.add_field(
                name="❌ Ошибка",
                value=f"Произошла ошибка: {e}",
                inline=False
            )
        
        await message.edit(embed=embed)
    
    async def check_role_bonus(self, ctx) -> Dict[str, Any]:
        """
        Проверяет, может ли пользователь использовать бесплатное кормление по роли
        
        Returns:
            {
                "is_free": bool,
                "role_name": Optional[str],
                "error": Optional[str]
            }
        """
        user_roles = [role.name for role in ctx.author.roles]
        
        # Проверяем роль Nitro Booster (2 раза в неделю, любой канал)
        if "Nitro Booster" in user_roles:
            can_use, current_uses, error = await RoleBonusCRUD.can_use_bonus(ctx.author.id, "Nitro Booster", 2)
            if can_use:
                return {"is_free": True, "role_name": "Nitro Booster", "error": None}
            else:
                return {"is_free": False, "role_name": "Nitro Booster", "error": error}
        
        # Проверяем роль Первопроходец (1 раз в неделю, только канал 1)
        if "Первопроходец" in user_roles:
            # Проверяем, что команда используется на канале 1
            if self.channel_1_id and ctx.channel.id != self.channel_1_id:
                return {
                    "is_free": False,
                    "role_name": "Первопроходец",
                    "error": f"Роль Первопроходец может использовать бесплатное кормление только на канале 1 (ID: {self.channel_1_id})"
                }
            
            can_use, current_uses, error = await RoleBonusCRUD.can_use_bonus(ctx.author.id, "Первопроходец", 1)
            if can_use:
                return {"is_free": True, "role_name": "Первопроходец", "error": None}
            else:
                return {"is_free": False, "role_name": "Первопроходец", "error": error}
        
        return {"is_free": False, "role_name": None, "error": None}
    
    async def get_player_steam_id(self, discord_id: int) -> Optional[str]:
        """Получает Steam ID игрока по Discord ID"""
        try:
            with get_session() as session:
                player = session.query(Players).filter_by(discord_id=discord_id).first()
                return player.steam_id if player else None
        except:
            return None
    
    async def get_player_steam_name(self, discord_id: int) -> Optional[str]:
        """Получает Steam имя игрока по Discord ID"""
        try:
            with get_session() as session:
                player = session.query(Players).filter_by(discord_id=discord_id).first()
                # Если у модели Players нет поля steam_name, возвращаем None
                return getattr(player, 'steam_name', None) if player else None
        except:
            return None

async def setup(bot):
    """Регистрация cog"""
    await bot.add_cog(DinoRconCommandsCog(bot))