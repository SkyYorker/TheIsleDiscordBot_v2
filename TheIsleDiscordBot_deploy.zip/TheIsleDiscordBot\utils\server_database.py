"""
Адаптер для работы с базой данных сервера The Isle
Поддерживает прямое взаимодействие с SQLite БД сервера
"""

import sqlite3
import asyncio
import aiosqlite
import json
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class TheIsleServerDatabase:
    """Класс для работы с базой данных сервера The Isle"""
    
    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.connection = None
        self._table_structure = {}
        
    async def connect(self) -> bool:
        """Подключение к базе данных"""
        try:
            if not self.db_path.exists():
                logger.error(f"Database file not found: {self.db_path}")
                return False
                
            # Проверяем доступность БД
            self.connection = await aiosqlite.connect(str(self.db_path))
            await self._analyze_structure()
            logger.info(f"Connected to The Isle server database: {self.db_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            return False
    
    async def disconnect(self):
        """Закрытие соединения"""
        if self.connection:
            await self.connection.close()
            self.connection = None
    
    async def _analyze_structure(self):
        """Анализ структуры базы данных"""
        try:
            # Получаем список таблиц
            cursor = await self.connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table';"
            )
            tables = await cursor.fetchall()
            
            for (table_name,) in tables:
                # Анализируем структуру каждой таблицы
                cursor = await self.connection.execute(f"PRAGMA table_info({table_name});")
                columns = await cursor.fetchall()
                
                self._table_structure[table_name] = {
                    "columns": {col[1]: col[2] for col in columns},
                    "primary_key": [col[1] for col in columns if col[5] == 1]
                }
                
            logger.info(f"Analyzed {len(self._table_structure)} tables")
            
        except Exception as e:
            logger.error(f"Error analyzing database structure: {e}")
    
    def get_table_structure(self) -> Dict:
        """Возвращает структуру таблиц БД"""
        return self._table_structure
    
    async def get_player_data(self, steam_id: str) -> Optional[Dict]:
        """Получение данных игрока по Steam ID"""
        if not self.connection:
            return None
            
        # Ищем таблицу с данными игроков
        player_table = self._find_player_table()
        if not player_table:
            logger.warning("Player table not found in database")
            return None
            
        try:
            # Различные варианты запросов в зависимости от структуры таблицы
            possible_columns = ['steam_id', 'steamid', 'player_id', 'userid', 'id']
            steam_column = None
            
            for col in possible_columns:
                if col in self._table_structure[player_table]["columns"]:
                    steam_column = col
                    break
            
            if not steam_column:
                logger.error(f"Steam ID column not found in table {player_table}")
                return None
                
            cursor = await self.connection.execute(
                f"SELECT * FROM {player_table} WHERE {steam_column} = ?",
                (steam_id,)
            )
            
            row = await cursor.fetchone()
            if row:
                # Преобразуем результат в словарь
                columns = list(self._table_structure[player_table]["columns"].keys())
                return dict(zip(columns, row))
                
        except Exception as e:
            logger.error(f"Error getting player data: {e}")
            
        return None
    
    async def get_all_players(self) -> List[Dict]:
        """Получение данных всех игроков"""
        if not self.connection:
            return []
            
        player_table = self._find_player_table()
        if not player_table:
            return []
            
        try:
            cursor = await self.connection.execute(f"SELECT * FROM {player_table}")
            rows = await cursor.fetchall()
            
            columns = list(self._table_structure[player_table]["columns"].keys())
            return [dict(zip(columns, row)) for row in rows]
            
        except Exception as e:
            logger.error(f"Error getting all players: {e}")
            return []
    
    async def update_player_data(self, steam_id: str, updates: Dict) -> bool:
        """Обновление данных игрока"""
        if not self.connection:
            return False
            
        player_table = self._find_player_table()
        if not player_table:
            return False
            
        try:
            # Находим колонку с Steam ID
            steam_column = self._find_steam_id_column(player_table)
            if not steam_column:
                return False
                
            # Формируем запрос обновления
            set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
            values = list(updates.values()) + [steam_id]
            
            await self.connection.execute(
                f"UPDATE {player_table} SET {set_clause} WHERE {steam_column} = ?",
                values
            )
            
            await self.connection.commit()
            logger.info(f"Updated player data for Steam ID: {steam_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating player data: {e}")
            return False
    
    async def get_player_dinosaurs(self, steam_id: str) -> List[Dict]:
        """Получение динозавров игрока"""
        if not self.connection:
            return []
            
        # Ищем таблицу с динозаврами
        dino_table = self._find_dinosaur_table()
        if not dino_table:
            return []
            
        try:
            steam_column = self._find_steam_id_column(dino_table)
            if not steam_column:
                return []
                
            cursor = await self.connection.execute(
                f"SELECT * FROM {dino_table} WHERE {steam_column} = ?",
                (steam_id,)
            )
            
            rows = await cursor.fetchall()
            columns = list(self._table_structure[dino_table]["columns"].keys())
            return [dict(zip(columns, row)) for row in rows]
            
        except Exception as e:
            logger.error(f"Error getting player dinosaurs: {e}")
            return []
    
    async def create_dinosaur(self, steam_id: str, dino_data: Dict) -> bool:
        """Создание нового динозавра"""
        if not self.connection:
            return False
            
        dino_table = self._find_dinosaur_table()
        if not dino_table:
            return False
            
        try:
            # Добавляем Steam ID к данным динозавра
            steam_column = self._find_steam_id_column(dino_table)
            if steam_column:
                dino_data[steam_column] = steam_id
                
            # Формируем запрос вставки
            columns = ", ".join(dino_data.keys())
            placeholders = ", ".join(["?" for _ in dino_data])
            values = list(dino_data.values())
            
            await self.connection.execute(
                f"INSERT INTO {dino_table} ({columns}) VALUES ({placeholders})",
                values
            )
            
            await self.connection.commit()
            logger.info(f"Created dinosaur for Steam ID: {steam_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error creating dinosaur: {e}")
            return False
    
    def _find_player_table(self) -> Optional[str]:
        """Поиск таблицы с данными игроков"""
        possible_names = ['players', 'player', 'users', 'user_data', 'accounts']
        
        for table_name in self._table_structure.keys():
            if table_name.lower() in possible_names:
                return table_name
                
        # Ищем по наличию характерных колонок
        for table_name, info in self._table_structure.items():
            columns = [col.lower() for col in info["columns"].keys()]
            if any(col in columns for col in ['steam_id', 'steamid', 'player_id']):
                return table_name
                
        return None
    
    def _find_dinosaur_table(self) -> Optional[str]:
        """Поиск таблицы с динозаврами"""
        possible_names = ['dinosaurs', 'dinos', 'characters', 'dino_data']
        
        for table_name in self._table_structure.keys():
            if table_name.lower() in possible_names:
                return table_name
                
        # Ищем по наличию характерных колонок
        for table_name, info in self._table_structure.items():
            columns = [col.lower() for col in info["columns"].keys()]
            if any(col in columns for col in ['dino_class', 'species', 'growth', 'health']):
                return table_name
                
        return None
    
    def _find_steam_id_column(self, table_name: str) -> Optional[str]:
        """Поиск колонки с Steam ID в таблице"""
        if table_name not in self._table_structure:
            return None
            
        columns = self._table_structure[table_name]["columns"]
        possible_names = ['steam_id', 'steamid', 'player_id', 'userid']
        
        for col_name in columns.keys():
            if col_name.lower() in possible_names:
                return col_name
                
        return None


class TheIsleServerMonitor:
    """Мониторинг изменений в БД сервера"""
    
    def __init__(self, db_adapter: TheIsleServerDatabase):
        self.db = db_adapter
        self._monitoring = False
        self._callbacks = []
        
    def add_callback(self, callback):
        """Добавление callback для уведомлений об изменениях"""
        self._callbacks.append(callback)
        
    async def start_monitoring(self, interval: int = 5):
        """Запуск мониторинга изменений"""
        self._monitoring = True
        last_check = {}
        
        while self._monitoring:
            try:
                # Проверяем изменения в данных игроков
                current_players = await self.db.get_all_players()
                current_hash = hash(str(current_players))
                
                if last_check.get('players') != current_hash:
                    last_check['players'] = current_hash
                    await self._notify_callbacks('players_changed', current_players)
                    
                await asyncio.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring: {e}")
                await asyncio.sleep(interval)
    
    def stop_monitoring(self):
        """Остановка мониторинга"""
        self._monitoring = False
        
    async def _notify_callbacks(self, event_type: str, data: Any):
        """Уведомление callbacks об изменениях"""
        for callback in self._callbacks:
            try:
                await callback(event_type, data)
            except Exception as e:
                logger.error(f"Error in callback: {e}")


# Пример использования
async def example_usage():
    # Инициализация
    db = TheIsleServerDatabase("path/to/server/database.db")
    
    if await db.connect():
        # Получение данных игрока
        player_data = await db.get_player_data("76561197961112579")
        print(f"Player data: {player_data}")
        
        # Получение динозавров игрока
        dinosaurs = await db.get_player_dinosaurs("76561197961112579")
        print(f"Player dinosaurs: {dinosaurs}")
        
        # Обновление данных
        await db.update_player_data("76561197961112579", {
            "last_login": datetime.now(timezone.utc).isoformat(),
            "playtime": 150
        })
        
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(example_usage())