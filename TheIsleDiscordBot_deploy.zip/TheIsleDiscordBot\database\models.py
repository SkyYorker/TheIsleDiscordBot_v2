from datetime import datetime, UTC, timedelta
from enum import Enum, auto
from typing import Optional

from sqlalchemy import DateTime, Text, Integer, Boolean, Enum as SQLEnum
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class SubscriptionTier(Enum):
    PLUS = auto()
    PREMIUM = auto()
    SUPREME = auto()


SUBSCRIPTION_CONFIG = {
    SubscriptionTier.PLUS: {
        "price": 199,
        "dino_slots": 3,
        "discord_role_id": 1395453023727390863
    },
    SubscriptionTier.PREMIUM: {
        "price": 599,
        "dino_slots": 6,
        "discord_role_id": 1395452649045753936
    },
    SubscriptionTier.SUPREME: {
        "price": 899,
        "dino_slots": 8,
        "discord_role_id": 1395452801970344017
    }
}


class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    steam_id: Mapped[str] = mapped_column(Text, index=True, nullable=False)
    tier: Mapped[SubscriptionTier] = mapped_column(SQLEnum(SubscriptionTier), nullable=False)
    dino_slots: Mapped[int] = mapped_column(Integer, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    auto_renewal: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    purchase_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )
    expiration_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )

    @classmethod
    def create(
            cls,
            steam_id: str,
            tier: SubscriptionTier,
            duration_days: int = 30
    ) -> "Subscription":
        if tier not in SUBSCRIPTION_CONFIG:
            raise ValueError(f"Unknown subscription tier: {tier}")

        now = datetime.now(UTC)
        return cls(
            steam_id=steam_id,
            tier=tier,
            dino_slots=SUBSCRIPTION_CONFIG[tier]["dino_slots"],
            is_active=True,
            auto_renewal=True,
            purchase_date=now,
            expiration_date=now + timedelta(days=duration_days)
        )


class Players(Base):
    __tablename__ = "players"

    discord_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    steam_id: Mapped[Optional[str]] = mapped_column(Text, unique=True, nullable=True)
    tk: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    registry_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )


class DinoStorage(Base):
    __tablename__ = "dino_storage"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    dino_class: Mapped[str] = mapped_column(Text, nullable=False)
    growth: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    hunger: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    thirst: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    health: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    steam_id: Mapped[str] = mapped_column(Text, nullable=False)


class PendingDinoStorage(Base):
    __tablename__ = "pending_dino_storage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    steam_id: Mapped[str] = mapped_column(Text, nullable=False, index=True)
    discord_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )
    url: Mapped[str] = mapped_column(Text, nullable=False)
    dino_class: Mapped[str] = mapped_column(Text, nullable=False)
    growth: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    hunger: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    thirst: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    health: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    def __repr__(self):
        return (
            f"<PendingDinoStorage(id={self.id}, steam_id={self.steam_id}, "
            f"discord_id={self.discord_id}, created_at={self.created_at}, url={self.url})>"
        )


class ItemType(Enum):
    DINOSAUR = "dinosaur"
    NUTRIENTS = "nutrients"
    FOOD_WATER = "food_water"
    CURRENCY = "currency"
    SPECIAL = "special"


class Item(Base):
    __tablename__ = "items"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    item_type: Mapped[ItemType] = mapped_column(SQLEnum(ItemType), nullable=False)
    price: Mapped[int] = mapped_column(Integer, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    max_stack: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    game_data: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON данные для игры
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )


class PlayerInventory(Base):
    __tablename__ = "player_inventory"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    discord_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    item_id: Mapped[int] = mapped_column(Integer, nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    purchased_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )
    used_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    is_used: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    def __repr__(self):
        return (
            f"<PlayerInventory(id={self.id}, discord_id={self.discord_id}, "
            f"item_id={self.item_id}, quantity={self.quantity}, is_used={self.is_used})>"
        )


class BonusCode(Base):
    __tablename__ = "bonus_codes"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(Text, unique=True, nullable=False, index=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    reward_type: Mapped[str] = mapped_column(Text, nullable=False)  # "tk", "item", "subscription"
    reward_value: Mapped[str] = mapped_column(Text, nullable=False)  # JSON с данными награды
    max_uses: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    current_uses: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    expires_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )
    created_by: Mapped[int] = mapped_column(Integer, nullable=False)  # Discord ID создателя

    def __repr__(self):
        return (
            f"<BonusCode(id={self.id}, code={self.code}, "
            f"current_uses={self.current_uses}/{self.max_uses}, is_active={self.is_active})>"
        )


class BonusCodeUsage(Base):
    __tablename__ = "bonus_code_usage"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    code_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    discord_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False
    )
    reward_received: Mapped[str] = mapped_column(Text, nullable=False)  # JSON с полученной наградой

    def __repr__(self):
        return (
            f"<BonusCodeUsage(id={self.id}, code_id={self.code_id}, "
            f"discord_id={self.discord_id}, used_at={self.used_at})>"
        )


class RoleBonusUsage(Base):
    __tablename__ = "role_bonus_usage"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    discord_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    role_name: Mapped[str] = mapped_column(Text, nullable=False)  # "Первопроходец" или "Nitro Booster"
    bonus_type: Mapped[str] = mapped_column(Text, nullable=False)  # "growth", "full_restore", "nutrients"
    used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.now(UTC), nullable=False, index=True
    )
    week_start: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )  # Начало недели для отслеживания

    def __repr__(self):
        return (
            f"<RoleBonusUsage(id={self.id}, discord_id={self.discord_id}, "
            f"role_name={self.role_name}, bonus_type={self.bonus_type}, "
            f"used_at={self.used_at}, week_start={self.week_start})>"
        )