#!/usr/bin/env python3
"""
Client for The Isle server API
"""

import aiohttp
import asyncio
from typing import Dict, Any, Optional

class ServerAPIClient:
    def __init__(self, base_url: str = "http://localhost:8080"):
        self.base_url = base_url.rstrip('/')
    
    async def restore_dino(self, steam_id: str, growth: float = 0.0) -> Dict[str, Any]:
        """Полное восстановление динозавра"""
        url = f"{self.base_url}/restore-dino"
        data = {
            "steam_id": steam_id,
            "growth": growth
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data) as response:
                return await response.json()
    
    async def heal_dino(self, steam_id: str) -> Dict[str, Any]:
        """Лечение динозавра"""
        url = f"{self.base_url}/heal-dino"
        data = {"steam_id": steam_id}
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data) as response:
                return await response.json()
    
    async def feed_dino(self, steam_id: str) -> Dict[str, Any]:
        """Кормление динозавра"""
        url = f"{self.base_url}/feed-dino"
        data = {"steam_id": steam_id}
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data) as response:
                return await response.json()
    
    async def boost_growth(self, steam_id: str, amount: float = 0.1) -> Dict[str, Any]:
        """Увеличение роста динозавра"""
        url = f"{self.base_url}/boost-growth"
        data = {
            "steam_id": steam_id,
            "amount": amount
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data) as response:
                return await response.json()

# Глобальный экземпляр клиента
server_api = ServerAPIClient()

# Пример использования:
async def test_api():
    # Восстановление динозавра
    result = await server_api.restore_dino("76561198032456798", growth=0.75)
    print(f"Restore result: {result}")
    
    # Лечение динозавра
    result = await server_api.heal_dino("76561198032456798")
    print(f"Heal result: {result}")

if __name__ == "__main__":
    asyncio.run(test_api())