from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

DATABASE_URL = "sqlite+aiosqlite:///./main.db"

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    future=True
)

async_session_maker = async_sessionmaker(
    engine,
    expire_on_commit=False
)

# Для обратной совместимости
def get_session():
    """Получить синхронную сессию как контекстный менеджер (deprecated, используйте async_session_maker)"""
    from sqlalchemy.orm import sessionmaker
    from sqlalchemy import create_engine
    from contextlib import contextmanager
    
    sync_engine = create_engine(DATABASE_URL.replace("+aiosqlite", ""))
    Session = sessionmaker(bind=sync_engine)
    
    @contextmanager
    def session_scope():
        session = Session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    
    return session_scope()