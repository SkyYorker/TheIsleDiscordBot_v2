#!/usr/bin/env python3
"""
Скрипт для обновления услуг в магазине
- Удаляет все тестовые предметы
- Создает только два нужных предмета: "Пополнение нутриентов" и "Пополнение еды и воды"
"""

import asyncio
import json
import sys
from pathlib import Path

# Добавляем родительскую папку в путь для импорта
sys.path.insert(0, str(Path(__file__).parent.parent))

from database.crud import init_models, ItemCRUD, ItemType


async def update_services():
    """Обновление услуг в магазине"""
    
    # Инициализируем БД
    await init_models()
    
    print("🔄 Обновление услуг в магазине...")
    print("")
    
    # Получаем все предметы
    all_items = await ItemCRUD.get_all_items(active_only=False)
    
    # Удаляем все предметы с типом nutrients и food_water
    deleted_count = 0
    for item in all_items:
        if item['item_type'] in ['nutrients', 'food_water']:
            try:
                # Деактивируем предмет (мягкое удаление)
                await ItemCRUD.update_item(item['id'], {'is_active': False})
                print(f"❌ Деактивирован: {item['name']}")
                deleted_count += 1
            except Exception as e:
                print(f"⚠️  Ошибка при деактивации '{item['name']}': {e}")
    
    print(f"\n🗑️  Деактивировано предметов: {deleted_count}")
    print("")
    
    # Создаем два новых предмета
    services = [
        {
            "name": "Пополнение нутриентов",
            "description": "Восстанавливает все нутриенты динозавра до 100%",
            "item_type": ItemType.NUTRIENTS,
            "price": 50,
            "max_stack": 10,
            "game_data": json.dumps({
                "prot": 100,
                "carb": 100,
                "lipid": 100,
                "description": "Полное пополнение нутриентов"
            })
        },
        {
            "name": "Пополнение еды и воды",
            "description": "Восстанавливает голод и жажду динозавра до 100%",
            "item_type": ItemType.FOOD_WATER,
            "price": 30,
            "max_stack": 10,
            "game_data": json.dumps({
                "hunger": 100,
                "thirst": 100,
                "description": "Пополнение еды и воды"
            })
        }
    ]
    
    created_count = 0
    for service_data in services:
        try:
            # Проверяем, существует ли уже предмет с таким именем
            existing_items = await ItemCRUD.get_all_items(active_only=False)
            existing = next((item for item in existing_items if item['name'] == service_data['name']), None)
            
            if existing:
                # Если существует, обновляем его
                await ItemCRUD.update_item(existing['id'], {
                    'description': service_data['description'],
                    'price': service_data['price'],
                    'max_stack': service_data['max_stack'],
                    'game_data': service_data['game_data'],
                    'is_active': True
                })
                print(f"✅ Обновлен: {service_data['name']} - {service_data['price']} ТС")
            else:
                # Если не существует, создаем новый
                item = await ItemCRUD.create_item(**service_data)
                print(f"✅ Создан: {item['name']} - {item['price']} ТС")
            
            created_count += 1
            
        except Exception as e:
            print(f"❌ Ошибка создания/обновления '{service_data['name']}': {e}")
    
    print(f"\n🎉 Обновление завершено!")
    print(f"📦 Создано/обновлено услуг: {created_count}")
    print("💡 Теперь в категории 'Услуги' будут только два предмета")


if __name__ == "__main__":
    asyncio.run(update_services())

