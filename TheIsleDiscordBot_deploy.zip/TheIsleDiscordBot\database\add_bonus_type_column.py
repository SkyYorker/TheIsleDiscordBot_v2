"""
Миграция: добавление колонки bonus_type в таблицу role_bonus_usage
"""
import asyncio
import logging
from sqlalchemy import text
from database import engine

logger = logging.getLogger(__name__)


async def add_bonus_type_column():
    """Добавляет колонку bonus_type в таблицу role_bonus_usage если её нет"""
    try:
        async with engine.begin() as conn:
            # Проверяем, существует ли колонка bonus_type
            result = await conn.execute(text(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='role_bonus_usage'"
            ))
            table_info = result.fetchone()
            
            if table_info and table_info[0]:
                table_sql = table_info[0]
                if 'bonus_type' not in table_sql:
                    logger.info("Добавление колонки bonus_type в таблицу role_bonus_usage...")
                    
                    # Для SQLite нужно пересоздать таблицу
                    # Сначала создаем новую таблицу с нужной структурой
                    await conn.execute(text("""
                        CREATE TABLE role_bonus_usage_new (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            discord_id INTEGER NOT NULL,
                            role_name TEXT NOT NULL,
                            bonus_type TEXT NOT NULL DEFAULT 'growth',
                            used_at TIMESTAMP NOT NULL,
                            week_start TIMESTAMP NOT NULL
                        )
                    """))
                    
                    # Копируем данные из старой таблицы (устанавливаем 'growth' как значение по умолчанию)
                    await conn.execute(text("""
                        INSERT INTO role_bonus_usage_new (id, discord_id, role_name, bonus_type, used_at, week_start)
                        SELECT id, discord_id, role_name, 'growth', used_at, week_start
                        FROM role_bonus_usage
                    """))
                    
                    # Удаляем старую таблицу
                    await conn.execute(text("DROP TABLE role_bonus_usage"))
                    
                    # Переименовываем новую таблицу
                    await conn.execute(text("ALTER TABLE role_bonus_usage_new RENAME TO role_bonus_usage"))
                    
                    # Создаем индексы
                    await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_role_bonus_usage_discord_id ON role_bonus_usage(discord_id)"))
                    await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_role_bonus_usage_used_at ON role_bonus_usage(used_at)"))
                    await conn.execute(text("CREATE INDEX IF NOT EXISTS ix_role_bonus_usage_week_start ON role_bonus_usage(week_start)"))
                    
                    logger.info("✅ Колонка bonus_type успешно добавлена в таблицу role_bonus_usage")
                else:
                    logger.info("✅ Колонка bonus_type уже существует в таблице role_bonus_usage")
            else:
                logger.warning("⚠️ Таблица role_bonus_usage не найдена. Она будет создана при следующей инициализации.")
                
    except Exception as e:
        logger.error(f"❌ Ошибка при добавлении колонки bonus_type: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(add_bonus_type_column())

