"""
Discord команды для автоматизации через RCON
Teleport, Set Growth, Give Item - полная автоматизация
"""

import discord
from discord.ext import commands
# Option будет доступен после патча в main.py
try:
    from discord.app_commands import Option
except ImportError:
    from discord.ext.commands import Option
import aiohttp
import logging
from utils.rcon_http_client import RCON_API_URL, RCON_API_KEY

logger = logging.getLogger(__name__)


class AutomationCog(commands.Cog):
    """Автоматизация команд через RCON API"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.slash_command(
        name="auto_growth",
        description="Автоматическая установка роста динозавра (0.0-1.0)"
    )
    @commands.has_permissions(administrator=True)
    async def auto_growth(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        growth: Option(float, "Рост (0.0 = 0%, 1.0 = 100%)", min_value=0.0, max_value=1.0),
        server_id: Option(int, "ID сервера", default=4, min_value=1, max_value=4)
    ):
        """Автоматическая установка роста через RCON"""
        
        try:
            await ctx.response.defer()
            
            # Отправляем команду через RCON API
            async with aiohttp.ClientSession() as session:
                data = {
                    "server_id": server_id,
                    "command": f"setgrowth {discord_user.display_name} {growth}",
                    "api_key": RCON_API_KEY
                }
                
                async with session.post(
                    f"{RCON_API_URL}/api/rcon/command",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    result = await resp.json()
                    
                    if resp.status == 200 and result.get('status'):
                        embed = discord.Embed(
                            title="✅ Рост установлен автоматически",
                            description=f"Рост динозавра **{discord_user.mention}** установлен на **{growth*100:.1f}%**",
                            color=discord.Color.green()
                        )
                        embed.add_field(
                            name="👤 Игрок",
                            value=f"{discord_user.display_name}",
                            inline=True
                        )
                        embed.add_field(
                            name="📊 Рост",
                            value=f"{growth*100:.1f}%",
                            inline=True
                        )
                        embed.add_field(
                            name="🖥️ Сервер",
                            value=f"#{server_id}",
                            inline=True
                        )
                    else:
                        embed = discord.Embed(
                            title="❌ Ошибка",
                            description=result.get('message', 'Неизвестная ошибка'),
                            color=discord.Color.red()
                        )
                    
                    await ctx.followup.send(embed=embed)
                    
        except Exception as e:
            logger.error(f"Error in auto_growth: {e}", exc_info=True)
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )
    
    @commands.slash_command(
        name="auto_teleport",
        description="Автоматический телепорт игрока на координаты"
    )
    @commands.has_permissions(administrator=True)
    async def auto_teleport(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        x: Option(float, "Координата X"),
        y: Option(float, "Координата Y"),
        z: Option(float, "Координата Z"),
        server_id: Option(int, "ID сервера", default=4, min_value=1, max_value=4)
    ):
        """Автоматический телепорт через RCON"""
        
        try:
            await ctx.response.defer()
            
            # Отправляем команду через RCON API
            async with aiohttp.ClientSession() as session:
                data = {
                    "server_id": server_id,
                    "command": f"teleport {discord_user.display_name} {x} {y} {z}",
                    "api_key": RCON_API_KEY
                }
                
                async with session.post(
                    f"{RCON_API_URL}/api/rcon/command",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    result = await resp.json()
                    
                    if resp.status == 200 and result.get('status'):
                        embed = discord.Embed(
                            title="✅ Телепорт выполнен автоматически",
                            description=f"Игрок **{discord_user.mention}** телепортирован на координаты **({x:.1f}, {y:.1f}, {z:.1f})**",
                            color=discord.Color.green()
                        )
                        embed.add_field(
                            name="👤 Игрок",
                            value=f"{discord_user.display_name}",
                            inline=True
                        )
                        embed.add_field(
                            name="📍 Координаты",
                            value=f"X: {x:.1f}\nY: {y:.1f}\nZ: {z:.1f}",
                            inline=True
                        )
                        embed.add_field(
                            name="🖥️ Сервер",
                            value=f"#{server_id}",
                            inline=True
                        )
                    else:
                        embed = discord.Embed(
                            title="❌ Ошибка",
                            description=result.get('message', 'Неизвестная ошибка'),
                            color=discord.Color.red()
                        )
                    
                    await ctx.followup.send(embed=embed)
                    
        except Exception as e:
            logger.error(f"Error in auto_teleport: {e}", exc_info=True)
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )
    
    @commands.slash_command(
        name="auto_give_item",
        description="Автоматическая выдача предмета игроку"
    )
    @commands.has_permissions(administrator=True)
    async def auto_give_item(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        item_name: Option(str, "Название предмета"),
        quantity: Option(int, "Количество", min_value=1, max_value=100, default=1),
        server_id: Option(int, "ID сервера", default=4, min_value=1, max_value=4)
    ):
        """Автоматическая выдача предметов через RCON"""
        
        try:
            await ctx.response.defer()
            
            # Отправляем команду через RCON API
            async with aiohttp.ClientSession() as session:
                data = {
                    "server_id": server_id,
                    "command": f"giveitem {discord_user.display_name} {item_name} {quantity}",
                    "api_key": RCON_API_KEY
                }
                
                async with session.post(
                    f"{RCON_API_URL}/api/rcon/command",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    result = await resp.json()
                    
                    if resp.status == 200 and result.get('status'):
                        embed = discord.Embed(
                            title="✅ Предмет выдан автоматически",
                            description=f"Игроку **{discord_user.mention}** выдано **{quantity}x {item_name}**",
                            color=discord.Color.green()
                        )
                        embed.add_field(
                            name="👤 Игрок",
                            value=f"{discord_user.display_name}",
                            inline=True
                        )
                        embed.add_field(
                            name="🎁 Предмет",
                            value=f"{item_name} x{quantity}",
                            inline=True
                        )
                        embed.add_field(
                            name="🖥️ Сервер",
                            value=f"#{server_id}",
                            inline=True
                        )
                    else:
                        embed = discord.Embed(
                            title="❌ Ошибка",
                            description=result.get('message', 'Неизвестная ошибка'),
                            color=discord.Color.red()
                        )
                    
                    await ctx.followup.send(embed=embed)
                    
        except Exception as e:
            logger.error(f"Error in auto_give_item: {e}", exc_info=True)
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )


async def setup(bot):
    await bot.add_cog(AutomationCog(bot))
