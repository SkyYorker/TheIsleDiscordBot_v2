"""
HTTP клиент для RCON API
Используется для отправки команд на игровой сервер через HTTP вместо прямого RCON
"""

import aiohttp
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

# Настройки API
RCON_API_URL = "http://localhost:8080"  # URL вашего RCON HTTP API
RCON_API_KEY = "your_secret_api_key_here"  # Тот же ключ что в rcon_http_api.py


class RCONHttpClient:
    """HTTP клиент для взаимодействия с RCON API"""
    
    @staticmethod
    async def send_command(server_id: int, command: str, content: str = "") -> Dict[str, Any]:
        """
        Отправить RCON команду на сервер
        
        Args:
            server_id: ID сервера (1-4)
            command: Команда (например: "say", "announce", "kick")
            content: Содержимое команды (опционально)
        
        Returns:
            dict: {"status": bool, "message": str, "response": str}
        """
        url = f"{RCON_API_URL}/api/rcon/command"
        data = {
            "server_id": server_id,
            "command": command,
            "content": content,
            "api_key": RCON_API_KEY
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    result = await resp.json()
                    logger.info(f"[RCON API] Команда '{command}' отправлена на сервер {server_id}")
                    return result
        except aiohttp.ClientError as e:
            logger.error(f"[RCON API] Ошибка подключения: {e}")
            return {"status": False, "message": f"Ошибка подключения к RCON API: {e}"}
        except Exception as e:
            logger.error(f"[RCON API] Неожиданная ошибка: {e}")
            return {"status": False, "message": f"Ошибка: {e}"}
    
    @staticmethod
    async def send_announce(server_id: int, message: str) -> Dict[str, Any]:
        """
        Отправить анонс на сервер
        
        Args:
            server_id: ID сервера (1-4)
            message: Текст анонса
        
        Returns:
            dict: {"status": bool, "message": str}
        """
        url = f"{RCON_API_URL}/api/rcon/announce"
        data = {
            "server_id": server_id,
            "message": message,
            "api_key": RCON_API_KEY
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    result = await resp.json()
                    logger.info(f"[RCON API] Анонс отправлен на сервер {server_id}: {message[:50]}...")
                    return result
        except aiohttp.ClientError as e:
            logger.error(f"[RCON API] Ошибка подключения: {e}")
            return {"status": False, "message": f"Ошибка подключения к RCON API: {e}"}
        except Exception as e:
            logger.error(f"[RCON API] Неожиданная ошибка: {e}")
            return {"status": False, "message": f"Ошибка: {e}"}
    
    @staticmethod
    async def get_players(server_id: int) -> List[str]:
        """
        Получить список игроков онлайн
        
        Args:
            server_id: ID сервера (1-4)
        
        Returns:
            list: Список имен игроков
        """
        url = f"{RCON_API_URL}/api/rcon/players"
        data = {
            "server_id": server_id,
            "api_key": RCON_API_KEY
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    result = await resp.json()
                    
                    if result.get('status'):
                        players = result.get('players_array', [])
                        logger.info(f"[RCON API] Получен список игроков: {len(players)} онлайн")
                        return players
                    else:
                        logger.warning(f"[RCON API] Не удалось получить список игроков: {result.get('message')}")
                        return []
        except aiohttp.ClientError as e:
            logger.error(f"[RCON API] Ошибка подключения: {e}")
            return []
        except Exception as e:
            logger.error(f"[RCON API] Неожиданная ошибка: {e}")
            return []
    
    @staticmethod
    async def get_player_count(server_id: int) -> int:
        """
        Получить количество игроков онлайн
        
        Args:
            server_id: ID сервера (1-4)
        
        Returns:
            int: Количество игроков
        """
        players = await RCONHttpClient.get_players(server_id)
        return len(players)
    
    @staticmethod
    async def kick_player(server_id: int, player_name: str, reason: str = "Kicked by admin") -> Dict[str, Any]:
        """
        Кикнуть игрока с сервера
        
        Args:
            server_id: ID сервера (1-4)
            player_name: Имя игрока
            reason: Причина кика
        
        Returns:
            dict: {"status": bool, "message": str}
        """
        return await RCONHttpClient.send_command(
            server_id=server_id,
            command="kick",
            content=f"{player_name},{reason}"
        )
    
    @staticmethod
    async def ban_player(server_id: int, player_name: str, reason: str = "Banned by admin", duration: int = 0) -> Dict[str, Any]:
        """
        Забанить игрока
        
        Args:
            server_id: ID сервера (1-4)
            player_name: Имя игрока
            reason: Причина бана
            duration: Длительность бана в минутах (0 = перманентный)
        
        Returns:
            dict: {"status": bool, "message": str}
        """
        return await RCONHttpClient.send_command(
            server_id=server_id,
            command="ban",
            content=f"{player_name},{reason},{duration}"
        )
    
    @staticmethod
    async def save_server(server_id: int) -> Dict[str, Any]:
        """
        Сохранить состояние сервера
        
        Args:
            server_id: ID сервера (1-4)
        
        Returns:
            dict: {"status": bool, "message": str}
        """
        return await RCONHttpClient.send_command(
            server_id=server_id,
            command="save"
        )
    
    @staticmethod
    async def check_api_health() -> bool:
        """
        Проверить доступность RCON API
        
        Returns:
            bool: True если API доступен
        """
        url = f"{RCON_API_URL}/health"
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    result = await resp.json()
                    return result.get('status') == 'ok'
        except Exception as e:
            logger.error(f"[RCON API] API недоступен: {e}")
            return False

