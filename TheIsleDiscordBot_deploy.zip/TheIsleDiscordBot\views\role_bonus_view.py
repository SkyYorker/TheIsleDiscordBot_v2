import logging
from typing import Optional, Dict, Any, List

import discord
from discord.ui import View, Button

from database.crud import RoleBonusCRUD, PlayerDinoCRUD, ROLE_BONUS_CONFIG
from utils.scripts import restore_all_dino, give_nutrients
from utils.clicker_api import restore_dino
from utils.steam_api import steam_api

logger = logging.getLogger(__name__)


class RoleBonusView(View):
    """View для бонусов за роли Discord (Первопроходец и Nitro Booster)"""
    
    def __init__(self, main_menu_embed: discord.Embed, main_menu_view):
        super().__init__(timeout=None)
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        
        self.add_item(Button(
            label="Пополнение всех характеристик",
            style=discord.ButtonStyle.green,
            emoji="✨",
            custom_id="restore_all",
            row=0
        ))
        
        self.add_item(Button(
            label="Рост на динозавра",
            style=discord.ButtonStyle.green,
            emoji="📈",
            custom_id="growth_dino",
            row=0
        ))
        
        self.add_item(Button(
            label="Пополнение нутриентов",
            style=discord.ButtonStyle.green,
            emoji="💊",
            custom_id="nutrients",
            row=1
        ))
        
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.grey,
            emoji="🏠",
            custom_id="back_to_menu",
            row=1
        ))
    
    def get_user_roles(self, interaction: discord.Interaction) -> List[str]:
        """Получить список ролей пользователя с учетом флага premium_subscriber"""
        user_roles = [role.name for role in interaction.user.roles]
        # Также проверяем, является ли роль бустером через флаг is_premium_subscriber
        user_role_objects = list(interaction.user.roles)
        has_booster_role = any(role.is_premium_subscriber() for role in user_role_objects)
        
        # Если есть флаг premium_subscriber, но нет роли "Nitro Booster", добавляем её
        if has_booster_role and "Nitro Booster" not in user_roles:
            user_roles.append("Nitro Booster")
        
        return user_roles
    
    def get_role_for_bonus(self, user_roles: List[str], bonus_type: str) -> Optional[str]:
        """Получить роль, которая дает доступ к бонусу (приоритет: Nitro Booster > Первопроходец)"""
        # Приоритет ролей
        priority_roles = ["Nitro Booster", "Первопроходец"]
        
        for role_name in priority_roles:
            if role_name in user_roles:
                role_bonuses = ROLE_BONUS_CONFIG.get(role_name, {})
                if role_bonuses.get(bonus_type, 0) > 0:
                    return role_name
        
        return None
    
    async def check_bonus_availability(self, interaction: discord.Interaction, bonus_type: str) -> Dict[str, Any]:
        """
        Проверяет доступность конкретного типа бонуса для пользователя
        
        Args:
            interaction: Discord interaction
            bonus_type: Тип бонуса ("growth", "full_restore", "nutrients")
        
        Returns:
            {
                "is_free": bool,
                "role_name": Optional[str],
                "error": Optional[str],
                "current_uses": int,
                "max_uses": int
            }
        """
        user_roles = self.get_user_roles(interaction)
        
        logger.info(f"[RoleBonusView] Проверка бонуса '{bonus_type}' для пользователя {interaction.user.id} ({interaction.user.name})")
        logger.info(f"[RoleBonusView] Роли пользователя: {user_roles}")
        
        # Проверяем доступность бонуса
        can_use, current_uses, max_uses, error = await RoleBonusCRUD.can_use_bonus(
            interaction.user.id, user_roles, bonus_type
        )
        
        # Получаем роль для записи использования
        role_name = self.get_role_for_bonus(user_roles, bonus_type)
        
        return {
            "is_free": can_use,
            "role_name": role_name,
            "error": error,
            "current_uses": current_uses,
            "max_uses": max_uses
        }
    
    @property
    def embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="Подписки",
            description="""# 🎁 Бонусы за роли

Бесплатные бонусы для обладателей специальных ролей Discord

## Доступные роли:

- @Первопроходец - рост на любого динозавра + пополнение нутриентов.

- @Nitro Booster - рост на любого динозавра (2 шт.) + пополнение всех характеристик (2 шт).

*Роль Nitro Booster автоматически выдается пользователям, которые бустят наш сервер Discord.* 

*Роль Первопроходец можно было получить ограниченно в первый месяц после старта сервера. На данный момент не выдётся.*



Доступные действия:

### ✨ Восстановление всех характеристик динозавра:

- ❤️ Здоровье (HP) - 100%

- 🍖 Голод - 100%

- 💧 Жажда - 100%

- 💊 Нутриенты - 100%

### ✨ Гров на любого динозавра:

- ⬆️ Рост - 98% (не 100%, чтобы успеть выбрать мутации)

- 🍖 Голод - 50%

- 💧 Жажда - 50%

## Как использовать:

Убедитесь, что у вас есть одна из ролей выше

Нажмите на нужную кнопку внизу

Бонус будет применен к вашему текущему динозавру в игре



Радуйтесь!:)""",
            color=discord.Color.gold()
        )
        embed.set_footer(text="💡 Бонусы работают только если вы находитесь в игре. Лимиты обновляются раз в неделю.")
        return embed
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        if custom_id == "restore_all":
            await interaction.response.defer(ephemeral=True)
            
            # Проверяем доступность бонуса "full_restore"
            bonus_info = await self.check_bonus_availability(interaction, "full_restore")
            
            if not bonus_info["is_free"]:
                embed = discord.Embed(
                    title="❌ Бонус недоступен",
                    description=bonus_info.get("error", "У вас нет доступа к этому бонусу"),
                    color=discord.Color.red()
                )
                if bonus_info["max_uses"] > 0:
                    embed.add_field(
                        name="📊 Статистика",
                        value=f"Использовано: {bonus_info['current_uses']}/{bonus_info['max_uses']}",
                        inline=False
                    )
                else:
                    user_roles = self.get_user_roles(interaction)
                    if user_roles:
                        embed.add_field(
                            name="🔍 Ваши роли",
                            value=", ".join(user_roles[:10]) + ("..." if len(user_roles) > 10 else ""),
                            inline=False
                        )
                    embed.add_field(
                        name="💡 Требуемые роли",
                        value="• **Nitro Booster** - 2× пополнение всех характеристик в неделю",
                        inline=False
                    )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return False
            
            # Полное восстановление всех характеристик
            success, error = await restore_all_dino(interaction.user.id)
            
            if success:
                # Записываем использование
                await RoleBonusCRUD.record_bonus_usage(
                    interaction.user.id, 
                    bonus_info["role_name"], 
                    "full_restore"
                )
                
                embed = discord.Embed(
                    title="✅ Пополнение всех характеристик выполнено",
                    description=f"Все характеристики вашего динозавра восстановлены до максимума!\n\n"
                                f"**Восстановлено:**\n"
                                f"❤️ Здоровье (HP) - 100%\n"
                                f"🍖 Голод - 100%\n"
                                f"💧 Жажда - 100%\n"
                                f"💊 Нутриенты - 100%\n"
                                f"⚡ Стамина - 100%\n\n"
                                + (f"**Использовано бонусов:** {bonus_info['current_uses'] + 1}/{bonus_info['max_uses']}" if bonus_info['max_uses'] < 999 else "**Лимиты:** Без ограничений"),
                    color=discord.Color.green()
                )
                if bonus_info["role_name"]:
                    embed.set_footer(text=f"Роль: {bonus_info['role_name']}")
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось выполнить полное восстановление.\n\n{error or 'Убедитесь, что вы находитесь в игре'}",
                    color=discord.Color.red()
                )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            return False
        
        elif custom_id == "growth_dino":
            await interaction.response.defer(ephemeral=True)
            
            # Проверяем доступность бонуса "growth"
            bonus_info = await self.check_bonus_availability(interaction, "growth")
            
            if not bonus_info["is_free"]:
                embed = discord.Embed(
                    title="❌ Бонус недоступен",
                    description=bonus_info.get("error", "У вас нет доступа к этому бонусу"),
                    color=discord.Color.red()
                )
                if bonus_info["max_uses"] > 0:
                    embed.add_field(
                        name="📊 Статистика",
                        value=f"Использовано: {bonus_info['current_uses']}/{bonus_info['max_uses']}",
                        inline=False
                    )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return False
            
            # Получаем данные игрока
            player = await PlayerDinoCRUD.get_player_info(interaction.user.id)
            if not player:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Нет привязки к Steam",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return False
            
            steam_id = player.get("player", {}).get("steam_id", "")
            if not steam_id:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Нет привязки к Steam",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return False
            
            # Применяем рост: 98% рост, 50% голод, 50% жажда
            result = await restore_dino(steam_id, growth=98, hunger=50, thirst=50, health=100)
            
            if isinstance(result, dict) and result.get("success"):
                # Записываем использование
                await RoleBonusCRUD.record_bonus_usage(
                    interaction.user.id, 
                    bonus_info["role_name"], 
                    "growth"
                )
                
                embed = discord.Embed(
                    title="✅ Гров применен",
                    description=f"Рост вашего динозавра установлен!\n\n"
                                f"**Применено:**\n"
                                f"⬆️ Рост - 98%\n"
                                f"🍖 Голод - 50%\n"
                                f"💧 Жажда - 50%\n"
                                f"❤️ Здоровье - 100%\n\n"
                                + (f"**Использовано бонусов:** {bonus_info['current_uses'] + 1}/{bonus_info['max_uses']}" if bonus_info['max_uses'] < 999 else "**Лимиты:** Без ограничений"),
                    color=discord.Color.green()
                )
                if bonus_info["role_name"]:
                    embed.set_footer(text=f"Роль: {bonus_info['role_name']}")
            else:
                error_msg = result.get("message", "Неизвестная ошибка") if isinstance(result, dict) else "Ошибка API"
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось применить гров.\n\n{error_msg}\n\nУбедитесь, что вы находитесь в игре",
                    color=discord.Color.red()
                )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            return False
        
        elif custom_id == "nutrients":
            await interaction.response.defer(ephemeral=True)
            
            # Проверяем доступность бонуса "nutrients"
            bonus_info = await self.check_bonus_availability(interaction, "nutrients")
            
            if not bonus_info["is_free"]:
                embed = discord.Embed(
                    title="❌ Бонус недоступен",
                    description=bonus_info.get("error", "У вас нет доступа к этому бонусу"),
                    color=discord.Color.red()
                )
                if bonus_info["max_uses"] > 0:
                    embed.add_field(
                        name="📊 Статистика",
                        value=f"Использовано: {bonus_info['current_uses']}/{bonus_info['max_uses']}",
                        inline=False
                    )
                else:
                    user_roles = self.get_user_roles(interaction)
                    if user_roles:
                        embed.add_field(
                            name="🔍 Ваши роли",
                            value=", ".join(user_roles[:10]) + ("..." if len(user_roles) > 10 else ""),
                            inline=False
                        )
                    embed.add_field(
                        name="💡 Требуемые роли",
                        value="• **Первопроходец** - 1× пополнение нутриентов в неделю",
                        inline=False
                    )
                await interaction.followup.send(embed=embed, ephemeral=True)
                return False
            
            # Пополнение нутриентов
            success, error = await give_nutrients(interaction.user.id)
            
            if success:
                # Записываем использование
                await RoleBonusCRUD.record_bonus_usage(
                    interaction.user.id, 
                    bonus_info["role_name"], 
                    "nutrients"
                )
                
                embed = discord.Embed(
                    title="✅ Нутриенты пополнены",
                    description=f"Все нутриенты вашего динозавра восстановлены до максимума!\n\n"
                                f"**Восстановлено:**\n"
                                f"💊 Белки - 100%\n"
                                f"💊 Углеводы - 100%\n"
                                f"💊 Жиры - 100%\n\n"
                                + (f"**Использовано бонусов:** {bonus_info['current_uses'] + 1}/{bonus_info['max_uses']}" if bonus_info['max_uses'] < 999 else "**Лимиты:** Без ограничений"),
                    color=discord.Color.green()
                )
                if bonus_info["role_name"]:
                    embed.set_footer(text=f"Роль: {bonus_info['role_name']}")
            else:
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось пополнить нутриенты.\n\n{error or 'Убедитесь, что вы находитесь в игре'}",
                    color=discord.Color.red()
                )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            return False
        
        elif custom_id == "back_to_menu":
            from views.main_menu import MainMenuView
            
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = MainMenuView(steam_data, interaction.user.id)
            await view.update_player_data(interaction.user.id)
            await interaction.response.edit_message(embed=view.embed, view=view, content=None)
        
        return False

