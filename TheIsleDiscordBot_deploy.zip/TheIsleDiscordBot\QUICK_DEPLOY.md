# Быстрый деплой бота на сервер

## 🚀 Автоматический деплой (рекомендуется)

### Первая установка:

```powershell
# Перейдите в папку, где хотите разместить бота
cd C:\Servers\servers

# Запустите скрипт деплоя
.\TheIsleDiscordBot\deploy.ps1 -ServerPath "C:\Servers\servers\TheIsleDiscordBot"
```

Или просто скопируйте `deploy.ps1` на сервер и запустите:

```powershell
.\deploy.ps1
```

### Обновление существующей версии:

```powershell
cd C:\Servers\servers\TheIsleDiscordBot
.\deploy.ps1 -Update
```

## 📋 Что делает скрипт:

1. ✅ Клонирует репозиторий из Git
2. ✅ Создает виртуальное окружение
3. ✅ Устанавливает все зависимости
4. ✅ Проверяет наличие .env и main.db
5. ✅ Создает бэкап БД при обновлении

## 🔧 Ручной деплой (если скрипт не работает)

### 1. Клонирование репозитория:

```powershell
cd C:\Servers\servers
git clone https://github.com/SkyYorker/TheIsleDiscordBot.git TheIsleDiscordBot
cd TheIsleDiscordBot
```

### 2. Настройка окружения:

```powershell
# Создать виртуальное окружение
python -m venv .venv

# Активировать
.\.venv\Scripts\Activate.ps1

# Установить зависимости
pip install -r requirements.txt
```

### 3. Копирование данных:

```powershell
# Скопировать БД из старой версии (если есть)
Copy-Item "C:\Servers\servers\TheIsleDiscordBot_old\main.db" -Destination ".\main.db"

# Скопировать .env (если есть)
Copy-Item "C:\Servers\servers\TheIsleDiscordBot_old\.env" -Destination ".\.env"
```

### 4. Запуск:

```powershell
.\start_bot.ps1
```

## 🔄 Обновление через Git

Если бот уже запущен из Git репозитория:

```powershell
cd C:\Servers\servers\TheIsleDiscordBot

# Остановите бота (Ctrl+C в окне, где он запущен)

# Обновите код
git pull origin master

# Перезапустите бота
.\start_bot.ps1
```

## ⚙️ Настройка .env файла

Создайте файл `.env` в папке бота со следующим содержимым:

```env
DISCORD_TOKEN=ваш_основной_токен
TEST_DISCORD_TOKEN=ваш_тестовый_токен (опционально)
RCON_HOST=адрес_сервера
RCON_PORT=порт
RCON_PASSWORD=пароль
# ... другие переменные
```

## 📝 Примечания

- Скрипт автоматически создает бэкап БД при обновлении
- Убедитесь, что Git установлен на сервере
- Убедитесь, что Python установлен и доступен в PATH
- При первой установке нужно настроить `.env` файл вручную

## 🆘 Решение проблем

### Ошибка "git не найден":
Установите Git: https://git-scm.com/download/win

### Ошибка "python не найден":
Убедитесь, что Python установлен и добавлен в PATH

### Ошибка при клонировании:
Проверьте, что репозиторий публичный или используйте токен доступа:
```powershell
.\deploy.ps1 -GitRepo "https://ВАШ_ТОКЕН@github.com/SkyYorker/TheIsleDiscordBot.git"
```

