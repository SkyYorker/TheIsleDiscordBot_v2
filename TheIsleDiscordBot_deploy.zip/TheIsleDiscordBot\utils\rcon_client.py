#!/usr/bin/env python3
"""
Стандартизированный RCON клиент для The Isle
Объединяет лучшие практики из всех существующих RCON файлов
"""

import asyncio
import logging
import time
import json
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
import os

# Используем проверенный RCON клиент
try:
    from gamercon_async import EvrimaRCON
except ImportError:
    print("ERROR: gamercon_async not installed. Install with: pip install gamercon-async")
    exit(1)

logger = logging.getLogger(__name__)

class RCONCommandType(Enum):
    """Типы RCON команд"""
    LIST_PLAYERS = "listplayers"
    SAVE_GAME = "save"
    BROADCAST = "broadcast"
    TELEPORT = "teleport"
    SET_HEALTH = "sethealth"
    SET_HUNGER = "sethunger"
    SET_THIRST = "setthirst"
    SET_STAMINA = "setstamina"
    KICK_PLAYER = "kick"
    BAN_PLAYER = "ban"
    CUSTOM = "custom"

@dataclass
class PlayerData:
    """Данные игрока"""
    name: Optional[str] = None
    player_id: Optional[str] = None
    location: Optional[Dict[str, float]] = None
    dino_class: Optional[str] = None
    growth: Optional[float] = None
    health: Optional[float] = None
    stamina: Optional[float] = None
    hunger: Optional[float] = None
    thirst: Optional[float] = None

    def __str__(self):
        return f"PlayerData(name={self.name}, player_id={self.player_id}, dino_class={self.dino_class})"

@dataclass
class RCONResponse:
    """Стандартизированный ответ RCON"""
    success: bool
    data: Any = None
    error: Optional[str] = None
    command: Optional[str] = None
    execution_time: Optional[float] = None

class TheIsleRCONClient:
    """
    Стандартизированный RCON клиент для The Isle
    Надежный, с обработкой ошибок и автоматическим реконнектом
    """

    def __init__(self, host: str, port: int, password: str):
        self.host = host
        self.port = port
        self.password = password

        self.rcon: Optional[EvrimaRCON] = None
        self.connected = False
        self.last_connection_attempt = 0
        self.reconnect_delay = 5  # секунд между попытками подключения
        self.max_reconnect_attempts = 3

        # Статистика
        self.stats = {
            "total_commands": 0,
            "successful_commands": 0,
            "failed_commands": 0,
            "total_reconnects": 0,
            "uptime_start": time.time()
        }

        # Команды для форматирования
        self.command_formats = {
            RCONCommandType.LIST_PLAYERS: b"\x02\x77\x00",
            RCONCommandType.SAVE_GAME: b"save\x00",
            RCONCommandType.BROADCAST: lambda msg: f"broadcast \"{msg}\"\x00".encode(),
        }

    async def connect(self) -> bool:
        """Подключение к RCON серверу с обработкой ошибок"""
        current_time = time.time()

        # Проверяем, не слишком ли часто пытаемся подключиться
        if current_time - self.last_connection_attempt < self.reconnect_delay:
            logger.warning("Too frequent connection attempts, waiting...")
            await asyncio.sleep(self.reconnect_delay)

        self.last_connection_attempt = current_time

        try:
            logger.info(f"Connecting to RCON server at {self.host}:{self.port}")
            self.rcon = EvrimaRCON(self.host, self.port, self.password)
            await self.rcon.connect()

            self.connected = True
            self.stats["total_reconnects"] += 1
            logger.info("Successfully connected to RCON server")
            return True

        except Exception as e:
            self.connected = False
            logger.error(f"Failed to connect to RCON server: {e}")
            return False

    async def disconnect(self):
        """Безопасное отключение"""
        if self.rcon and self.connected:
            try:
                await self.rcon.disconnect()
            except Exception as e:
                logger.warning(f"Error during disconnect: {e}")
            finally:
                self.connected = False
                logger.info("Disconnected from RCON server")

    async def _ensure_connection(self) -> bool:
        """Проверяет подключение и переподключается при необходимости"""
        if not self.connected or not self.rcon:
            return await self.connect()

        # Проверяем подключение тестовым запросом
        try:
            # Отправляем пустую команду для проверки соединения
            await asyncio.wait_for(
                self.rcon.send_command(b"\x02\x77\x00"),
                timeout=5.0
            )
            return True
        except Exception as e:
            logger.warning(f"Connection test failed: {e}")
            self.connected = False
            return await self.connect()

    async def execute_command(self, command: Union[str, RCONCommandType], *args) -> RCONResponse:
        """Выполнение RCON команды с полной обработкой ошибок"""
        start_time = time.time()
        self.stats["total_commands"] += 1

        try:
            # Проверяем подключение
            if not await self._ensure_connection():
                return RCONResponse(
                    success=False,
                    error="Failed to connect to RCON server",
                    command=str(command),
                    execution_time=time.time() - start_time
                )

            # Форматируем команду
            command_bytes = self._format_command(command, *args)
            if not command_bytes:
                return RCONResponse(
                    success=False,
                    error=f"Unknown command format: {command}",
                    command=str(command),
                    execution_time=time.time() - start_time
                )

            # Выполняем команду с таймаутом
            response = await asyncio.wait_for(
                self.rcon.send_command(command_bytes),
                timeout=10.0
            )

            self.stats["successful_commands"] += 1

            return RCONResponse(
                success=True,
                data=self._parse_response(response, command),
                command=str(command),
                execution_time=time.time() - start_time
            )

        except asyncio.TimeoutError:
            self.stats["failed_commands"] += 1
            logger.error(f"RCON command timeout: {command}")
            return RCONResponse(
                success=False,
                error="Command timeout",
                command=str(command),
                execution_time=time.time() - start_time
            )

        except Exception as e:
            self.stats["failed_commands"] += 1
            logger.error(f"RCON command failed: {command} - {e}")
            self.connected = False  # Помечаем соединение как нерабочее
            return RCONResponse(
                success=False,
                error=str(e),
                command=str(command),
                execution_time=time.time() - start_time
            )

    def _format_command(self, command: Union[str, RCONCommandType], *args) -> Optional[bytes]:
        """Форматирование команды в байты"""
        if isinstance(command, RCONCommandType):
            if command == RCONCommandType.BROADCAST and args:
                return self.command_formats[command](args[0])
            elif command in self.command_formats:
                return self.command_formats[command]
        else:
            # Кастомная команда
            return f"{command}\x00".encode()

        return None

    def _parse_response(self, response: str, command: Union[str, RCONCommandType]) -> Any:
        """Парсинг ответа сервера"""
        if not response:
            return None

        # Парсим в зависимости от типа команды
        if command == RCONCommandType.LIST_PLAYERS:
            return self._parse_player_list(response)
        elif command in [RCONCommandType.SET_HEALTH, RCONCommandType.SET_HUNGER,
                         RCONCommandType.SET_THIRST, RCONCommandType.SET_STAMINA]:
            return response.strip()
        else:
            return response.strip()

    def _parse_player_list(self, response: str) -> List[PlayerData]:
        """Парсинг списка игроков"""
        import re

        players = []
        player_blocks = re.split(
            r'(?:\[\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}\]\s*)?Name: |(?:\[\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}\]\s*)?PlayerDataName: ',
            response
        )

        for block in player_blocks:
            if not block.strip():
                continue

            player = PlayerData()

            # Парсим имя
            name_match = re.search(r"Name: ([^,]+)", block)
            if not name_match:
                name_match = re.search(r"PlayerDataName: ([^,]+)", block)
            if name_match:
                player.name = name_match.group(1).strip()

            # Парсим ID игрока
            player_id_match = re.search(r"PlayerID: (\d+)", block)
            if player_id_match:
                player.player_id = player_id_match.group(1)

            # Парсим локацию
            location_match = re.search(r"Location: X=([-\d\.]+) Y=([-\d\.]+) Z=([-\d\.]+)", block)
            if location_match:
                player.location = {
                    "X": float(location_match.group(1)),
                    "Y": float(location_match.group(2)),
                    "Z": float(location_match.group(3))
                }

            # Парсим класс динозавра
            dino_class_match = re.search(r"Class: ([^,]+)", block)
            if dino_class_match:
                player.dino_class = dino_class_match.group(1)

            # Парсим статы
            def extract_float(field: str) -> Optional[float]:
                match = re.search(rf"{field}: ([\d\.]+)", block)
                return float(match.group(1)) if match else None

            player.growth = extract_float("Growth")
            player.health = extract_float("Health")
            player.stamina = extract_float("Stamina")
            player.hunger = extract_float("Hunger")
            player.thirst = extract_float("Thirst")

            if player.name or player.player_id:
                players.append(player)

        return players

    async def get_players(self) -> RCONResponse:
        """Получить список игроков"""
        return await self.execute_command(RCONCommandType.LIST_PLAYERS)

    async def save_game(self) -> RCONResponse:
        """Сохранить игру"""
        return await self.execute_command(RCONCommandType.SAVE_GAME)

    async def broadcast_message(self, message: str) -> RCONResponse:
        """Отправить сообщение всем игрокам"""
        return await self.execute_command(RCONCommandType.BROADCAST, message)

    async def heal_player(self, player_name: str) -> RCONResponse:
        """Вылечить игрока"""
        return await self.execute_command(f"sethealth {player_name} 100")

    async def feed_player(self, player_name: str) -> RCONResponse:
        """Накормить игрока"""
        return await self.execute_command(f"sethunger {player_name} 100")

    async def hydrate_player(self, player_name: str) -> RCONResponse:
        """Напоить игрока"""
        return await self.execute_command(f"setthirst {player_name} 100")

    async def restore_player(self, player_name: str) -> RCONResponse:
        """Полностью восстановить игрока"""
        commands = [
            f"sethealth {player_name} 100",
            f"sethunger {player_name} 100",
            f"setthirst {player_name} 100",
            f"setstamina {player_name} 100"
        ]

        results = []
        for cmd in commands:
            result = await self.execute_command(cmd)
            results.append(result)
            await asyncio.sleep(0.1)  # Небольшая задержка между командами

        # Возвращаем результат последней команды
        return results[-1] if results else RCONResponse(success=False, error="No commands executed")

    async def teleport_player(self, player_name: str, x: float, y: float, z: float) -> RCONResponse:
        """Телепортировать игрока"""
        return await self.execute_command(f"teleport {player_name} {x} {y} {z}")

    def get_stats(self) -> Dict[str, Any]:
        """Получить статистику работы клиента"""
        uptime = time.time() - self.stats["uptime_start"]
        success_rate = (self.stats["successful_commands"] / max(1, self.stats["total_commands"])) * 100

        return {
            "connection_status": "connected" if self.connected else "disconnected",
            "total_commands": self.stats["total_commands"],
            "successful_commands": self.stats["successful_commands"],
            "failed_commands": self.stats["failed_commands"],
            "success_rate_percent": round(success_rate, 2),
            "total_reconnects": self.stats["total_reconnects"],
            "uptime_seconds": round(uptime, 2),
            "server_info": {
                "host": self.host,
                "port": self.port
            }
        }

    async def health_check(self) -> Dict[str, Any]:
        """Проверка здоровья соединения"""
        start_time = time.time()

        try:
            # Тестовая команда для проверки соединения
            response = await self.execute_command(RCONCommandType.LIST_PLAYERS)

            return {
                "healthy": response.success,
                "response_time": response.execution_time,
                "error": response.error,
                "last_check": time.time()
            }

        except Exception as e:
            return {
                "healthy": False,
                "error": str(e),
                "response_time": time.time() - start_time,
                "last_check": time.time()
            }

# Глобальный RCON клиент для использования в проекте
_rcon_client: Optional[TheIsleRCONClient] = None

def get_rcon_client() -> TheIsleRCONClient:
    """Получить глобальный RCON клиент"""
    global _rcon_client
    if _rcon_client is None:
        # Загружаем настройки из переменных окружения
        host = os.getenv("RCON_HOST", "localhost")
        port = int(os.getenv("RCON_PORT", "24904"))
        password = os.getenv("RCON_PASSWORD", "")

        if not password:
            logger.error("RCON_PASSWORD not set in environment variables")
            raise ValueError("RCON_PASSWORD not configured")

        _rcon_client = TheIsleRCONClient(host, port, password)
        logger.info(f"RCON client initialized for {host}:{port}")

    return _rcon_client

async def initialize_rcon():
    """Инициализировать RCON соединение"""
    client = get_rcon_client()
    connected = await client.connect()

    if connected:
        logger.info("RCON client successfully connected")
    else:
        logger.error("Failed to connect RCON client")

    return connected

# Удобные функции для использования в проекте
async def rcon_command(command: Union[str, RCONCommandType], *args) -> RCONResponse:
    """Выполнить RCON команду через глобальный клиент"""
    client = get_rcon_client()
    return await client.execute_command(command, *args)

async def get_online_players() -> List[PlayerData]:
    """Получить список игроков онлайн"""
    response = await rcon_command(RCONCommandType.LIST_PLAYERS)
    if response.success and response.data:
        return response.data
    return []

async def broadcast_to_server(message: str) -> bool:
    """Отправить сообщение всем игрокам"""
    response = await rcon_command(RCONCommandType.BROADCAST, message)
    return response.success

async def save_server_world() -> bool:
    """Сохранить мир сервера"""
    response = await rcon_command(RCONCommandType.SAVE_GAME)
    return response.success

if __name__ == "__main__":
    # Тестовый пример использования
    async def test_rcon():
        client = TheIsleRCONClient("localhost", 24904, "test_password")

        # Подключаемся
        if await client.connect():
            print("Connected to RCON server")

            # Получаем список игроков
            players_response = await client.get_players()
            if players_response.success:
                players = players_response.data
                print(f"Found {len(players)} players online")
                for player in players:
                    print(f"  - {player}")
            else:
                print(f"Failed to get players: {players_response.error}")

            # Отправляем сообщение
            broadcast_response = await client.broadcast_message("Test message from RCON client")
            if broadcast_response.success:
                print("Message sent successfully")
            else:
                print(f"Failed to send message: {broadcast_response.error}")

            # Показываем статистику
            stats = client.get_stats()
            print(f"RCON Stats: {json.dumps(stats, indent=2)}")

            await client.disconnect()
        else:
            print("Failed to connect to RCON server")

    # Запускаем тест
    logging.basicConfig(level=logging.INFO)
    asyncio.run(test_rcon())