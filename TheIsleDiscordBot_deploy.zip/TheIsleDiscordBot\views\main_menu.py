import os

import discord
from discord.ui import View, Button

from database.crud import PlayerDinoCRUD, DonationCRUD, SubscriptionCRUD
from utils.rcon_isle import PlayerData
from utils.scripts import get_all_dinos, get_current_dino, kill_current_dino
from utils.steam_api import steam_api
from views.deposit_view import DepositView
from views.dino_shop import DinoShopView
from views.kill_dino_confirm import KillDinoConfirmView, kill_dino_confirm_embed
from views.save_dino import SaveDinoView
from views.subscription_management_view import SubscriptionManagementView

LOGO_URL = os.getenv("LOGO_URL")


class KillDinoResultView(View):
    def __init__(self, main_menu_embed, main_menu_view):
        super().__init__(timeout=None)
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.green,
            emoji="🏠",
            custom_id="back_to_main_menu",
            row=0
        ))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        if custom_id == "back_to_main_menu":
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = await MainMenuView.create_with_admin_check(steam_data, interaction.user.id, interaction)
            await view.update_player_data(interaction.user.id)
            await interaction.response.send_message(embed=view.embed, view=view, ephemeral=True)
            # await self.main_menu_view.update_player_data(interaction.user.id)
            # await interaction.response.edit_message(embed=self.main_menu_view.embed, view=self.main_menu_view)
        return False


class MainMenuView(View):
    def __init__(self, steam_data: dict, user_id: int, interaction: discord.Interaction = None):
        super().__init__(timeout=None)

        self.steam_data = steam_data
        self.user_id = user_id
        self.interaction = interaction

        self.subscribe = "Нет подписки"
        self.tk = 0  # Инициализируем баланс по умолчанию

        # Сохраняем статус проверки админа
        self._is_admin_checked = False
        self._is_admin_user = False
        self._admin_button_added = False

        # Row 0: Пополнить баланс, Магазинчик, Подписки, Инвентарь, Мои динозавры
        self.add_item(Button(
            label="Пополнить баланс",
            style=discord.ButtonStyle.green,
            emoji="💵",
            custom_id="deposit",
            row=0
        ))

        self.add_item(Button(
            label="Магазинчик",
            style=discord.ButtonStyle.green,
            emoji="🛒",
            custom_id="shop",
            row=0
        ))

        self.add_item(Button(
            label="Подписки",
            style=discord.ButtonStyle.blurple,
            emoji="🌟",
            custom_id="subscription_management",
            row=0
        ))

        self.add_item(Button(
            label="Инвентарь",
            style=discord.ButtonStyle.blurple,
            emoji="🎒",
            custom_id="inventory",
            row=0
        ))

        self.add_item(Button(
            label="Мои динозавры",
            style=discord.ButtonStyle.blurple,
            emoji="🦖",
            custom_id="my_dinosaurs",
            row=0
        ))

        # Row 1: Бонусы, Сохранить динозавра
        self.add_item(Button(
            label="Бонусы",
            style=discord.ButtonStyle.blurple,
            emoji="⭐",
            custom_id="role_bonuses",
            row=1
        ))

        self.add_item(Button(
            label="Сохранить динозавра",
            style=discord.ButtonStyle.grey,
            emoji="💾",
            custom_id="save_dino",
            row=1
        ))

        # Row 2: Освободить слот, Убить текущего динозавра
        self.add_item(Button(
            label="Освободить слот",
            style=discord.ButtonStyle.red,
            emoji="🗑️",
            custom_id="delete_dino",
            row=2
        ))

        self.add_item(Button(
            label="Убить текущего динозавра",
            style=discord.ButtonStyle.red,
            emoji="💀",
            custom_id="kill_current_dino",
            row=2
        ))

        # Row 3: Бонус-коды, Бонус-коды (админ), Закрыть, Выйти из аккаунта
        # Кнопка "Бонус-коды" для всех пользователей (применение кодов)
        self.add_item(Button(
            label="Бонус-коды",
            style=discord.ButtonStyle.green,
            emoji="🎁",
            custom_id="bonus_codes",
            row=3
        ))

        # Кнопка "Бонус-коды (админ)" только для админов (создание кодов)
        # Проверяем админа сразу, если interaction доступен
        if self.interaction and self.interaction.guild:
            # Синхронная проверка (быстрая, но может не сработать без интентов)
            if self._is_admin():
                self._is_admin_user = True
                self._is_admin_checked = True
                self._add_admin_button()

        self.add_item(Button(
            label="Закрыть",
            style=discord.ButtonStyle.grey,
            emoji="❌",
            custom_id="close",
            row=3
        ))

        self.add_item(Button(
            label="Выйти из аккаунта",
            style=discord.ButtonStyle.red,
            emoji="🚪",
            custom_id="logout",
            row=3
        ))

    def _add_admin_button(self):
        """Добавляет кнопку админа, если она еще не добавлена"""
        if not self._admin_button_added:
            # Проверяем, нет ли уже такой кнопки
            for item in self.children:
                if isinstance(item, Button) and item.custom_id == "bonus_codes_admin":
                    self._admin_button_added = True
                    return
            
            self.add_item(Button(
                label="Бонус-коды (админ)",
                style=discord.ButtonStyle.red,
                emoji="🎁",
                custom_id="bonus_codes_admin",
                row=3
            ))
            self._admin_button_added = True
    
    @staticmethod
    async def create_with_admin_check(steam_data: dict, user_id: int, interaction: discord.Interaction):
        """Создает MainMenuView с проверкой админа"""
        view = MainMenuView(steam_data, user_id, interaction)
        
        # Если синхронная проверка не сработала, проверяем асинхронно
        if not view._is_admin_checked and interaction and interaction.guild:
            is_admin = await view._is_admin_async(interaction)
            view._is_admin_user = is_admin
            view._is_admin_checked = True
            if is_admin:
                view._add_admin_button()
        
        return view

    def _is_admin(self) -> bool:
        """Проверка прав администратора"""
        if not self.interaction or not self.interaction.guild:
            return False
        
        try:
            user = self.interaction.user
            guild = self.interaction.guild
            
            # 1. Проверяем напрямую через interaction.user (самый быстрый способ)
            if isinstance(user, discord.Member):
                if hasattr(user, 'guild_permissions') and user.guild_permissions:
                    if user.guild_permissions.administrator:
                        return True
            
            # 2. Проверяем владельца сервера (не требует интентов)
            if hasattr(guild, 'owner_id') and guild.owner_id == self.user_id:
                return True
            
            # 3. Проверяем через get_member (может работать без интентов для кэшированных участников)
            try:
                member = guild.get_member(self.user_id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (AttributeError, TypeError):
                pass
                
        except Exception as e:
            # Логируем ошибку для отладки
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"Ошибка при проверке прав администратора: {e}")
        
        return False
    
    async def _is_admin_async(self, interaction: discord.Interaction) -> bool:
        """Асинхронная проверка прав администратора с fetch_member"""
        if not interaction or not interaction.guild:
            return False
        
        try:
            user = interaction.user
            guild = interaction.guild
            
            # 1. Проверяем напрямую через interaction.user
            if isinstance(user, discord.Member):
                if hasattr(user, 'guild_permissions') and user.guild_permissions:
                    if user.guild_permissions.administrator:
                        return True
            
            # 2. Проверяем владельца сервера
            if hasattr(guild, 'owner_id') and guild.owner_id == user.id:
                return True
            
            # 3. Пытаемся получить участника через fetch_member (требует интент GUILD_MEMBERS)
            try:
                member = await guild.fetch_member(user.id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (discord.Forbidden, discord.HTTPException, AttributeError, TypeError):
                # Если нет прав или участник не найден, продолжаем
                pass
            
            # 4. Проверяем через get_member (кэшированные участники)
            try:
                member = guild.get_member(user.id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (AttributeError, TypeError):
                pass
                
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.debug(f"Ошибка при асинхронной проверке прав администратора: {e}")
        
        return False

    async def update_player_data(self, user_id: int):
        updated_data = await DonationCRUD.get_tk(user_id)
        if updated_data is not None:
            self.tk = updated_data
        sub = await SubscriptionCRUD.get_active_subscription(user_id)
        if sub:
            self.subscribe = sub.get("tier", "Нет подписки")

    @property
    def embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="👥 Профиль пользователя",
            description=(
                f"―――――――――――――――――――\n"
                f"`ℹ️` Steam nick: `{self.steam_data.get('username', 'Неизвестно')}`\n"
                f"`🆔` DiscordID: `{self.user_id}`\n"
                f"`🆔` SteamID: `{self.steam_data.get('steamid', 'Неизвестно')}`\n"
                f"`🌐` [__Открыть профиль Steam__](https://steamcommunity.com/profiles/{self.steam_data.get('steamid', '')})\n"
                f"\n"
                f"―――――――――――――――――――\n"
                f"🪙 **Количество TC:** `{self.tk}`\n"
                f"🔅 **Подписка:** `{self.subscribe}`\n"
                f"―――――――――――――――――――\n"
            ),
            color=discord.Color.green()
        )
        if LOGO_URL:
            embed.set_image(url=LOGO_URL)
        embed.set_thumbnail(url=self.steam_data.get("avatar"))
        embed.set_footer(text="🔗 Используйте кнопки ниже для использования функционала бота и управления профилем ")
        return embed

    async def kill_dino_confirm_callback(self, interaction: discord.Interaction, dino_data: PlayerData):
        await interaction.response.defer()

        try:
            result = await kill_current_dino(interaction.user.id)
            if result is True:
                embed = discord.Embed(
                    title="💀 Текущий динозавр убит",
                    description="Ваш текущий динозавр был убит по вашему запросу.",
                    color=discord.Color.dark_red()
                )
            else:
                # result = (None, error_message)
                embed = discord.Embed(
                    title="Ошибка",
                    description=result[1] if isinstance(result, tuple) else "Не удалось убить динозавра.",
                    color=discord.Color.orange()
                )
            kill_view = KillDinoResultView(self.embed, self)
            await interaction.followup.edit_message(interaction.message.id, embed=embed, view=kill_view)
        except Exception as e:
            error_embed = discord.Embed(
                title="Ошибка",
                description=f"Произошла ошибка при обработке запроса: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=error_embed, ephemeral=True)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        # Обновляем interaction для актуальной проверки прав
        self.interaction = interaction
        
        # Проверяем админа асинхронно при первом взаимодействии, если еще не проверили
        if not self._is_admin_checked:
            is_admin = await self._is_admin_async(interaction)
            self._is_admin_user = is_admin
            self._is_admin_checked = True
            
            # Если админ и кнопка еще не добавлена, добавляем её
            if is_admin and not self._admin_button_added:
                self._add_admin_button()
                # Обновляем сообщение, чтобы показать кнопку админа (только если еще не ответили)
                if not interaction.response.is_done():
                    try:
                        await interaction.response.edit_message(view=self)
                        return False  # Прерываем обработку, так как уже ответили
                    except:
                        pass  # Если не удалось, продолжаем обычную обработку
        # Если админ уже проверен и кнопка должна быть, но её нет - добавляем
        elif self._is_admin_user and not self._admin_button_added:
            self._add_admin_button()
        
        custom_id = interaction.data["custom_id"]

        if custom_id == "save_dino":
            view = SaveDinoView(self, interaction.message.embeds[0])
            await interaction.response.edit_message(embed=view.embed, view=view)

        elif custom_id == "delete_dino":
            # Открываем инвентарь на вкладке динозавров для удаления
            from views.inventory_view import InventoryView
            inventory_view = InventoryView(interaction.message.embeds[0], self)
            inventory_view.active_tab = "dinosaurs"
            inventory_view.dino_state = "category"
            await inventory_view.load_data(interaction.user.id)
            await interaction.response.edit_message(embed=inventory_view.embed, view=inventory_view)

        elif custom_id == "logout":
            await PlayerDinoCRUD.delete_player(interaction.user.id)
            embed = discord.Embed(
                title="🔒 Аккаунт отвязан",
                description="Ваш Steam-аккаунт успешно отвязан.",
                color=discord.Color.red()
            )
            await interaction.response.edit_message(embed=embed, view=None)

        elif custom_id == "shop":
            view = DinoShopView(interaction.message.embeds[0], self)
            await interaction.response.edit_message(embed=view.embed, view=view)

        elif custom_id == "kill_current_dino":
            current_dino = await get_current_dino(interaction.user.id)
            if not current_dino or isinstance(current_dino, tuple):
                embed = discord.Embed(
                    title="Ошибка",
                    description=current_dino[1] if isinstance(current_dino,
                                                              tuple) else "У вас нет активного динозавра.",
                    color=discord.Color.orange()
                )
                error_view = discord.ui.View(timeout=None)
                error_view.add_item(Button(
                    label="Главное меню",
                    style=discord.ButtonStyle.green,
                    emoji="🏠",
                    custom_id="back_to_main_menu",
                    row=0
                ))
                error_view.add_item(Button(
                    label="Закрыть",
                    style=discord.ButtonStyle.grey,
                    emoji="❌",
                    custom_id="close",
                    row=0
                ))

                async def error_interaction_check(interaction: discord.Interaction) -> bool:
                    custom_id = interaction.data.get("custom_id")
                    if custom_id == "back_to_main_menu":
                        steam_data = await steam_api.get_steam_data(interaction.user.id)
                        view = MainMenuView(steam_data, interaction.user.id)
                        await view.update_player_data(interaction.user.id)
                        await interaction.response.send_message(embed=view.embed, view=view, ephemeral=True)
                        # await interaction.response.edit_message(embed=self.embed, view=self)
                    elif custom_id == "close":
                        await interaction.response.defer()
                        await interaction.delete_original_response()
                    return False

                error_view.interaction_check = error_interaction_check
                await interaction.response.edit_message(embed=embed, view=error_view)
            else:
                confirm_embed = kill_dino_confirm_embed(current_dino)
                confirm_view = KillDinoConfirmView(
                    dino_data=current_dino,
                    main_menu_embed=self.embed,
                    main_menu_view=self,
                    on_confirm_callback=self.kill_dino_confirm_callback
                )
                await interaction.response.edit_message(embed=confirm_embed, view=confirm_view)
        elif custom_id == "deposit":
            deposit_view = DepositView(self.embed, self)
            await deposit_view.show_deposit_modal(interaction)
        elif custom_id == "subscription_management":
            management_view = SubscriptionManagementView(
                self.embed,
                self,
                interaction.user.id
            )
            await interaction.response.edit_message(embed=await management_view.get_embed(), view=management_view)
        elif custom_id == "inventory":
            from views.inventory_view import InventoryView
            inventory_view = InventoryView(self.embed, self)
            await inventory_view.load_inventory(interaction.user.id)
            await interaction.response.edit_message(embed=inventory_view.embed, view=inventory_view)
        
        elif custom_id == "my_dinosaurs":
            from views.inventory_view import InventoryView
            inventory_view = InventoryView(self.embed, self)
            inventory_view.active_tab = "dinosaurs"
            inventory_view.dino_state = "category"
            await inventory_view.load_data(interaction.user.id)
            await interaction.response.edit_message(embed=inventory_view.embed, view=inventory_view)
            
        elif custom_id == "bonus_codes":
            from views.bonus_code_view import BonusCodeView
            bonus_view = BonusCodeView(self.embed, self)
            await interaction.response.edit_message(embed=bonus_view.embed, view=bonus_view)
        
        elif custom_id == "bonus_codes_admin":
            from views.bonus_code_view import AdminBonusCodeView
            admin_view = AdminBonusCodeView(self.embed, self)
            await admin_view.load_bonus_codes()
            await interaction.response.edit_message(embed=admin_view.embed, view=admin_view)
        
        elif custom_id == "role_bonuses":
            from views.role_bonus_view import RoleBonusView
            role_bonus_view = RoleBonusView(self.embed, self)
            await interaction.response.edit_message(embed=role_bonus_view.embed, view=role_bonus_view)
            
        elif custom_id == "close":
            await interaction.response.defer()
            await interaction.delete_original_response()
        return False
