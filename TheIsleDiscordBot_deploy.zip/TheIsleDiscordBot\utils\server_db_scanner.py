"""
Сканер базы данных сервера The Isle
Ищет и анализирует возможные БД файлы сервера
"""

import os
import sqlite3
import json
import configparser
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class TheIsleServerScanner:
    """Сканер для поиска и анализа БД сервера The Isle"""
    
    def __init__(self, server_root_path: str = None):
        self.server_root = Path(server_root_path) if server_root_path else None
        self.found_databases = []
        self.found_configs = []
        self.found_save_files = []
        
    def scan_windowsgsm_servers(self, wgsm_path: str = "C:\\WindowsGSM") -> List[Dict]:
        """Сканирует серверы WindowsGSM в поисках The Isle"""
        results = []
        wgsm_path = Path(wgsm_path)
        
        if not wgsm_path.exists():
            logger.warning(f"WindowsGSM path not found: {wgsm_path}")
            return results
            
        # Ищем папки серверов
        servers_path = wgsm_path / "servers"
        if servers_path.exists():
            for server_dir in servers_path.iterdir():
                if server_dir.is_dir():
                    server_info = self._analyze_server_directory(server_dir)
                    if server_info:
                        results.append(server_info)
                        
        return results
    
    def _analyze_server_directory(self, server_path: Path) -> Optional[Dict]:
        """Анализирует директорию сервера"""
        server_info = {
            "server_id": server_path.name,
            "path": str(server_path),
            "databases": [],
            "configs": [],
            "save_files": [],
            "is_theisle": False
        }
        
        # Проверяем это ли The Isle сервер
        serverfiles = server_path / "serverfiles"
        if serverfiles.exists():
            # Ищем характерные для The Isle файлы
            theisle_indicators = [
                "TheIsle.exe", "TheIsleServer.exe", 
                "TheIsle", "Evrima"
            ]
            
            for indicator in theisle_indicators:
                if any(serverfiles.rglob(f"*{indicator}*")):
                    server_info["is_theisle"] = True
                    break
        
        if server_info["is_theisle"]:
            # Сканируем БД файлы
            server_info["databases"] = self._find_database_files(server_path)
            server_info["configs"] = self._find_config_files(server_path)
            server_info["save_files"] = self._find_save_files(server_path)
            
        return server_info if server_info["is_theisle"] else None
    
    def _find_database_files(self, base_path: Path) -> List[Dict]:
        """Ищет файлы баз данных"""
        db_files = []
        db_extensions = [".db", ".sqlite", ".sqlite3", ".sql"]
        
        for ext in db_extensions:
            for db_file in base_path.rglob(f"*{ext}"):
                if db_file.is_file():
                    db_info = self._analyze_database_file(db_file)
                    if db_info:
                        db_files.append(db_info)
                        
        return db_files
    
    def _find_config_files(self, base_path: Path) -> List[Dict]:
        """Ищет конфигурационные файлы"""
        config_files = []
        config_extensions = [".ini", ".cfg", ".conf", ".json"]
        
        for ext in config_extensions:
            for config_file in base_path.rglob(f"*{ext}"):
                if config_file.is_file() and config_file.stat().st_size < 1024*1024:  # < 1MB
                    try:
                        config_info = {
                            "path": str(config_file),
                            "name": config_file.name,
                            "size": config_file.stat().st_size,
                            "type": ext,
                            "content_preview": None
                        }
                        
                        # Читаем превью содержимого
                        with open(config_file, 'r', encoding='utf-8', errors='ignore') as f:
                            preview = f.read(500)
                            if any(keyword in preview.lower() for keyword in 
                                  ['database', 'mysql', 'sqlite', 'connection', 'player']):
                                config_info["content_preview"] = preview
                                config_files.append(config_info)
                                
                    except Exception as e:
                        logger.debug(f"Error reading config {config_file}: {e}")
                        
        return config_files
    
    def _find_save_files(self, base_path: Path) -> List[Dict]:
        """Ищет файлы сохранений игроков"""
        save_files = []
        
        # Ищем .sav файлы (как в примере)
        for sav_file in base_path.rglob("*.sav"):
            if sav_file.is_file():
                save_info = {
                    "path": str(sav_file),
                    "name": sav_file.name,
                    "size": sav_file.stat().st_size,
                    "steam_id": None
                }
                
                # Попытка извлечь Steam ID из имени файла
                if sav_file.stem.isdigit() and len(sav_file.stem) == 17:
                    save_info["steam_id"] = sav_file.stem
                    
                save_files.append(save_info)
                
        return save_files
    
    def _analyze_database_file(self, db_path: Path) -> Optional[Dict]:
        """Анализирует файл базы данных"""
        db_info = {
            "path": str(db_path),
            "name": db_path.name,
            "size": db_path.stat().st_size,
            "type": "unknown",
            "tables": [],
            "accessible": False
        }
        
        # Проверяем SQLite
        if self._is_sqlite_database(db_path):
            db_info["type"] = "sqlite"
            tables = self._get_sqlite_tables(db_path)
            db_info["tables"] = tables
            db_info["accessible"] = len(tables) > 0
            
        return db_info if db_info["accessible"] else None
    
    def _is_sqlite_database(self, file_path: Path) -> bool:
        """Проверяет является ли файл SQLite базой"""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(16)
                return header.startswith(b'SQLite format 3\x00')
        except:
            return False
    
    def _get_sqlite_tables(self, db_path: Path) -> List[Dict]:
        """Получает список таблиц из SQLite БД"""
        tables = []
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # Получаем список таблиц
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            table_names = cursor.fetchall()
            
            for (table_name,) in table_names:
                # Получаем структуру таблицы
                cursor.execute(f"PRAGMA table_info({table_name});")
                columns = cursor.fetchall()
                
                # Получаем количество записей
                cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
                row_count = cursor.fetchone()[0]
                
                table_info = {
                    "name": table_name,
                    "columns": [{"name": col[1], "type": col[2]} for col in columns],
                    "row_count": row_count
                }
                tables.append(table_info)
                
            conn.close()
            
        except Exception as e:
            logger.debug(f"Error analyzing SQLite database {db_path}: {e}")
            
        return tables


def scan_for_theisle_databases(base_paths: List[str] = None) -> Dict:
    """Основная функция сканирования"""
    if not base_paths:
        base_paths = [
            "C:\\WindowsGSM",
            "C:\\GameServers", 
            "C:\\SteamCMD",
            "D:\\GameServers"
        ]
    
    scanner = TheIsleServerScanner()
    results = {
        "servers_found": [],
        "total_databases": 0,
        "recommendations": []
    }
    
    for base_path in base_paths:
        if os.path.exists(base_path):
            servers = scanner.scan_windowsgsm_servers(base_path)
            results["servers_found"].extend(servers)
    
    # Подсчитываем общее количество БД
    for server in results["servers_found"]:
        results["total_databases"] += len(server["databases"])
    
    # Генерируем рекомендации
    if results["total_databases"] > 0:
        results["recommendations"].append("Найдены SQLite базы данных - можно использовать прямое подключение")
    else:
        results["recommendations"].append("БД не найдены - рекомендуется использовать мониторинг файлов сохранений")
    
    return results


if __name__ == "__main__":
    # Пример использования
    import json
    
    print("Сканирование серверов The Isle...")
    results = scan_for_theisle_databases()
    
    print(json.dumps(results, indent=2, ensure_ascii=False))