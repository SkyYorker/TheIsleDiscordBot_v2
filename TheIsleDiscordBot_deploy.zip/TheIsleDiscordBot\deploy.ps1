# Скрипт автоматического деплоя бота на сервер через Git
# Использование: .\deploy.ps1 [путь_к_папке_на_сервере]

param(
    [string]$ServerPath = "C:\Servers\servers\TheIsleDiscordBot",
    [string]$GitRepo = "https://github.com/SkyYorker/TheIsleDiscordBot.git",
    [switch]$Update = $false
)

Write-Host "=== Деплой Discord бота ===" -ForegroundColor Cyan
Write-Host ""

# Проверяем, существует ли папка
if (Test-Path $ServerPath) {
    if ($Update) {
        Write-Host "Обновление существующей версии..." -ForegroundColor Yellow
        Set-Location $ServerPath
        
        # Останавливаем бота (если запущен)
        Write-Host "Остановка бота..." -ForegroundColor Yellow
        Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*$ServerPath*" } | Stop-Process -Force -ErrorAction SilentlyContinue
        
        # Делаем бэкап БД
        $backupPath = Join-Path $ServerPath "backups"
        if (-not (Test-Path $backupPath)) {
            New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
        }
        $backupFile = Join-Path $backupPath "main.db.backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        if (Test-Path (Join-Path $ServerPath "main.db")) {
            Copy-Item (Join-Path $ServerPath "main.db") -Destination $backupFile -Force
            Write-Host "Бэкап БД создан: $backupFile" -ForegroundColor Green
        }
        
        # Обновляем из Git
        Write-Host "Обновление из Git..." -ForegroundColor Yellow
        git pull origin master
        
        Write-Host "Обновление завершено!" -ForegroundColor Green
        Write-Host "Запустите бота: .\start_bot.ps1" -ForegroundColor Cyan
    } else {
        Write-Host "Папка уже существует: $ServerPath" -ForegroundColor Red
        Write-Host "Используйте -Update для обновления существующей версии" -ForegroundColor Yellow
        Write-Host "Или укажите другую папку" -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "Клонирование репозитория..." -ForegroundColor Yellow
    Write-Host "Путь: $ServerPath" -ForegroundColor Cyan
    Write-Host "Репозиторий: $GitRepo" -ForegroundColor Cyan
    Write-Host ""
    
    # Создаем родительскую папку, если не существует
    $parentPath = Split-Path $ServerPath -Parent
    if (-not (Test-Path $parentPath)) {
        New-Item -ItemType Directory -Path $parentPath -Force | Out-Null
        Write-Host "Создана папка: $parentPath" -ForegroundColor Green
    }
    
    # Клонируем репозиторий
    git clone $GitRepo $ServerPath
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Ошибка при клонировании репозитория!" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Репозиторий успешно клонирован!" -ForegroundColor Green
    Write-Host ""
    
    Set-Location $ServerPath
    
    # Создаем виртуальное окружение
    Write-Host "Создание виртуального окружения..." -ForegroundColor Yellow
    python -m venv .venv
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Ошибка при создании виртуального окружения!" -ForegroundColor Red
        Write-Host "Убедитесь, что Python установлен и доступен в PATH" -ForegroundColor Yellow
        exit 1
    }
    
    Write-Host "Виртуальное окружение создано!" -ForegroundColor Green
    Write-Host ""
    
    # Активируем виртуальное окружение и устанавливаем зависимости
    Write-Host "Установка зависимостей..." -ForegroundColor Yellow
    & .\.venv\Scripts\Activate.ps1
    pip install --upgrade pip
    pip install -r requirements.txt
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Ошибка при установке зависимостей!" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Зависимости установлены!" -ForegroundColor Green
    Write-Host ""
    
    # Проверяем наличие .env файла
    if (-not (Test-Path ".env")) {
        Write-Host "⚠️  Файл .env не найден!" -ForegroundColor Yellow
        Write-Host "Создайте файл .env с необходимыми переменными окружения" -ForegroundColor Yellow
        Write-Host "Пример содержимого:" -ForegroundColor Cyan
        Write-Host "DISCORD_TOKEN=ваш_токен" -ForegroundColor Gray
        Write-Host "TEST_DISCORD_TOKEN=тестовый_токен" -ForegroundColor Gray
        Write-Host ""
    } else {
        Write-Host "Файл .env найден ✓" -ForegroundColor Green
    }
    
    # Проверяем наличие main.db
    if (-not (Test-Path "main.db")) {
        Write-Host "⚠️  База данных main.db не найдена!" -ForegroundColor Yellow
        Write-Host "Если у вас есть старая версия бота, скопируйте main.db из старой папки" -ForegroundColor Yellow
        Write-Host "Пример команды:" -ForegroundColor Cyan
        Write-Host "Copy-Item 'C:\Servers\servers\TheIsleDiscordBot\main.db' -Destination '$ServerPath\main.db'" -ForegroundColor Gray
        Write-Host ""
    } else {
        Write-Host "База данных main.db найдена ✓" -ForegroundColor Green
    }
    
    Write-Host "=== Деплой завершен! ===" -ForegroundColor Green
    Write-Host ""
    Write-Host "Следующие шаги:" -ForegroundColor Cyan
    Write-Host "1. Убедитесь, что файл .env настроен правильно" -ForegroundColor White
    Write-Host "2. Скопируйте main.db из старой версии (если есть)" -ForegroundColor White
    Write-Host "3. Запустите бота: .\start_bot.ps1" -ForegroundColor White
    Write-Host ""
}

