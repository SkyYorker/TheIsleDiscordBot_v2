import os
import logging
import asyncio

from aiohttp import ClientSession, BasicAuth, ClientTimeout, TCPConnector
from aiohttp.client_exceptions import ServerDisconnectedError, ClientError

logger = logging.getLogger(__name__)


def _get_clicker_config():
    """Получает настройки Clicker API из переменных окружения"""
    api_url = os.getenv("CLICKER_SERVER_API_URL")
    username = os.getenv("CLICKER_SERVER_USERNAME")
    password = os.getenv("CLICKER_SERVER_PASSWORD")
    
    # Проверка наличия настроек (логируем только один раз при первом вызове)
    if not hasattr(_get_clicker_config, '_logged'):
        if api_url and username and password:
            logger.info(f"✅ Clicker API настроен: URL={api_url}, Username={username}")
        else:
            missing = []
            if not api_url:
                missing.append("CLICKER_SERVER_API_URL")
            if not username:
                missing.append("CLICKER_SERVER_USERNAME")
            if not password:
                missing.append("CLICKER_SERVER_PASSWORD")
            logger.warning(f"⚠️ Clicker API: отсутствуют настройки в .env: {', '.join(missing)}")
        _get_clicker_config._logged = True
    
    return api_url, username, password


async def _make_request(url: str, data: dict = None, endpoint_name: str = "endpoint", max_retries: int = 3) -> dict:
    """
    Общая функция для выполнения HTTP запросов к Clicker API с повторными попытками.
    
    Args:
        url: Полный URL для запроса
        data: Данные для отправки (если None, отправляется POST без тела)
        endpoint_name: Имя endpoint'а для логирования
        max_retries: Максимальное количество попыток
    
    Returns:
        dict: Результат запроса или dict с ошибкой
    """
    API_URL, USERNAME, PASSWORD = _get_clicker_config()
    if not API_URL or not USERNAME or not PASSWORD:
        logger.error("Clicker API: не указаны настройки в .env файле")
        return {"success": False, "error": "Clicker API не настроен"}
    
    logger.debug(f"Clicker API: отправка запроса на {url} ({endpoint_name})")
    
    for attempt in range(max_retries):
        try:
            # Создаем новый connector для каждого запроса с принудительным закрытием
            # Это помогает избежать проблем с переиспользованием соединений
            # ClientSession автоматически закроет connector при выходе из контекста
            connector = TCPConnector(
                limit=1,
                force_close=True,
                enable_cleanup_closed=True,
                ttl_dns_cache=0,  # Отключаем кэш DNS
                use_dns_cache=False
            )
            timeout = ClientTimeout(total=30, connect=10, sock_read=10)
            
            async with ClientSession(connector=connector, timeout=timeout) as session:
                # Определяем параметры запроса
                request_kwargs = {
                    "auth": BasicAuth(USERNAME, PASSWORD),
                    "headers": {
                        'Connection': 'close',  # Явно закрываем соединение после запроса
                        'User-Agent': 'TheIsleDiscordBot/1.0',
                        'Content-Type': 'application/json'
                    }
                }
                
                if data is not None:
                    request_kwargs["json"] = data
                
                async with session.post(url, **request_kwargs) as response:
                    if response.status == 200:
                        try:
                            result = await response.json()
                            logger.info(f"Clicker API: успешный запрос к {endpoint_name}")
                            return result
                        except Exception as json_error:
                            # Если ответ не JSON, читаем как текст
                            text_result = await response.text()
                            logger.warning(f"Clicker API: ответ не в формате JSON для {endpoint_name}: {text_result}")
                            return {"success": True, "message": text_result}
                    else:
                        error_text = await response.text()
                        logger.error(f"Clicker API: ошибка {response.status} для {endpoint_name} - {error_text}")
                        return {"success": False, "error": f"HTTP {response.status}: {error_text}"}
                        
        except ServerDisconnectedError as e:
            if attempt < max_retries - 1:
                wait_time = (attempt + 1) * 0.5  # Задержка: 0.5, 1, 1.5 секунды
                logger.warning(
                    f"Clicker API: разрыв соединения для {endpoint_name} "
                    f"(попытка {attempt + 1}/{max_retries}), повтор через {wait_time} сек..."
                )
                await asyncio.sleep(wait_time)
                continue
            else:
                logger.error(f"Clicker API: разрыв соединения после {max_retries} попыток для {endpoint_name}: {e}")
                return {"success": False, "error": f"Разрыв соединения: {str(e)}"}
        except asyncio.TimeoutError as e:
            if attempt < max_retries - 1:
                wait_time = (attempt + 1) * 0.5
                logger.warning(
                    f"Clicker API: таймаут для {endpoint_name} "
                    f"(попытка {attempt + 1}/{max_retries}), повтор через {wait_time} сек..."
                )
                await asyncio.sleep(wait_time)
                continue
            else:
                logger.error(f"Clicker API: таймаут после {max_retries} попыток для {endpoint_name}")
                return {"success": False, "error": "Таймаут подключения"}
        except ClientError as e:
            logger.error(f"Clicker API: ошибка подключения к {url} ({endpoint_name}): {e}")
            return {"success": False, "error": f"Ошибка подключения: {str(e)}"}
        except Exception as e:
            logger.error(f"Clicker API: неожиданная ошибка для {endpoint_name}: {e}", exc_info=True)
            return {"success": False, "error": f"Ошибка: {str(e)}"}
    
    return {"success": False, "error": "Не удалось подключиться после нескольких попыток"}


async def run_enter():
    """Выполняет команду enter на кликере"""
    API_URL, _, _ = _get_clicker_config()
    url = f"http://{API_URL}/run-enter"
    return await _make_request(url, data=None, endpoint_name="/run-enter")


async def restore_dino(
        steamid: str,
        growth: int,
        hunger: int,
        thirst: int,
        health: int
):
    """Восстанавливает динозавра через Clicker API"""
    API_URL, _, _ = _get_clicker_config()
    url = f"http://{API_URL}/run-restore-dino"
    data = {
        "steamid": steamid,
        "growth": growth,
        "hunger": hunger,
        "thirst": thirst,
        "health": health
    }
    logger.debug(f"Clicker API: восстановление динозавра для steamid={steamid}")
    return await _make_request(url, data=data, endpoint_name=f"/run-restore-dino (steamid={steamid})")


async def slay_dino(steamid: str):
    """Убивает динозавра через Clicker API"""
    API_URL, _, _ = _get_clicker_config()
    url = f"http://{API_URL}/run-slay-dino"
    data = {"steamid": steamid}
    logger.debug(f"Clicker API: убийство динозавра для steamid={steamid}")
    return await _make_request(url, data=data, endpoint_name=f"/run-slay-dino (steamid={steamid})")


async def set_nutrients(
        steamid: str,
        prot: float,
        carb: float,
        lipid: float
):
    """Устанавливает нутриенты динозавра через Clicker API"""
    API_URL, _, _ = _get_clicker_config()
    url = f"http://{API_URL}/run-set-nutrients"
    data = {
        "steamid": steamid,
        "prot": prot,
        "carb": carb,
        "lipid": lipid
    }
    logger.debug(f"Clicker API: установка нутриентов для steamid={steamid}")
    return await _make_request(url, data=data, endpoint_name=f"/run-set-nutrients (steamid={steamid})")


async def set_food(
        steamid: str,
        hunger: int,
        thirst: int
):
    """Устанавливает еду/воду динозавра через Clicker API"""
    API_URL, _, _ = _get_clicker_config()
    url = f"http://{API_URL}/run-set-food"
    data = {
        "steamid": steamid,
        "thirst": thirst,
        "hunger": hunger
    }
    logger.debug(f"Clicker API: установка еды/воды для steamid={steamid}")
    return await _make_request(url, data=data, endpoint_name=f"/run-set-food (steamid={steamid})")
