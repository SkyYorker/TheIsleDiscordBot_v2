from typing import Optional, List
import json
import logging

import discord
from discord.ui import View, Select, Button, Modal
try:
    from discord.ui import InputText
except ImportError:
    from discord.ui import TextInput as InputText

from data.dinosaurus import DINOSAURS, CATEGORY_EMOJIS, find_name_by_class
from database.crud import DonationCRUD, ItemCRUD, InventoryCRUD
from database.models import ItemType
from utils.steam_api import steam_api

logger = logging.getLogger(__name__)


def get_dinos_by_category(category: str) -> List[tuple[str, int]]:
    return [(name, data["price"]) for name, data in DINOSAURS.items()
            if data.get("category") == category and data.get("price") is not None]


async def get_or_create_dino_item(dino_name: str) -> Optional[dict]:
    """Получает или создает Item для динозавра"""
    dino_data = DINOSAURS.get(dino_name)
    if not dino_data:
        return None
    
    # Проверяем, существует ли Item с таким именем
    all_items = await ItemCRUD.get_all_items(active_only=False)
    for item in all_items:
        if item['name'] == dino_name and item['item_type'] == 'dinosaur':
            return item
    
    # Создаем новый Item для динозавра
    game_data = json.dumps({
        "dino_class": dino_data["class_name"],
        "growth": 99,
        "hunger": 100,
        "thirst": 100,
        "health": 100
    })
    
    description = f"Динозавр: {dino_name}\n"
    description += f"Категория: {dino_data.get('category', 'Неизвестно')}\n"
    description += f"В группе разрешено: {dino_data.get('group_limit', '?')}\n"
    description += f"Макс. вес: {dino_data.get('weight', '?')}\n"
    description += f"Скорость: {dino_data.get('speed', '?')}\n"
    description += f"Сила укуса: {dino_data.get('bite', '?')}"
    
    try:
        item = await ItemCRUD.create_item(
            name=dino_name,
            description=description,
            item_type=ItemType.DINOSAUR,
            price=dino_data["price"],
            max_stack=1,
            game_data=game_data
        )
        return item
    except Exception as e:
        # Если Item уже существует (unique constraint), пытаемся получить его
        all_items = await ItemCRUD.get_all_items(active_only=False)
        for item in all_items:
            if item['name'] == dino_name:
                return item
        return None


class PurchaseDinoQuantityModal(Modal):
    """Модальное окно для покупки динозавров (добавление в инвентарь)"""
    def __init__(self, dino_name: str, price: int, shop_view: 'DinoShopView', message_id: int = None):
        # Используем custom_id для идентификации модального окна
        # Заменяем пробелы и специальные символы для custom_id
        safe_dino_name = dino_name.replace(" ", "_").replace("'", "").replace('"', '')[:20]
        custom_id = f"purchase_dino_modal_{safe_dino_name}"
        super().__init__(title="Количество динозавров", custom_id=custom_id)
        self.dino_name = dino_name
        self.price = price
        self.shop_view = shop_view
        self.message_id = message_id  # ID сообщения магазина для редактирования

        # Обрезаем название динозавра, если оно слишком длинное (максимум 45 символов для метки)
        short_name = dino_name[:30] if len(dino_name) > 30 else dino_name
        self.quantity = InputText(
            label=f"Количество {short_name}",
            placeholder="1",
            min_length=1,
            max_length=3
        )
        self.add_item(self.quantity)

    async def callback(self, interaction: discord.Interaction):
        logger.info(f"[PurchaseDinoQuantityModal] ⚡ CALLBACK ВЫЗВАН для пользователя {interaction.user.id}, динозавр {self.dino_name}")
        logger.info(f"[PurchaseDinoQuantityModal] interaction.data: {interaction.data}")
        logger.info(f"[PurchaseDinoQuantityModal] self.quantity: {self.quantity}, value: {getattr(self.quantity, 'value', 'NO VALUE')}")
        logger.info(f"[PurchaseDinoQuantityModal] self.children: {self.children}")
        
        try:
            logger.info(f"[PurchaseDinoQuantityModal] Начало обработки покупки динозавра {self.dino_name} для пользователя {interaction.user.id}")
            
            # Получаем значение с fallback на self.children
            quantity_value = self.quantity.value
            if not quantity_value and self.children:
                quantity_value = self.children[0].value
                logger.debug(f"[PurchaseDinoQuantityModal] Использован fallback через self.children[0].value: {quantity_value}")
            
            # Проверка на None/пустое значение
            if not quantity_value or (isinstance(quantity_value, str) and quantity_value.strip() == ""):
                logger.warning(f"[PurchaseDinoQuantityModal] Пустое значение количества для пользователя {interaction.user.id}. quantity_value={quantity_value}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите количество динозавров для покупки.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            logger.debug(f"[PurchaseDinoQuantityModal] Получено значение количества: {quantity_value} (тип: {type(quantity_value)})")
            
            # Валидация количества
            try:
                quantity = int(quantity_value)
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[PurchaseDinoQuantityModal] Некорректное количество: {quantity_value} (ошибка: {e})")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите корректное количество (целое число больше 0).",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            total_price = self.price * quantity
            logger.info(f"[PurchaseDinoQuantityModal] Проверка баланса: требуется {total_price} ТС")
            
            # Проверяем существование игрока и получаем баланс
            current_balance = await DonationCRUD.get_tk(interaction.user.id)
            
            if current_balance is None:
                logger.warning(f"[PurchaseDinoQuantityModal] Игрок {interaction.user.id} не найден в базе данных")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Ваш аккаунт не найден в системе.\n\n"
                                "Пожалуйста, привяжите свой Steam аккаунт через кнопку 'Привязать Steam' в главном меню.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            has_enough_tk = await DonationCRUD.check_balance(interaction.user.id, total_price)

            if not has_enough_tk:
                logger.warning(f"[PurchaseDinoQuantityModal] Недостаточно ТС: баланс {current_balance}, требуется {total_price}")
                error_embed = discord.Embed(
                    title="❌ Недостаточно ТC",
                    description=f"У вас недостаточно ТC для покупки {quantity}x {self.dino_name}.\n\n"
                                f"**Требуется:** {total_price} ТС\n"
                                f"**Ваш баланс:** {current_balance} ТC",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            # Получаем ID сообщения для редактирования
            message_id = self.message_id
            
            # Откладываем ответ модального окна
            await interaction.response.defer(ephemeral=True)
            
            # Если есть ID сообщения магазина, показываем wait embed
            if message_id:
                wait_embed = discord.Embed(
                    title="⏳ Пожалуйста, подождите",
                    description="Происходит обработка покупки...\nЭто может занять несколько секунд.",
                    color=discord.Color.blurple()
                )
                try:
                    # Получаем канал и сообщение для редактирования
                    channel = interaction.channel
                    if channel:
                        message = await channel.fetch_message(message_id)
                        await message.edit(embed=wait_embed, view=None)
                except Exception as e:
                    logger.warning(f"[PurchaseDinoQuantityModal] Не удалось показать wait embed: {e}")
                    # Продолжаем выполнение, даже если не удалось показать wait embed

            # Получаем или создаем Item для динозавра
            dino_item = await get_or_create_dino_item(self.dino_name)
            if not dino_item:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось создать Item для динозавра {self.dino_name}.",
                    color=discord.Color.red()
                )
                if message_id:
                    try:
                        # Получаем канал и сообщение для редактирования
                        channel = interaction.channel
                        if channel:
                            message = await channel.fetch_message(message_id)
                            await message.edit(embed=error_embed, view=None)
                        else:
                            await interaction.followup.send(embed=error_embed, ephemeral=True)
                    except Exception as edit_error:
                        logger.warning(f"[PurchaseDinoQuantityModal] Не удалось отредактировать сообщение: {edit_error}")
                        await interaction.followup.send(embed=error_embed, ephemeral=True)
                else:
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
                return

            # Списываем деньги
            await DonationCRUD.remove_tk(interaction.user.id, total_price)
            
            # Добавляем динозавров в инвентарь
            try:
                for _ in range(quantity):
                    await InventoryCRUD.add_item_to_inventory(interaction.user.id, dino_item['id'], 1)
                
                # Получаем новый баланс
                new_balance = await DonationCRUD.get_tk(interaction.user.id)
                
                confirmation_view = DinoPurchaseConfirmationView(
                    self.shop_view,
                    self.shop_view.main_menu_embed,
                    self.shop_view.main_menu_view
                )

                embed = discord.Embed(
                    title="✅ Покупка успешна",
                    description=f"Вы купили **{quantity}x {self.dino_name}** за {total_price} ТС!\n\n"
                                f"Динозавры добавлены в ваш инвентарь.\n"
                                f"Перейдите в **Главное меню → Инвентарь**, чтобы активировать их в игру.",
                    color=discord.Color.green()
                )
                embed.add_field(name="💰 Потрачено", value=f"{total_price} ТС", inline=True)
                embed.add_field(name="💳 Осталось", value=f"{new_balance} ТС", inline=True)
                embed.add_field(name="🦖 Динозавр", value=f"{quantity}x {self.dino_name}", inline=False)
                embed.set_footer(text="Активируйте динозавров из инвентаря для использования в игре")
                
                # Редактируем сообщение вместо отправки нового
                if message_id:
                    try:
                        # Получаем канал и сообщение для редактирования
                        channel = interaction.channel
                        if channel:
                            message = await channel.fetch_message(message_id)
                            await message.edit(embed=embed, view=confirmation_view)
                        else:
                            # Если канал недоступен, отправляем новое сообщение
                            await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
                    except Exception as edit_error:
                        logger.warning(f"[PurchaseDinoQuantityModal] Не удалось отредактировать сообщение: {edit_error}")
                        # Если не удалось отредактировать, отправляем новое сообщение
                        await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
                else:
                    await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
            except Exception as e:
                logger.error(f"[PurchaseDinoQuantityModal] Ошибка при добавлении динозавров в инвентарь: {e}", exc_info=True)
                # Возвращаем деньги при ошибке
                await DonationCRUD.add_tk(interaction.user.id, total_price)
                error_embed = discord.Embed(
                    title="❌ Ошибка покупки",
                    description=f"Не удалось добавить динозавров в инвентарь.\n\n"
                                f"Деньги возвращены на ваш баланс.\n"
                                f"Ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                # Редактируем сообщение с ошибкой или отправляем новое
                if message_id:
                    try:
                        # Получаем канал и сообщение для редактирования
                        channel = interaction.channel
                        if channel:
                            message = await channel.fetch_message(message_id)
                            await message.edit(embed=error_embed, view=None)
                        else:
                            await interaction.followup.send(embed=error_embed, ephemeral=True)
                    except Exception as edit_error:
                        logger.warning(f"[PurchaseDinoQuantityModal] Не удалось отредактировать сообщение: {edit_error}")
                        await interaction.followup.send(embed=error_embed, ephemeral=True)
                else:
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[PurchaseDinoQuantityModal] ❌ КРИТИЧЕСКАЯ ОШИБКА в callback: {e}", exc_info=True)
            logger.error(f"[PurchaseDinoQuantityModal] Тип ошибки: {type(e).__name__}")
            logger.error(f"[PurchaseDinoQuantityModal] Traceback:", exc_info=True)
            # Пытаемся отправить сообщение об ошибке, если еще не ответили
            try:
                if not interaction.response.is_done():
                    logger.info(f"[PurchaseDinoQuantityModal] Отправляем ошибку через response.send_message")
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Произошла ошибка при обработке покупки.\n\nОшибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
                else:
                    logger.info(f"[PurchaseDinoQuantityModal] Отправляем ошибку через followup.send")
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Произошла ошибка при обработке покупки.\n\nОшибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
            except Exception as send_error:
                logger.error(f"[PurchaseDinoQuantityModal] ❌ Не удалось отправить сообщение об ошибке: {send_error}", exc_info=True)
                print(f"[PurchaseDinoQuantityModal] КРИТИЧЕСКАЯ ОШИБКА - не удалось отправить сообщение: {send_error}")


class PurchaseItemQuantityModal(Modal):
    """Модальное окно для покупки предметов (добавление в инвентарь)"""
    def __init__(self, item_id: int, item_name: str, price: int, shop_view: 'DinoShopView', message_id: int = None):
        # Используем custom_id для идентификации модального окна
        custom_id = f"purchase_item_modal_{item_id}"
        super().__init__(title="Количество предметов", custom_id=custom_id)
        self.item_id = item_id
        self.item_name = item_name
        self.price = price
        self.shop_view = shop_view
        self.message_id = message_id  # ID сообщения магазина для редактирования

        # Обрезаем название предмета, если оно слишком длинное (максимум 45 символов для метки)
        short_name = item_name[:30] if len(item_name) > 30 else item_name
        self.quantity = InputText(
            label=f"Количество {short_name}",
            placeholder="1",
            min_length=1,
            max_length=3
        )
        self.add_item(self.quantity)

    async def callback(self, interaction: discord.Interaction):
        logger.info(f"[PurchaseItemQuantityModal] ⚡⚡⚡ CALLBACK ВЫЗВАН для пользователя {interaction.user.id}, предмет {self.item_id}")
        logger.info(f"[PurchaseItemQuantityModal] interaction.data: {interaction.data}")
        logger.info(f"[PurchaseItemQuantityModal] self.quantity: {self.quantity}, value: {getattr(self.quantity, 'value', 'NO VALUE')}")
        logger.info(f"[PurchaseItemQuantityModal] self.children: {self.children}")
        
        # Получаем значения из interaction.data напрямую
        quantity_from_data = None
        if hasattr(interaction, 'data') and 'components' in interaction.data:
            logger.info(f"[PurchaseItemQuantityModal] components в interaction.data: {interaction.data.get('components')}")
            for component in interaction.data.get('components', []):
                for item in component.get('components', []):
                    if item.get('type') == 4:  # InputText type
                        quantity_from_data = item.get('value')
                        logger.info(f"[PurchaseItemQuantityModal] Найден InputText: value={quantity_from_data}")
                        break
                if quantity_from_data:
                    break
        
        try:
            logger.info(f"[PurchaseItemQuantityModal] Начало обработки покупки предмета {self.item_id} для пользователя {interaction.user.id}")
            
            # Получаем значение с fallback на self.children и interaction.data
            quantity_value = None
            
            # Сначала пытаемся получить из interaction.data
            if quantity_from_data:
                quantity_value = quantity_from_data
                logger.info(f"[PurchaseItemQuantityModal] Использовано значение из interaction.data: {quantity_value}")
            # Затем из self.quantity.value
            elif hasattr(self.quantity, 'value') and self.quantity.value:
                quantity_value = self.quantity.value
                logger.info(f"[PurchaseItemQuantityModal] Использовано значение из self.quantity.value: {quantity_value}")
            # Затем из self.children
            elif self.children and len(self.children) > 0:
                quantity_value = getattr(self.children[0], 'value', None)
                logger.info(f"[PurchaseItemQuantityModal] Использован fallback через self.children[0].value: {quantity_value}")
            
            # Проверка на None/пустое значение
            if not quantity_value or (isinstance(quantity_value, str) and quantity_value.strip() == ""):
                logger.warning(f"[PurchaseItemQuantityModal] Пустое значение количества для пользователя {interaction.user.id}. quantity_value={quantity_value}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите количество предметов для покупки.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            logger.debug(f"[PurchaseItemQuantityModal] Получено значение количества: {quantity_value} (тип: {type(quantity_value)})")
            
            # Валидация количества
            try:
                quantity = int(quantity_value)
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[PurchaseItemQuantityModal] Некорректное количество: {quantity_value} (ошибка: {e})")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите корректное количество (целое число больше 0).",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            total_price = self.price * quantity
            logger.info(f"[PurchaseItemQuantityModal] Проверка баланса: требуется {total_price} ТС")
            
            # Проверяем существование игрока и получаем баланс
            current_balance = await DonationCRUD.get_tk(interaction.user.id)
            
            if current_balance is None:
                logger.warning(f"[PurchaseItemQuantityModal] Игрок {interaction.user.id} не найден в базе данных")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Ваш аккаунт не найден в системе.\n\n"
                                "Пожалуйста, привяжите свой Steam аккаунт через кнопку 'Привязать Steam' в главном меню.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            has_enough_tk = await DonationCRUD.check_balance(interaction.user.id, total_price)

            if not has_enough_tk:
                logger.warning(f"[PurchaseItemQuantityModal] Недостаточно ТС: баланс {current_balance}, требуется {total_price}")
                error_embed = discord.Embed(
                    title="❌ Недостаточно ТC",
                    description=f"У вас недостаточно ТC для покупки {quantity}x {self.item_name}.\n\n"
                                f"**Требуется:** {total_price} ТС\n"
                                f"**Ваш баланс:** {current_balance} ТC",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            # Получаем ID сообщения для редактирования
            message_id = self.message_id
            
            # Откладываем ответ модального окна
            logger.info(f"[PurchaseItemQuantityModal] Откладываем ответ для пользователя {interaction.user.id}")
            await interaction.response.defer(ephemeral=True)
            
            # Если есть ID сообщения магазина, показываем wait embed
            if message_id:
                wait_embed = discord.Embed(
                    title="⏳ Пожалуйста, подождите",
                    description="Происходит обработка покупки...\nЭто может занять несколько секунд.",
                    color=discord.Color.blurple()
                )
                try:
                    # Получаем канал и сообщение для редактирования
                    channel = interaction.channel
                    if channel:
                        message = await channel.fetch_message(message_id)
                        await message.edit(embed=wait_embed, view=None)
                except Exception as e:
                    logger.warning(f"[PurchaseItemQuantityModal] Не удалось показать wait embed: {e}")
                    # Продолжаем выполнение, даже если не удалось показать wait embed

            # Списываем деньги
            logger.info(f"[PurchaseItemQuantityModal] Списываем {total_price} ТС с баланса пользователя {interaction.user.id}")
            await DonationCRUD.remove_tk(interaction.user.id, total_price)
            
            # Добавляем предметы в инвентарь
            try:
                logger.info(f"[PurchaseItemQuantityModal] Добавляем {quantity}x предмет {self.item_id} в инвентарь")
                for i in range(quantity):
                    await InventoryCRUD.add_item_to_inventory(interaction.user.id, self.item_id, 1)
                    logger.debug(f"[PurchaseItemQuantityModal] Добавлен предмет {i+1}/{quantity}")
                
                # Получаем новый баланс
                new_balance = await DonationCRUD.get_tk(interaction.user.id)
                logger.info(f"[PurchaseItemQuantityModal] Покупка успешна. Новый баланс: {new_balance} ТС")
                
                confirmation_view = DinoPurchaseConfirmationView(
                    self.shop_view,
                    self.shop_view.main_menu_embed,
                    self.shop_view.main_menu_view
                )

                embed = discord.Embed(
                    title="✅ Покупка успешна",
                    description=f"Вы купили **{quantity}x {self.item_name}** за {total_price} ТС!\n\n"
                                f"Предметы добавлены в ваш инвентарь.\n"
                                f"Перейдите в **Главное меню → Инвентарь**, чтобы использовать их.",
                    color=discord.Color.green()
                )
                embed.add_field(name="💰 Потрачено", value=f"{total_price} ТС", inline=True)
                embed.add_field(name="💳 Осталось", value=f"{new_balance} ТС", inline=True)
                embed.add_field(name="📦 Предмет", value=f"{quantity}x {self.item_name}", inline=False)
                embed.set_footer(text="Используйте предметы в инвентаре для применения в игре")
                
                # Редактируем сообщение вместо отправки нового
                if message_id:
                    try:
                        # Получаем канал и сообщение для редактирования
                        channel = interaction.channel
                        if channel:
                            message = await channel.fetch_message(message_id)
                            await message.edit(embed=embed, view=confirmation_view)
                        else:
                            # Если канал недоступен, отправляем новое сообщение
                            await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
                    except Exception as edit_error:
                        logger.warning(f"[PurchaseItemQuantityModal] Не удалось отредактировать сообщение: {edit_error}")
                        # Если не удалось отредактировать, отправляем новое сообщение
                        await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
                else:
                    await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
            except Exception as e:
                logger.error(f"[PurchaseItemQuantityModal] Ошибка при добавлении предметов в инвентарь: {e}", exc_info=True)
                # Возвращаем деньги при ошибке
                await DonationCRUD.add_tk(interaction.user.id, total_price)
                error_embed = discord.Embed(
                    title="❌ Ошибка покупки",
                    description=f"Не удалось добавить предметы в инвентарь.\n\n"
                                f"Деньги возвращены на ваш баланс.\n"
                                f"Ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                # Редактируем сообщение с ошибкой или отправляем новое
                if message_id:
                    try:
                        # Получаем канал и сообщение для редактирования
                        channel = interaction.channel
                        if channel:
                            message = await channel.fetch_message(message_id)
                            await message.edit(embed=error_embed, view=None)
                        else:
                            await interaction.followup.send(embed=error_embed, ephemeral=True)
                    except Exception as edit_error:
                        logger.warning(f"[PurchaseItemQuantityModal] Не удалось отредактировать сообщение: {edit_error}")
                        await interaction.followup.send(embed=error_embed, ephemeral=True)
                else:
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[PurchaseItemQuantityModal] ❌ КРИТИЧЕСКАЯ ОШИБКА в callback: {e}", exc_info=True)
            logger.error(f"[PurchaseItemQuantityModal] Тип ошибки: {type(e).__name__}")
            logger.error(f"[PurchaseItemQuantityModal] Traceback:", exc_info=True)
            # Пытаемся отправить сообщение об ошибке, если еще не ответили
            try:
                if not interaction.response.is_done():
                    logger.info(f"[PurchaseItemQuantityModal] Отправляем ошибку через response.send_message")
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Произошла ошибка при обработке покупки.\n\nОшибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
                else:
                    logger.info(f"[PurchaseItemQuantityModal] Отправляем ошибку через followup.send")
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Произошла ошибка при обработке покупки.\n\nОшибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
            except Exception as send_error:
                logger.error(f"[PurchaseItemQuantityModal] ❌ Не удалось отправить сообщение об ошибке: {send_error}", exc_info=True)
                print(f"[PurchaseItemQuantityModal] КРИТИЧЕСКАЯ ОШИБКА - не удалось отправить сообщение: {send_error}")


class DinoPurchaseConfirmationView(View):
    def __init__(self, shop_view: 'DinoShopView', main_menu_embed: discord.Embed, main_menu_view):
        super().__init__(timeout=None)
        self.shop_view = shop_view
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view

        self.add_item(Button(
            label="Инвентарь",
            style=discord.ButtonStyle.green,
            emoji="🎒",
            custom_id="open_inventory",
            row=0
        ))
        self.add_item(Button(
            label="Вернуться",
            style=discord.ButtonStyle.blurple,
            custom_id="back_to_shop",
            row=0
        ))
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.grey,
            custom_id="back_to_menu",
            row=1
        ))
        self.add_item(Button(
            label="Закрыть",
            style=discord.ButtonStyle.red,
            custom_id="close",
            row=1
        ))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        if custom_id == "open_inventory":
            # Переход в инвентарь
            from views.inventory_view import InventoryView
            from views.main_menu import MainMenuView
            
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            main_menu_view = MainMenuView(steam_data, interaction.user.id)
            await main_menu_view.update_player_data(interaction.user.id)
            
            inventory_view = InventoryView(main_menu_view.embed, main_menu_view)
            await inventory_view.load_inventory(interaction.user.id)
            await interaction.response.edit_message(embed=inventory_view.embed, view=inventory_view, content=None)
            
        elif custom_id == "back_to_shop":
            # Возврат в магазин - пересоздаем DinoShopView
            try:
                # Пересоздаем магазин с актуальными данными
                shop_view = DinoShopView(
                    self.main_menu_embed,
                    self.main_menu_view
                )
                await interaction.response.edit_message(
                    content=None,
                    embed=shop_view.embed,
                    view=shop_view
                )
            except Exception as e:
                # Если не удалось вернуться в магазин, возвращаемся в главное меню
                logger.error(f"[DinoPurchaseConfirmationView] Не удалось вернуться в магазин: {e}", exc_info=True)
                from views.main_menu import MainMenuView
                steam_data = await steam_api.get_steam_data(interaction.user.id)
                view = MainMenuView(steam_data, interaction.user.id)
                await view.update_player_data(interaction.user.id)
                await interaction.response.edit_message(embed=view.embed, view=view, content=None)
                
        elif custom_id == "back_to_menu":
            from views.main_menu import MainMenuView
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = MainMenuView(steam_data, interaction.user.id)
            await view.update_player_data(interaction.user.id)
            await interaction.response.edit_message(embed=view.embed, view=view, content=None)
            
        elif custom_id == "close":
            await interaction.response.defer()
            await interaction.delete_original_response()
            
        return False


class DinoShopView(View):
    """Магазинчик - покупка динозавров и предметов в инвентарь"""
    def __init__(self, main_menu_embed: discord.Embed, main_menu_view: View):
        super().__init__(timeout=None)
        self.main_menu_view = main_menu_view
        self.main_menu_embed = main_menu_embed

        self.selected_category: Optional[str] = None
        self.selected_dino: Optional[str] = None
        self.selected_price: Optional[int] = None
        self.selected_item: Optional[dict] = None  # Для предметов из БД
        self.is_items_mode: bool = False  # Режим: True = предметы из БД, False = динозавры

        self.category_select = self.create_category_select()
        self.dino_select = self.create_dino_select()
        self.buy_button = Button(
            label="Купить",
            style=discord.ButtonStyle.green,
            custom_id="buy_item_or_dino",
            disabled=True,
            row=2
        )
        self.back_button = Button(
            label="В главное меню",
            style=discord.ButtonStyle.grey,
            custom_id="back_to_menu",
            row=3
        )
        self.close_button = Button(
            label="Закрыть",
            style=discord.ButtonStyle.red,
            custom_id="close",
            row=3
        )

        self.add_item(self.category_select)
        self.add_item(self.dino_select)
        self.add_item(self.buy_button)
        self.add_item(self.back_button)
        self.add_item(self.close_button)

    def create_category_select(self) -> Select:
        categories = set(data["category"] for data in DINOSAURS.values() if data.get("category"))
        placeholder = (
            f"Выбрана категория: {self.selected_category}"
            if self.selected_category else "Выберите категорию"
        )
        options = [
                discord.SelectOption(
                    label=f"{cat}",
                    value=cat,
                    emoji=CATEGORY_EMOJIS[cat]
                ) for cat in sorted(categories)
            ]
        options.append(discord.SelectOption(label="📦 Предметы", value="items_shop", emoji="📦", description="Покупка предметов из БД"))
        return Select(
            placeholder=placeholder,
            options=options,
            custom_id="select_category",
            row=0
        )

    def create_dino_select(self) -> Select:
        """Создает select для динозавров"""
        options = []
        if self.selected_category and self.selected_category != "items_shop":
            for dino, price in get_dinos_by_category(self.selected_category):
                label = f"{dino} — {price} ТС"
                options.append(discord.SelectOption(label=label, value=DINOSAURS[dino]["class_name"]))
            placeholder = (
                f"Выбран динозавр: {self.selected_dino}"
                if self.selected_dino else "Выберите динозавра"
            )
        else:
            placeholder = "Сначала выберите категорию"
            
        return Select(
            placeholder=placeholder,
            options=options if options else [
                discord.SelectOption(label="Сначала выберите категорию", value="none", default=True, description="")],
            custom_id="select_dino",
            disabled=not self.selected_category or self.selected_category == "items_shop",
            row=1
        )

    @property
    def embed(self) -> discord.Embed:
        if self.is_items_mode:
            # Режим покупки предметов из БД
            embed = discord.Embed(
                title="📦 TAPKIN SHOP - Предметы 📦",
                description="""### Выберите предмет для покупки ниже в выпадающем списке.
💡 **Дополнительная информация:**
>>> - После покупки, предметы добавятся в ваш **инвентарь**.
- Чтобы использовать предмет, перейдите в **Главное меню → Инвентарь**.
- Выберите предмет и нажмите "Использовать предмет" для применения в игре.""",
                color=discord.Color.blue()
            )
            if self.selected_item:
                type_emoji = {
                    "dinosaur": "🦖",
                    "nutrients": "💊",
                    "food_water": "🍖",
                    "currency": "💰",
                    "special": "⭐"
                }.get(self.selected_item.get('item_type', ''), "📦")
                
                embed.add_field(
                    name=f"{type_emoji} Предмет",
                    value=f"**{self.selected_item['name']}**\nЦена: **{self.selected_item['price']} ТС**",
                    inline=True
                )
                embed.add_field(
                    name="📝 Описание",
                    value=self.selected_item.get('description', 'Без описания')[:1024],
                    inline=False
                )
                embed.add_field(
                    name="🏷️ Тип",
                    value=self.selected_item.get('item_type', 'unknown'),
                    inline=True
                )
                embed.add_field(
                    name="📊 Макс. стек",
                    value=self.selected_item.get('max_stack', 1),
                    inline=True
                )
            embed.set_footer(text="💡 Предметы попадают в инвентарь после покупки")
            embed.set_thumbnail(url="https://emojicdn.elk.sh/📦")
        else:
            # Режим покупки динозавров
            embed = discord.Embed(
                title="🦖 TAPKIN SHOP - Динозавры 🦖",
                description="""### Выберите категорию и динозавра для покупки ниже в выпадающем списке.
💡 **Дополнительная информация:**
>>> - После покупки, динозавр добавится в ваш **инвентарь**.
- Чтобы активировать динозавра в игру, перейдите в **Главное меню → Инвентарь**.
- Выберите динозавра из инвентаря и нажмите "Активировать в игру".""",
                color=discord.Color.gold()
            )
            if self.selected_category and self.selected_category != "items_shop":
                emoji = CATEGORY_EMOJIS.get(self.selected_category, "")
                embed.add_field(
                    name="Категория",
                    value=f"{emoji} **{self.selected_category}**",
                    inline=True
                )
            if self.selected_dino and self.selected_price is not None:
                embed.add_field(
                    name="Динозавр",
                    value=f"**{self.selected_dino}**\nЦена: **{self.selected_price} ТС**",
                    inline=True
                )
                details = DINOSAURS.get(self.selected_dino)
                if details:
                    embed.add_field(
                        name="В группе разрешено",
                        value=details.get("group_limit", "?"),
                        inline=True
                    )
                    embed.add_field(
                        name="Макс. вес",
                        value=details['weight'],
                        inline=False
                    )
                    embed.add_field(name="Скорость бега", value=details["speed"], inline=False)
                    embed.add_field(name="Сила укуса", value=details["bite"], inline=False)
                    embed.set_image(url=details["image"])
            embed.set_footer(
                text="💡 Динозавры попадают в инвентарь, откуда их можно активировать в игру")
            embed.set_thumbnail(url="https://emojicdn.elk.sh/🦖")
        return embed

    async def load_items(self):
        """Загружает предметы из БД и обновляет select (для режима items_shop)"""
        if not self.is_items_mode:
            return
            
        items = await ItemCRUD.get_all_items(active_only=True)
        options = []
        
        for item in items:
            type_emoji = {
                "dinosaur": "🦖",
                "nutrients": "💊",
                "food_water": "🍖",
                "currency": "💰",
                "special": "⭐"
            }.get(item['item_type'], "📦")
            label = f"{type_emoji} {item['name']} — {item['price']} ТС"
            description = item['description'][:100] if item.get('description') else ""
            options.append(discord.SelectOption(
                label=label[:100],
                value=str(item['id']),
                description=description[:100] if description else None
            ))
        
        placeholder = (
            f"Выбран: {self.selected_item['name'] if self.selected_item else ''}"
            if self.selected_item else "Выберите предмет"
        )
        
        # Обновляем select
        self.remove_item(self.dino_select)
        self.dino_select = Select(
            placeholder=placeholder,
            options=options if options else [
                discord.SelectOption(label="Предметы не найдены", value="none", default=True, description="Создайте предметы через /create_item")],
            custom_id="select_dino",
            disabled=len(options) == 0,
            row=1
        )
        self.add_item(self.dino_select)
        
        # Обновляем кнопку "Купить"
        self.buy_button.disabled = not (self.selected_item and self.selected_item.get('price'))

    async def update_view(self, interaction: discord.Interaction):
        self.remove_item(self.category_select)
        self.remove_item(self.dino_select)
        self.category_select = self.create_category_select()
        
        if self.is_items_mode:
            await self.load_items()
        else:
            self.dino_select = self.create_dino_select()
            self.add_item(self.dino_select)
        
        self.add_item(self.category_select)
        
        # Обновляем состояние кнопки "Купить"
        if self.is_items_mode:
            self.buy_button.disabled = not (self.selected_item and self.selected_item.get('price'))
        else:
            self.buy_button.disabled = not (self.selected_dino and self.selected_price is not None)
        
        # Проверяем, было ли взаимодействие уже обработано
        if interaction.response.is_done():
            await interaction.followup.edit_message(interaction.message.id, embed=self.embed, view=self)
        else:
            await interaction.response.edit_message(embed=self.embed, view=self)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        if custom_id == "select_category":
            self.selected_category = interaction.data["values"][0]
            if self.selected_category == "items_shop":
                # Переключаемся в режим покупки предметов из БД
                self.is_items_mode = True
                self.selected_dino = None
                self.selected_price = None
                self.selected_item = None
            else:
                # Режим покупки динозавров
                self.is_items_mode = False
                self.selected_dino = None
                self.selected_price = None
                self.selected_item = None
            await self.update_view(interaction)
            
        elif custom_id == "select_dino":
            if self.is_items_mode and self.selected_category == "items_shop":
                # Выбор предмета из БД
                item_id = int(interaction.data["values"][0])
                item = await ItemCRUD.get_item_by_id(item_id)
                if item:
                    self.selected_item = item
                await self.update_view(interaction)
            elif self.selected_category and self.selected_category != "items_shop":
                # Выбор динозавра
                dino_class = interaction.data["values"][0]
                self.selected_dino = find_name_by_class(dino_class)
                self.selected_price = DINOSAURS.get(self.selected_dino).get("price", 0)
            await self.update_view(interaction)
            
        elif custom_id == "buy_item_or_dino":
            logger.info(f"[DinoShopView] Кнопка 'Купить' нажата пользователем {interaction.user.id}")
            logger.info(f"[DinoShopView] is_items_mode={self.is_items_mode}, selected_item={self.selected_item}, selected_dino={self.selected_dino}")
            
            if self.is_items_mode and self.selected_item:
                # Покупка предмета из БД (добавление в инвентарь)
                logger.info(f"[DinoShopView] Создаем PurchaseItemQuantityModal для предмета {self.selected_item['id']}")
                # Получаем ID сообщения для редактирования после покупки
                message_id = interaction.message.id if interaction.message else None
                modal = PurchaseItemQuantityModal(
                    self.selected_item['id'],
                    self.selected_item['name'],
                    self.selected_item['price'],
                    self,
                    message_id
                )
                logger.info(f"[DinoShopView] Отправляем модальное окно PurchaseItemQuantityModal")
                try:
                    await interaction.response.send_modal(modal)
                    logger.info(f"[DinoShopView] Модальное окно успешно отправлено")
                except Exception as e:
                    logger.error(f"[DinoShopView] Ошибка при отправке модального окна: {e}", exc_info=True)
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Не удалось открыть форму покупки. Ошибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
            elif self.selected_dino and self.selected_price is not None:
                # Покупка динозавра (добавление в инвентарь как Item)
                logger.info(f"[DinoShopView] Создаем PurchaseDinoQuantityModal для динозавра {self.selected_dino}")
                # Получаем ID сообщения для редактирования после покупки
                message_id = interaction.message.id if interaction.message else None
                modal = PurchaseDinoQuantityModal(self.selected_dino, self.selected_price, self, message_id)
                logger.info(f"[DinoShopView] Отправляем модальное окно PurchaseDinoQuantityModal")
                try:
                    await interaction.response.send_modal(modal)
                    logger.info(f"[DinoShopView] Модальное окно успешно отправлено")
                except Exception as e:
                    logger.error(f"[DinoShopView] Ошибка при отправке модального окна: {e}", exc_info=True)
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description=f"Не удалось открыть форму покупки. Ошибка: {str(e)}",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
                
        elif custom_id == "back_to_menu":
            from views.main_menu import MainMenuView
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = MainMenuView(steam_data, interaction.user.id)
            await view.update_player_data(interaction.user.id)
            await interaction.response.edit_message(embed=view.embed, view=view, content=None)
        elif custom_id == "close":
            await interaction.response.defer()
            await interaction.delete_original_response()
        return False
