import re
from dataclasses import dataclass, field
from typing import Optional, List, Dict
import asyncio
import logging

# Используем gamercon_async как в оригинальном коде
try:
    from gamercon_async import EvrimaRCON
except ImportError:
    EvrimaRCON = None
    print("WARNING: gamercon_async not installed. RCON functions will not work.")

logger = logging.getLogger(__name__)


@dataclass
class PlayerData:
    name: Optional[str] = None
    player_id: Optional[str] = None
    location: Optional[Dict[str, float]] = field(default_factory=dict)
    dino_class: Optional[str] = None
    growth: Optional[float] = None
    health: Optional[float] = None
    stamina: Optional[float] = None
    hunger: Optional[float] = None
    thirst: Optional[float] = None

    def __str__(self):
        return f"PlayerData(name={self.name}, player_id={self.player_id}, location={self.location}, dino_class={self.dino_class}, growth={self.growth}, health={self.health}, stamina={self.stamina}, hunger={self.hunger}, thirst={self.thirst})"


def parse_player_data(response: str) -> List[PlayerData]:
    player_blocks = re.split(
        r'(?:\[\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}\]\s*)?Name: |(?:\[\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}\]\s*)?PlayerDataName: ',
        response)
    players = []
    for block in player_blocks:
        if not block.strip():
            continue

        if not block.startswith("Name:") and not block.startswith("PlayerDataName:"):
            block = "Name: " + block

        name_match = re.search(r"Name: ([^,]+)", block)
        if not name_match:
            name_match = re.search(r"PlayerDataName: ([^,]+)", block)
        name = name_match.group(1).strip() if name_match else None

        player_id_match = re.search(r"PlayerID: (\d+)", block)
        player_id = player_id_match.group(1) if player_id_match else None

        location_match = re.search(r"Location: X=([-\d\.]+) Y=([-\d\.]+) Z=([-\d\.]+)", block)
        location = {}
        if location_match:
            location = {
                "X": float(location_match.group(1)),
                "Y": float(location_match.group(2)),
                "Z": float(location_match.group(3)),
            }

        dino_class_match = re.search(r"Class: ([^,]+)", block)
        dino_class = dino_class_match.group(1) if dino_class_match else None

        def extract_float(field: str) -> Optional[float]:
            m = re.search(rf"{field}: ([\d\.]+)", block)
            return float(m.group(1)) if m else None

        growth_value = extract_float("Growth")
        growth = 100 / 0.75 * growth_value / 100 if growth_value is not None else None
        health = extract_float("Health")
        stamina = extract_float("Stamina")
        hunger = extract_float("Hunger")
        thirst = extract_float("Thirst")

        players.append(PlayerData(
            name=name,
            player_id=player_id,
            location=location,
            dino_class=dino_class,
            growth=growth,
            health=health,
            stamina=stamina,
            hunger=hunger,
            thirst=thirst,
        ))
    return players


def find_player_by_id(players: List[PlayerData], player_id: str) -> Optional[PlayerData]:
    for player in players:
        if player.player_id == player_id:
            return player
    return None


def execute_rcon_command(host: str, port: int, password: str, command: str) -> Optional[str]:
    """Выполняет RCON команду напрямую"""
    # Эта функция не используется, оставлена для совместимости
    # Используйте send_direct_rcon_command вместо этого
    logger.warning("execute_rcon_command is deprecated, use send_direct_rcon_command instead")
    return None


async def send_direct_rcon_command(rcon_host: str, rcon_port: int, rcon_password: str, command: str) -> Optional[str]:
    """Отправляет RCON команду напрямую с обработкой ошибок"""
    if EvrimaRCON is None:
        raise ImportError("gamercon_async not installed. Install with: pip install gamercon-async")
    try:
        # Используем оригинальный подход с gamercon_async
        rcon = EvrimaRCON(rcon_host, rcon_port, rcon_password)
        await rcon.connect()
        
        # Форматируем команду в байты как в оригинальном коде
        # Based on the server configuration, we need to use the correct command format
        if command == "listplayers":
            # Используем правильный формат команды как в рабочем коде
            formatted_command = b"\x02\x77\x00"
        elif command.startswith(("sethealth", "sethunger", "setthirst", "setstamina", "teleport", "broadcast", "save")):
            # Для игровых команд используем текстовый формат с нулевым байтом в конце
            formatted_command = command.encode() + b"\x00"
        elif command.startswith("say "):
            # Для say команд
            formatted_command = command.encode() + b"\x00"
        else:
            # Для других команд используем стандартный формат
            formatted_command = b"\x02" + command.encode() + b"\x00"
            
        response = await rcon.send_command(formatted_command)
        return response
    except Exception as e:
        logger.error(f"Error executing RCON command {command}: {e}")
        return None


async def fetch_all_players(rcon_host: str, rcon_port: int, rcon_password: str) -> List[PlayerData]:
    """Получает список всех игроков на сервере"""
    response = await send_direct_rcon_command(rcon_host, rcon_port, rcon_password, "listplayers")
    if response and "Connection lost" not in response and "Error" not in response:
        return parse_player_data(response)
    return []


async def fetch_player_by_id(rcon_host: str, rcon_port: int, rcon_password: str, player_id: str) -> Optional[
    PlayerData]:
    all_players = await fetch_all_players(rcon_host, rcon_port, rcon_password)
    return find_player_by_id(all_players, player_id)


async def send_dm_message(rcon_host: str, rcon_port: int, rcon_password: str, player_id: str, content="test"):
    if EvrimaRCON is None:
        raise ImportError("gamercon_async not installed. Install with: pip install gamercon-async")
    player = await fetch_player_by_id(rcon_host, rcon_port, rcon_password, player_id)
    if not player:
        return
    rcon = EvrimaRCON(rcon_host, rcon_port, rcon_password)
    await rcon.connect()
    formatted_message = f"{player_id},{content}"
    response = await rcon.send_command(b"\x02" + b"\x11," + formatted_message.encode() + b"\x00")
    return response


async def rcon_ban(rcon_host: str, rcon_port: int, rcon_password: str, player_id: str, duration: int,
                   reason="Отсутствует"):
    if EvrimaRCON is None:
        raise ImportError("gamercon_async not installed. Install with: pip install gamercon-async")
    player = await fetch_player_by_id(rcon_host, rcon_port, rcon_password, player_id)
    if not player:
        return
    rcon = EvrimaRCON(rcon_host, rcon_port, rcon_password)
    await rcon.connect()
    formatted_message = f"{player_id}"
    response = await rcon.send_command(b"\x02" + b"\x20" + formatted_message.encode() + b"\x00")
    return response

async def heal_player_dino(rcon_host: str, rcon_port: int, rcon_password: str, player_name: str) -> Optional[str]:
    """Лечит динозавра игрока"""
    command = f"sethealth {player_name} 100"
    return await send_direct_rcon_command(rcon_host, rcon_port, rcon_password, command)


async def feed_player_dino(rcon_host: str, rcon_port: int, rcon_password: str, player_name: str) -> Optional[str]:
    """Кормит динозавра игрока"""
    command = f"sethunger {player_name} 100"
    return await send_direct_rcon_command(rcon_host, rcon_port, rcon_password, command)


async def restore_player_dino(rcon_host: str, rcon_port: int, rcon_password: str, player_name: str) -> Optional[str]:
    """Полностью восстанавливает динозавра игрока"""
    # Используем правильные команды для восстановления, как указано в конфигурации сервера
    commands = [
        f"sethealth {player_name} 100",
        f"sethunger {player_name} 100",
        f"setthirst {player_name} 100",
        f"setstamina {player_name} 100"
    ]
    
    results = []
    for command in commands:
        result = await send_direct_rcon_command(rcon_host, rcon_port, rcon_password, command)
        # Даже если результат None, продолжаем выполнение других команд
        results.append(result or f"Command sent: {command}")
        await asyncio.sleep(0.1)  # Небольшая задержка между командами
    
    return "\\n".join(filter(None, results)) if any(results) else None
