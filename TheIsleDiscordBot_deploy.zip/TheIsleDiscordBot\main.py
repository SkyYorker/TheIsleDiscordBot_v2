import asyncio
import os
import sys
import json

# ПРИМЕНЯЕМ ПАТЧИ ДО ИМПОРТА МОДУЛЕЙ
import discord
from discord.ext import commands
from discord import app_commands

# Добавляем ApplicationContext в discord для обратной совместимости
# В discord.py 2.6.4 ApplicationContext находится в app_commands
discord.ApplicationContext = app_commands.AppCommandContext

from dotenv import load_dotenv
from pathlib import Path

# Загружаем .env из папки, где находится main.py
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)

# Используем тестовый токен, если он есть, иначе основной
TEST_DISCORD_TOKEN = os.getenv("TEST_DISCORD_TOKEN")
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

if TEST_DISCORD_TOKEN:
    TOKEN_TO_USE = TEST_DISCORD_TOKEN
    print("[TEST] Используется тестовый токен (TEST_DISCORD_TOKEN)")
elif DISCORD_TOKEN:
    TOKEN_TO_USE = DISCORD_TOKEN
    print("[OK] Используется основной токен (DISCORD_TOKEN)")
else:
    print("[ERROR] Не найден ни TEST_DISCORD_TOKEN, ни DISCORD_TOKEN в .env файле!")
    exit(1)

os.environ["DISCORD_TOKEN"] = TOKEN_TO_USE

from database.crud import init_models

import logging

# Настраиваем базовое логирование для всех модулей
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(filename='discord.log', encoding='utf-8', mode='a'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('discord')
logger.setLevel(logging.INFO)

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

# Добавляем поддержку slash_command декоратора для py-cord
# В py-cord нет commands.slash_command, поэтому создаем его для совместимости

# Создаем класс Option для совместимости с кодом (глобально для использования в register_slash_commands_from_cog)
class Option:
    """Класс Option для определения параметров slash команд"""
    def __init__(self, type_, description=None, **kwargs):
        self.type = type_
        self.description = description or ""
        self.kwargs = kwargs

def _patch_slash_command():
    """Добавляет поддержку commands.slash_command через app_commands"""
    from discord import app_commands
    
    # Добавляем Option в discord.app_commands для импорта
    app_commands.Option = Option
    
    def slash_command(name=None, description=None, **kwargs):
        """Декоратор для создания slash команд через app_commands"""
        def decorator(func):
            # Просто помечаем функцию как slash команду
            # Регистрация будет выполнена позже через bot.tree.command
            cmd_name = name or func.__name__
            cmd_desc = description or func.__doc__ or ""
            
            func._is_slash_command = True
            func._slash_command_name = cmd_name
            func._slash_command_description = cmd_desc
            func._slash_command_kwargs = kwargs
            
            return func
        return decorator
    commands.slash_command = slash_command
    
    # Также добавляем Option в commands для импорта
    commands.Option = Option

# Применяем патч ДО импорта модулей, которые используют commands.slash_command
_patch_slash_command()

# Теперь импортируем views и cogs после применения патча
from views.auth_view import AuthView
from views.main_menu import MainMenuView, KillDinoResultView
from cogs.main_menu_cog import WelcomeView
from views.inventory_view import InventoryView
from views.dino_shop import DinoShopView, DinoPurchaseConfirmationView
from views.dinosaurs import DinosaurSelectView, DinosaurDeleteSelectView
from views.bonus_code_view import BonusCodeView, AdminBonusCodeView
from views.subscription_management_view import SubscriptionManagementView, SubscriptionConfirmView
from views.deposit_view import DepositView
from views.save_dino import SaveDinoView
from views.kill_dino_confirm import KillDinoConfirmView
from views.nutrients_view import OtherServicesView
from views.role_bonus_view import RoleBonusView
import discord

# Функция для регистрации slash команд из cog в bot.tree
async def register_slash_commands_from_cog(cog):
    """Регистрирует все slash команды из cog в bot.tree"""
    from discord import app_commands
    import inspect
    
    print(f"[DEBUG] Регистрация команд из cog: {cog.__class__.__name__}")
    found_commands = 0
    
    # Проверяем все методы класса
    for attr_name in dir(cog):
        # Пропускаем служебные методы
        if attr_name.startswith('_'):
            continue
            
        attr = getattr(cog, attr_name)
        
        # Проверяем, является ли это методом и помечен ли как slash команда
        if not callable(attr):
            continue
            
        if not (hasattr(attr, '_is_slash_command') and attr._is_slash_command):
            continue
        
        found_commands += 1
        print(f"[DEBUG] Найдена команда: {attr_name}")
            
        try:
            cmd_name = getattr(attr, '_slash_command_name', attr.__name__)
            cmd_desc = getattr(attr, '_slash_command_description', attr.__doc__ or "")
            
            # Получаем сигнатуру функции
            sig = inspect.signature(attr)
            
            # Извлекаем список параметров команды (кроме self и ctx)
            command_params = []
            for param_name, param in sig.parameters.items():
                if param_name not in ('self', 'ctx'):
                    command_params.append(param_name)
            
            # Создаем функцию-обертку с правильными аннотациями типов
            def create_wrapper(original_func, cog_instance, expected_params):
                # Получаем несвязанный метод, если это связанный метод
                # Это необходимо, чтобы избежать двойной передачи self
                if hasattr(original_func, '__func__'):
                    # Это связанный метод, получаем несвязанный
                    unbound_method = original_func.__func__
                else:
                    # Это уже несвязанный метод или функция
                    unbound_method = original_func
                
                # Создаем wrapper, который принимает interaction и параметры команды
                # discord.app_commands.Command вызывает callback(interaction, **params)
                async def wrapper(interaction: discord.Interaction, **kwargs):
                    # Создаем простой wrapper для совместимости с ApplicationContext
                    # В py-cord Interaction имеет все необходимые методы, но использует 'user' вместо 'author'
                    class ContextWrapper:
                        def __init__(self, interaction):
                            self._interaction = interaction
                            # Добавляем атрибут author для совместимости
                            self.author = interaction.user
                            # Проксируем все остальные атрибуты и методы
                            for attr_name in dir(interaction):
                                if not attr_name.startswith('_') and attr_name != 'user':
                                    try:
                                        setattr(self, attr_name, getattr(interaction, attr_name))
                                    except:
                                        pass
                        
                        async def respond(self, *args, **kwargs):
                            """Метод respond для совместимости с ApplicationContext"""
                            # В py-cord используется interaction.response.send_message()
                            return await self._interaction.response.send_message(*args, **kwargs)
                        
                        async def defer(self, *args, **kwargs):
                            """Метод defer для совместимости с ApplicationContext"""
                            return await self._interaction.response.defer(*args, **kwargs)
                        
                        @property
                        def followup(self):
                            """Свойство followup для совместимости с ApplicationContext"""
                            return self._interaction.followup
                        
                        @property
                        def response(self):
                            """Свойство response для совместимости"""
                            return self._interaction.response
                        
                        def __getattr__(self, name):
                            # Если атрибут не найден, пробуем получить его из interaction
                            return getattr(self._interaction, name)
                    
                    ctx = ContextWrapper(interaction)
                    # Фильтруем kwargs: передаем только те параметры, которые есть в сигнатуре оригинальной функции
                    filtered_kwargs = {k: v for k, v in kwargs.items() if k in expected_params}
                    # Вызываем оригинальную функцию с cog как self и ctx
                    # Используем несвязанный метод и передаем cog_instance как self
                    if filtered_kwargs:
                        return await unbound_method(cog_instance, ctx, **filtered_kwargs)
                    else:
                        return await unbound_method(cog_instance, ctx)
                return wrapper
            
            wrapper = create_wrapper(attr, cog, command_params)
            
            # Исправляем аннотации типов в сигнатуре для app_commands.Command
            params = []
            # Первый параметр - interaction (но мы его не добавляем, так как app_commands.Command добавляет его автоматически)
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue  # Пропускаем self
                elif param_name == 'ctx':
                    continue  # Пропускаем ctx, так как мы передаем его из interaction
                else:
                    # Проверяем, является ли аннотация Option
                    annotation = param.annotation
                    if isinstance(annotation, Option):
                        # Заменяем Option на обычный тип
                        params.append(inspect.Parameter(param_name, param.kind, 
                                                       annotation=annotation.type,
                                                       default=param.default))
                    elif annotation != inspect.Parameter.empty:
                        params.append(param)
                    else:
                        params.append(param)
            
            # Создаем новую сигнатуру для wrapper
            # app_commands.Command ожидает callback(interaction, **params)
            wrapper_params = [inspect.Parameter('interaction', inspect.Parameter.POSITIONAL_OR_KEYWORD,
                                               annotation=discord.Interaction)]
            wrapper_params.extend(params)
            wrapper.__signature__ = inspect.Signature(wrapper_params)
            wrapper.__name__ = attr.__name__
            wrapper.__doc__ = attr.__doc__
            
            # Регистрируем команду через app_commands.Command
            cmd = app_commands.Command(name=cmd_name, description=cmd_desc, callback=wrapper)
            bot.tree.add_command(cmd)
            
            print(f"[CMD] Зарегистрирована команда /{cmd_name} из {cog.__class__.__name__}")
        except Exception as e:
            print(f"[ERROR] Ошибка регистрации команды {attr_name}: {e}")
            import traceback
            traceback.print_exc()
    
    if found_commands == 0:
        print(f"[WARN] В cog {cog.__class__.__name__} не найдено slash команд")
        # Выводим все методы для отладки
        print(f"[DEBUG] Методы в cog {cog.__class__.__name__}:")
        for attr_name in dir(cog):
            if not attr_name.startswith('_'):
                attr = getattr(cog, attr_name)
                if callable(attr):
                    has_flag = hasattr(attr, '_is_slash_command')
                    print(f"  {attr_name}: callable={callable(attr)}, _is_slash_command={has_flag}")


@bot.event
async def on_ready():
    # Загружаем расширения асинхронно (если они еще не загружены)
    if len(bot.extensions) == 0:
        print(f"[LOAD] Загружаем расширения асинхронно...")
        extensions = [
            "cogs.dino_fast_commands_cog",
            "cogs.main_menu_cog",
            "cogs.admin_donate_cog",
            "cogs.admin_items_cog",
            "cogs.admin_bonus_codes_cog",
            "cogs.save_manager_cog",
            "cogs.dino_rcon_commands_cog",
            "cogs.automation_cog",
        ]
        
        loaded_count = 0
        for ext in extensions:
            try:
                await bot.load_extension(ext)
                # После загрузки расширения, регистрируем его slash команды
                # Получаем имя cog из имени модуля
                # Формат: cogs.dino_fast_commands_cog -> DinoFastCommandsCog
                module_name = ext.split('.')[-1]  # dino_fast_commands_cog
                # Преобразуем в CamelCase: dino_fast_commands_cog -> DinoFastCommandsCog
                parts = module_name.replace('_cog', '').split('_')
                cog_name = ''.join(word.capitalize() for word in parts) + 'Cog'
                
                # Ищем cog по имени класса из всех загруженных cogs
                cog_instance = None
                # Сначала пробуем точное совпадение
                for cog in list(bot.cogs.values()):  # Создаем список для стабильности
                    if cog.__class__.__name__ == cog_name:
                        cog_instance = cog
                        break
                
                # Если не нашли, пробуем найти по части имени
                if not cog_instance:
                    for cog in list(bot.cogs.values()):
                        class_name = cog.__class__.__name__
                        # Проверяем, содержит ли имя класса ключевые слова из модуля
                        module_keywords = module_name.replace('_cog', '').split('_')
                        class_name_lower = class_name.lower()
                        if all(keyword in class_name_lower for keyword in module_keywords):
                            cog_instance = cog
                            break
                
                if cog_instance:
                    print(f"[DEBUG] Найден cog: {cog_instance.__class__.__name__} для расширения {ext}")
                    await register_slash_commands_from_cog(cog_instance)
                else:
                    print(f"[WARN] Cog не найден для расширения {ext} (ожидалось: {cog_name})")
                    # Выводим список всех доступных cogs для отладки
                    all_cogs = [cog.__class__.__name__ for cog in bot.cogs.values()]
                    print(f"[DEBUG] Доступные cogs: {all_cogs}")
                loaded_count += 1
                print(f"[OK] Расширение {ext} загружено")
            except Exception as e:
                logger.error(f"Ошибка загрузки расширения {ext}: {e}", exc_info=True)
                print(f"[ERROR] Не удалось загрузить расширение {ext}: {e}")
                import traceback
                traceback.print_exc()
        print(f"[LOAD] Загрузка завершена. Загружено: {loaded_count} (bot.extensions: {len(bot.extensions)})")
    
    # Регистрируем все persistent views для работы кнопок после перезапуска бота
    # Это предотвращает проблему, когда кнопки становятся неактивными через некоторое время
    # 
    # ВАЖНО: Все View с timeout=None и кнопками custom_id автоматически становятся persistent
    # если они зарегистрированы через bot.add_view(). Это гарантирует, что кнопки
    # будут работать даже после перезапуска бота и бесконечно долго.
    try:
        # Создаем пустой embed для инициализации View
        empty_embed = discord.Embed(title="", description="")
        
        # Регистрируем основные View
        bot.add_view(AuthView())
        bot.add_view(WelcomeView())
        
        # KillDinoResultView с пустыми параметрами для регистрации
        bot.add_view(KillDinoResultView(None, None))
        
        # Создаем упрощенные версии View для регистрации persistent кнопок
        # Discord.py будет обрабатывать кнопки по custom_id
        class PersistentMainMenuView(MainMenuView):
            """Упрощенная версия MainMenuView для persistent регистрации"""
            def __init__(self):
                super().__init__(steam_data={"username": "", "avatar": "", "steamid": ""}, user_id=0)
        
        class PersistentInventoryView(InventoryView):
            """Упрощенная версия InventoryView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentDinoShopView(DinoShopView):
            """Упрощенная версия DinoShopView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentDinosaurSelectView(DinosaurSelectView):
            """Упрощенная версия DinosaurSelectView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView(), [])
        
        class PersistentDinosaurDeleteSelectView(DinosaurDeleteSelectView):
            """Упрощенная версия DinosaurDeleteSelectView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView(), [])
        
        class PersistentBonusCodeView(BonusCodeView):
            """Упрощенная версия BonusCodeView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentAdminBonusCodeView(AdminBonusCodeView):
            """Упрощенная версия AdminBonusCodeView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentSubscriptionManagementView(SubscriptionManagementView):
            """Упрощенная версия SubscriptionManagementView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView(), 0)
        
        class PersistentDepositView(DepositView):
            """Упрощенная версия DepositView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentSaveDinoView(SaveDinoView):
            """Упрощенная версия SaveDinoView для persistent регистрации"""
            def __init__(self):
                super().__init__(PersistentMainMenuView(), empty_embed)
        
        class PersistentKillDinoConfirmView(KillDinoConfirmView):
            """Упрощенная версия KillDinoConfirmView для persistent регистрации"""
            def __init__(self):
                # Используем None для dino_data и пустую функцию для callback
                async def empty_callback(*args, **kwargs):
                    pass
                super().__init__(None, empty_embed, PersistentMainMenuView(), empty_callback)
        
        class PersistentOtherServicesView(OtherServicesView):
            """Упрощенная версия OtherServicesView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
        
        class PersistentDinoPurchaseConfirmationView(DinoPurchaseConfirmationView):
            """Упрощенная версия DinoPurchaseConfirmationView для persistent регистрации"""
            def __init__(self):
                shop_view = PersistentDinoShopView()
                super().__init__(shop_view, empty_embed, PersistentMainMenuView())
        
        class PersistentSubscriptionConfirmView(SubscriptionConfirmView):
            """Упрощенная версия SubscriptionConfirmView для persistent регистрации"""
            def __init__(self):
                management_view = PersistentSubscriptionManagementView()
                super().__init__("basic", empty_embed, PersistentMainMenuView(), management_view, 0)
        
        class PersistentRoleBonusView(RoleBonusView):
            """Упрощенная версия RoleBonusView для persistent регистрации"""
            def __init__(self):
                super().__init__(empty_embed, PersistentMainMenuView())
         
        # Регистрируем все View
        bot.add_view(PersistentMainMenuView())
        bot.add_view(PersistentInventoryView())
        bot.add_view(PersistentDinoShopView())
        bot.add_view(PersistentDinosaurSelectView())
        bot.add_view(PersistentDinosaurDeleteSelectView())
        bot.add_view(PersistentBonusCodeView())
        bot.add_view(PersistentAdminBonusCodeView())
        bot.add_view(PersistentSubscriptionManagementView())
        bot.add_view(PersistentDepositView())
        bot.add_view(PersistentSaveDinoView())
        bot.add_view(PersistentKillDinoConfirmView())
        bot.add_view(PersistentOtherServicesView())
        bot.add_view(PersistentDinoPurchaseConfirmationView())
        bot.add_view(PersistentSubscriptionConfirmView())
        bot.add_view(PersistentRoleBonusView())
        
        print(f"[PERSISTENT] Регистрация persistent views...")
        print(f"[OK] AuthView зарегистрирован")
        print(f"[OK] WelcomeView зарегистрирован")
        print(f"[OK] KillDinoResultView зарегистрирован")
        print(f"[OK] MainMenuView зарегистрирован")
        print(f"[OK] InventoryView зарегистрирован")
        print(f"[OK] DinoShopView зарегистрирован")
        print(f"[OK] DinosaurSelectView зарегистрирован")
        print(f"[OK] DinosaurDeleteSelectView зарегистрирован")
        print(f"[OK] BonusCodeView зарегистрирован")
        print(f"[OK] AdminBonusCodeView зарегистрирован")
        print(f"[OK] SubscriptionManagementView зарегистрирован")
        print(f"[OK] DepositView зарегистрирован")
        print(f"[OK] SaveDinoView зарегистрирован")
        print(f"[OK] KillDinoConfirmView зарегистрирован")
        print(f"[OK] OtherServicesView зарегистрирован")
        print(f"[OK] DinoPurchaseConfirmationView зарегистрирован")
        print(f"[OK] SubscriptionConfirmView зарегистрирован")
        print(f"[OK] RoleBonusView зарегистрирован")
        print(f"[INFO] Все View с timeout=None и custom_id будут работать как persistent")
        print(f"[INFO] Кнопки останутся активными бесконечно долго, даже после перезапуска бота")
    except Exception as e:
        logger.error(f"Ошибка регистрации persistent views: {e}")
        print(f"[ERROR] Ошибка регистрации views: {e}")
        import traceback
        traceback.print_exc()
    
    # Синхронизируем слэш-команды с Discord (только после загрузки расширений)
    try:
        print(f"[SYNC] Начинаем синхронизацию слэш-команд с Discord...")
        print(f"[DEBUG] Расширений загружено: {len(bot.extensions)}")
        print(f"[DEBUG] Расширения: {list(bot.extensions)}")
        
        # Проверяем команды в дереве ДО синхронизации
        tree_commands_before = bot.tree.get_commands()
        print(f"[DEBUG] Команд в дереве до синхронизации: {len(tree_commands_before)}")
        for cmd in tree_commands_before:
            print(f"  - {cmd.name} ({type(cmd).__name__})")
        
        synced = await bot.tree.sync()
        print(f"[OK] Синхронизировано {len(synced)} слэш-команд с Discord")
        for cmd in synced:
            print(f"  - /{cmd.name}")
    except Exception as e:
        logger.error(f"Ошибка синхронизации команд: {e}", exc_info=True)
        print(f"[ERROR] Ошибка синхронизации команд: {e}")
        import traceback
        traceback.print_exc()
        synced = []  # Определяем переменную в случае ошибки
    
    print(f"Бот {bot.user} готов!")
    print(f"Загружено расширений: {len(bot.extensions)}")
    print(f"Загружено команд: {len(bot.commands)}")
    
    # Выводим список всех слэш-команд для проверки
    try:
        # В py-cord команды хранятся в bot.tree
        tree_commands = bot.tree.get_commands()
        slash_commands = [cmd for cmd in tree_commands if isinstance(cmd, discord.app_commands.Command)]
        print(f"Загружено слэш-команд в дереве команд: {len(slash_commands)}")
        for cmd in slash_commands:
            print(f"  - /{cmd.name}")
        
        # Если команды есть, но не синхронизированы, пробуем синхронизировать еще раз
        if len(slash_commands) > 0 and len(synced) == 0:
            print(f"[RETRY] Повторная синхронизация команд...")
            synced_retry = await bot.tree.sync()
            print(f"[OK] Повторно синхронизировано {len(synced_retry)} команд")
            for cmd in synced_retry:
                print(f"  - /{cmd.name}")
    except Exception as e:
        logger.warning(f"Не удалось получить список команд из дерева: {e}")
        print(f"[WARN] Не удалось получить список команд: {e}")

# Расширения будут загружены асинхронно в on_ready
# Это необходимо, так как load_extension в py-cord является асинхронной функцией


@bot.event
async def on_interaction(interaction: discord.Interaction):
    """Обработчик всех взаимодействий для логирования и обработки модальных окон"""
    if interaction.type == discord.InteractionType.modal_submit:
        logger.info(f"[BOT] ⚡ Модальное окно отправлено пользователем {interaction.user.id}")
        logger.info(f"[BOT] interaction.data: {interaction.data}")
        logger.info(f"[BOT] custom_id: {interaction.data.get('custom_id', 'NO CUSTOM_ID')}")
        
        # Обрабатываем модальные окна вручную, так как callback может не вызываться
        custom_id = interaction.data.get('custom_id', '')
        
        # Обрабатываем модальные окна создания бонус-кодов
        if custom_id == "create_bonus_code_tk_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода ТС: {custom_id}")
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 4:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            amount_value = input_values[2] if len(input_values) > 2 else None
            max_uses_value = input_values[3] if len(input_values) > 3 else None
            
            logger.info(f"[BOT] Извлечены значения: code={code_value}, desc={description_value}, amount={amount_value}, max_uses={max_uses_value}")
            
            # Валидация
            if not code_value or code_value.strip() == "":
                await interaction.response.send_message("❌ Пожалуйста, введите код.", ephemeral=True)
                return
            
            if not description_value or description_value.strip() == "":
                await interaction.response.send_message("❌ Пожалуйста, введите описание.", ephemeral=True)
                return
            
            try:
                amount = int(amount_value.strip()) if amount_value else 0
                if amount <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message("❌ Количество ТС должно быть положительным числом.", ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip()) if max_uses_value else 0
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message("❌ Макс использований должно быть положительным числом.", ephemeral=True)
                return
            
            # Создаем код
            try:
                from database.crud import BonusCodeCRUD
                from views.bonus_code_view import safe_respond
                
                code = code_value.strip().upper()
                description = description_value.strip()
                
                logger.info(f"[BOT] Создание бонус-кода: {code}, сумма: {amount}, макс: {max_uses}")
                bonus_code = await BonusCodeCRUD.create_bonus_code(
                    code=code,
                    description=description,
                    reward_type='tk',
                    reward_value=str(amount),
                    max_uses=max_uses,
                    created_by=interaction.user.id
                )
                logger.info(f"[BOT] Бонус-код успешно создан: {bonus_code}")
                
                embed = discord.Embed(
                    title="✅ Бонус-код создан",
                    description=f"**Код:** `{code}`\n**Описание:** {description}\n**Награда:** {amount} ТС\n**Максимум использований:** {max_uses}",
                    color=discord.Color.green()
                )
                await safe_respond(interaction, embed=embed, ephemeral=True)
            except Exception as e:
                logger.error(f"[BOT] Ошибка при создании бонус-кода: {e}", exc_info=True)
                error_embed = discord.Embed(
                    title="❌ Ошибка создания",
                    description=f"Произошла ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                await safe_respond(interaction, embed=error_embed, ephemeral=True)
            return
        
        elif custom_id == "create_bonus_code_subscription_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода подписки: {custom_id}")
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 5:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            tier_value = input_values[2] if len(input_values) > 2 else None
            duration_value = input_values[3] if len(input_values) > 3 else None
            max_uses_value = input_values[4] if len(input_values) > 4 else None
            
            logger.info(f"[BOT] Извлечены значения: code={code_value}, desc={description_value}, tier={tier_value}, duration={duration_value}, max_uses={max_uses_value}")
            
            # Валидация
            if not code_value or not description_value or not tier_value or not duration_value or not max_uses_value:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Все поля обязательны для заполнения.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Проверяем уровень подписки
            from database.models import SubscriptionTier
            tier_map = {
                'PLUS': SubscriptionTier.PLUS,
                'PREMIUM': SubscriptionTier.PREMIUM,
                'SUPREME': SubscriptionTier.SUPREME
            }
            tier_upper = tier_value.strip().upper()
            if tier_upper not in tier_map:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Неверный уровень подписки. Используйте: PLUS, PREMIUM или SUPREME.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            try:
                duration_days = int(duration_value.strip())
                if duration_days <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Длительность должна быть положительным числом.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip())
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Макс использований должно быть положительным числом.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Создаем JSON для reward_value
            reward_value = json.dumps({
                "tier": tier_upper,
                "duration_days": duration_days
            })
            
            # Создаем код
            from database.crud import BonusCodeCRUD
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code_value.strip().upper(),
                description=description_value.strip(),
                reward_type='subscription',
                reward_value=reward_value,
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code_value.strip().upper()}`\n**Описание:** {description_value.strip()}\n**Награда:** Подписка {tier_upper} на {duration_days} дней\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[BOT] Код подписки создан успешно: {code_value.strip().upper()}")
        
        elif custom_id == "create_bonus_code_nutrients_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода нутриентов: {custom_id}")
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 3:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            max_uses_value = input_values[2] if len(input_values) > 2 else None
            
            # Валидация
            if not code_value or not description_value or not max_uses_value:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Все поля обязательны для заполнения.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip())
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Макс использований должно быть положительным числом.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Создаем код (nutrients не требует дополнительных параметров)
            from database.crud import BonusCodeCRUD
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code_value.strip().upper(),
                description=description_value.strip(),
                reward_type='nutrients',
                reward_value='{}',  # Пустой JSON, так как параметров нет
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code_value.strip().upper()}`\n**Описание:** {description_value.strip()}\n**Награда:** Пополнение всех нутриентов\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[BOT] Код нутриентов создан успешно: {code_value.strip().upper()}")
        
        elif custom_id == "create_bonus_code_stats_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода статистик: {custom_id}")
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 3:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            max_uses_value = input_values[2] if len(input_values) > 2 else None
            
            # Валидация
            if not code_value or not description_value or not max_uses_value:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Все поля обязательны для заполнения.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip())
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Макс использований должно быть положительным числом.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Создаем код (stats не требует дополнительных параметров)
            from database.crud import BonusCodeCRUD
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code_value.strip().upper(),
                description=description_value.strip(),
                reward_type='stats',
                reward_value='{}',  # Пустой JSON, так как параметров нет
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code_value.strip().upper()}`\n**Описание:** {description_value.strip()}\n**Награда:** Пополнение статистик (здоровье, голод, жажда)\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[BOT] Код статистик создан успешно: {code_value.strip().upper()}")
        
        elif custom_id == "create_bonus_code_growth_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода грова: {custom_id}")
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 3:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            max_uses_value = input_values[2] if len(input_values) > 2 else None
            
            # Валидация
            if not code_value or not description_value or not max_uses_value:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Все поля обязательны для заполнения.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip())
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Макс использований должно быть положительным числом.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Создаем код (growth: рост 98%, голод 98%, жажда 98%)
            from database.crud import BonusCodeCRUD
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code_value.strip().upper(),
                description=description_value.strip(),
                reward_type='growth',
                reward_value='{}',  # Пустой JSON, параметры фиксированные
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code_value.strip().upper()}`\n**Описание:** {description_value.strip()}\n**Награда:** Гров на динозавра (рост 98%, голод 98%, жажда 98%)\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[BOT] Код грова создан успешно: {code_value.strip().upper()}")
        
        elif custom_id.startswith("create_item_code_modal_"):
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно создания бонус-кода предмета: {custom_id}")
            
            # Извлекаем item_id из custom_id
            try:
                item_id = int(custom_id.replace("create_item_code_modal_", ""))
            except (ValueError, TypeError):
                logger.error(f"[BOT] Не удалось извлечь item_id из custom_id: {custom_id}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось определить предмет для награды.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Получаем информацию о предмете
            try:
                from database.crud import ItemCRUD
                item = await ItemCRUD.get_item_by_id(item_id)
                if not item:
                    logger.error(f"[BOT] Предмет {item_id} не найден в базе данных")
                    error_embed = discord.Embed(
                        title="❌ Ошибка",
                        description="Предмет не найден в системе.",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=error_embed, ephemeral=True)
                    return
            except Exception as e:
                logger.error(f"[BOT] Ошибка при получении предмета: {e}", exc_info=True)
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось получить информацию о предмете: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Извлекаем значения из interaction.data
            input_values = []
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    if component.get('components'):
                        for sub_component in component.get('components', []):
                            if sub_component.get('type') == 4:  # InputText type
                                value = sub_component.get('value')
                                if value:
                                    input_values.append(value)
            
            if len(input_values) < 4:
                logger.error(f"[BOT] Не удалось извлечь все значения из модального окна. Получено: {len(input_values)}")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось получить все данные из формы. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            code_value = input_values[0] if len(input_values) > 0 else None
            description_value = input_values[1] if len(input_values) > 1 else None
            quantity_value = input_values[2] if len(input_values) > 2 else None
            max_uses_value = input_values[3] if len(input_values) > 3 else None
            
            logger.info(f"[BOT] Извлечены значения: code={code_value}, desc={description_value}, quantity={quantity_value}, max_uses={max_uses_value}, item_id={item_id}")
            
            # Валидация
            if not code_value or code_value.strip() == "":
                await interaction.response.send_message("❌ Пожалуйста, введите код.", ephemeral=True)
                return
            
            if not description_value or description_value.strip() == "":
                await interaction.response.send_message("❌ Пожалуйста, введите описание.", ephemeral=True)
                return
            
            try:
                quantity = int(quantity_value.strip()) if quantity_value else 0
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message("❌ Количество должно быть положительным числом.", ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_value.strip()) if max_uses_value else 0
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message("❌ Макс использований должно быть положительным числом.", ephemeral=True)
                return
            
            # Создаем код
            try:
                from database.crud import BonusCodeCRUD
                from views.bonus_code_view import safe_respond
                import json
                
                code = code_value.strip().upper()
                description = description_value.strip()
                
                # Создаем JSON для reward_value
                reward_value = json.dumps({
                    "item_id": item_id,
                    "quantity": quantity
                })
                
                logger.info(f"[BOT] Создание бонус-кода: {code}, предмет: {item['name']}, количество: {quantity}, макс: {max_uses}")
                bonus_code = await BonusCodeCRUD.create_bonus_code(
                    code=code,
                    description=description,
                    reward_type='item',
                    reward_value=reward_value,
                    max_uses=max_uses,
                    created_by=interaction.user.id
                )
                logger.info(f"[BOT] Бонус-код успешно создан: {bonus_code}")
                
                embed = discord.Embed(
                    title="✅ Бонус-код создан",
                    description=f"**Код:** `{code}`\n**Описание:** {description}\n**Награда:** {quantity}x {item['name']}\n**Максимум использований:** {max_uses}",
                    color=discord.Color.green()
                )
                await safe_respond(interaction, embed=embed, ephemeral=True)
            except Exception as e:
                logger.error(f"[BOT] Ошибка при создании бонус-кода: {e}", exc_info=True)
                error_embed = discord.Embed(
                    title="❌ Ошибка создания",
                    description=f"Произошла ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                await safe_respond(interaction, embed=error_embed, ephemeral=True)
            return
        
        if custom_id.startswith('purchase_item_modal_'):
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно покупки предмета вручную: {custom_id}")
            # Извлекаем item_id из custom_id
            item_id = int(custom_id.replace('purchase_item_modal_', ''))
            
            # Извлекаем значение из interaction.data
            quantity_value = None
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    for item in component.get('components', []):
                        if item.get('type') == 4:  # InputText type
                            quantity_value = item.get('value')
                            logger.info(f"[BOT] Извлечено значение количества: {quantity_value}")
                            break
                    if quantity_value:
                        break
            
            if not quantity_value:
                logger.error(f"[BOT] Не удалось извлечь значение из модального окна")
                await interaction.response.send_message(
                    "❌ Ошибка: не удалось получить значение из формы. Попробуйте еще раз.",
                    ephemeral=True
                )
                return
            
            # Импортируем необходимые модули
            from database.crud import DonationCRUD, InventoryCRUD, ItemCRUD
            from views.dino_shop import DinoPurchaseConfirmationView
            
            # Получаем данные предмета
            item = await ItemCRUD.get_item_by_id(item_id)
            if not item:
                logger.error(f"[BOT] Предмет {item_id} не найден в базе данных")
                await interaction.response.send_message(
                    "❌ Предмет не найден.",
                    ephemeral=True
                )
                return
            
            # Валидация количества
            try:
                quantity = int(quantity_value)
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[BOT] Некорректное количество: {quantity_value} (ошибка: {e})")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите корректное количество (целое число больше 0).",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            total_price = item['price'] * quantity
            logger.info(f"[BOT] Проверка баланса: требуется {total_price} ТС для покупки {quantity}x {item['name']}")
            
            # Проверяем существование игрока и получаем баланс
            current_balance = await DonationCRUD.get_tk(interaction.user.id)
            
            if current_balance is None:
                logger.warning(f"[BOT] Игрок {interaction.user.id} не найден в базе данных")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Ваш аккаунт не найден в системе.\n\n"
                                "Пожалуйста, привяжите свой Steam аккаунт через кнопку 'Привязать Steam' в главном меню.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            has_enough_tk = await DonationCRUD.check_balance(interaction.user.id, total_price)

            if not has_enough_tk:
                logger.warning(f"[BOT] Недостаточно ТС: баланс {current_balance}, требуется {total_price}")
                error_embed = discord.Embed(
                    title="❌ Недостаточно ТC",
                    description=f"У вас недостаточно ТC для покупки {quantity}x {item['name']}.\n\n"
                                f"**Требуется:** {total_price} ТС\n"
                                f"**Ваш баланс:** {current_balance} ТC",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            # Откладываем ответ для длительных операций
            logger.info(f"[BOT] Откладываем ответ для пользователя {interaction.user.id}")
            await interaction.response.defer(ephemeral=True)

            # Списываем деньги
            logger.info(f"[BOT] Списываем {total_price} ТС с баланса пользователя {interaction.user.id}")
            await DonationCRUD.remove_tk(interaction.user.id, total_price)
            
            # Добавляем предметы в инвентарь
            try:
                logger.info(f"[BOT] Добавляем {quantity}x предмет {item_id} в инвентарь")
                for i in range(quantity):
                    await InventoryCRUD.add_item_to_inventory(interaction.user.id, item_id, 1)
                    logger.debug(f"[BOT] Добавлен предмет {i+1}/{quantity}")
                
                # Получаем новый баланс
                new_balance = await DonationCRUD.get_tk(interaction.user.id)
                logger.info(f"[BOT] Покупка успешна. Новый баланс: {new_balance} ТС")
                
                # Создаем confirmation view (нужен shop_view, создадим упрощенную версию)
                from views.main_menu import MainMenuView
                empty_embed = discord.Embed(title="", description="")
                temp_main_menu = MainMenuView({"username": "", "avatar": "", "steamid": ""}, 0)
                temp_shop_view = type('TempShopView', (), {
                    'main_menu_embed': empty_embed,
                    'main_menu_view': temp_main_menu
                })()
                
                confirmation_view = DinoPurchaseConfirmationView(
                    temp_shop_view,
                    empty_embed,
                    temp_main_menu
                )

                embed = discord.Embed(
                    title="✅ Покупка успешна",
                    description=f"Вы купили **{quantity}x {item['name']}** за {total_price} ТС!\n\n"
                                f"Предметы добавлены в ваш инвентарь.\n"
                                f"Перейдите в **Главное меню → Инвентарь**, чтобы использовать их.",
                    color=discord.Color.green()
                )
                embed.add_field(name="💰 Потрачено", value=f"{total_price} ТС", inline=True)
                embed.add_field(name="💳 Осталось", value=f"{new_balance} ТС", inline=True)
                embed.add_field(name="📦 Предмет", value=f"{quantity}x {item['name']}", inline=False)
                embed.set_footer(text="Используйте предметы в инвентаре для применения в игре")
                
                await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
            except Exception as e:
                logger.error(f"[BOT] Ошибка при добавлении предметов в инвентарь: {e}", exc_info=True)
                # Возвращаем деньги при ошибке
                await DonationCRUD.add_tk(interaction.user.id, total_price)
                error_embed = discord.Embed(
                    title="❌ Ошибка покупки",
                    description=f"Не удалось добавить предметы в инвентарь.\n\n"
                                f"Деньги возвращены на ваш баланс.\n"
                                f"Ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
            
            return  # Важно! Прерываем дальнейшую обработку
        
        elif custom_id.startswith('purchase_dino_modal_'):
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно покупки динозавра вручную: {custom_id}")
            
            # Извлекаем название динозавра из custom_id
            dino_name_encoded = custom_id.replace('purchase_dino_modal_', '')
            # Восстанавливаем название (заменяем _ обратно на пробелы)
            dino_name = dino_name_encoded.replace('_', ' ')
            
            # Извлекаем значение из interaction.data
            quantity_value = None
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    for item in component.get('components', []):
                        if item.get('type') == 4:  # InputText type
                            quantity_value = item.get('value')
                            logger.info(f"[BOT] Извлечено значение количества динозавров: {quantity_value}")
                            break
                    if quantity_value:
                        break
            
            if not quantity_value:
                logger.error(f"[BOT] Не удалось извлечь значение из модального окна покупки динозавра")
                await interaction.response.send_message(
                    "❌ Ошибка: не удалось получить значение из формы. Попробуйте еще раз.",
                    ephemeral=True
                )
                return
            
            # Импортируем необходимые модули
            from database.crud import DonationCRUD, InventoryCRUD
            from views.dino_shop import DinoPurchaseConfirmationView, get_or_create_dino_item
            from data.dinosaurus import DINOSAURS
            
            # Получаем цену динозавра
            dino_data = DINOSAURS.get(dino_name)
            if not dino_data:
                logger.error(f"[BOT] Динозавр {dino_name} не найден в списке")
                await interaction.response.send_message(
                    "❌ Динозавр не найден.",
                    ephemeral=True
                )
                return
            
            price = dino_data.get('price', 0)
            
            # Валидация количества
            try:
                quantity = int(quantity_value)
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[BOT] Некорректное количество динозавров: {quantity_value} (ошибка: {e})")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите корректное количество (целое число больше 0).",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            total_price = price * quantity
            logger.info(f"[BOT] Проверка баланса: требуется {total_price} ТС для покупки {quantity}x {dino_name}")
            
            # Проверяем существование игрока и получаем баланс
            current_balance = await DonationCRUD.get_tk(interaction.user.id)
            
            if current_balance is None:
                logger.warning(f"[BOT] Игрок {interaction.user.id} не найден в базе данных")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Ваш аккаунт не найден в системе.\n\n"
                                "Пожалуйста, привяжите свой Steam аккаунт через кнопку 'Привязать Steam' в главном меню.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            has_enough_tk = await DonationCRUD.check_balance(interaction.user.id, total_price)

            if not has_enough_tk:
                logger.warning(f"[BOT] Недостаточно ТС: баланс {current_balance}, требуется {total_price}")
                error_embed = discord.Embed(
                    title="❌ Недостаточно ТC",
                    description=f"У вас недостаточно ТC для покупки {quantity}x {dino_name}.\n\n"
                                f"**Требуется:** {total_price} ТС\n"
                                f"**Ваш баланс:** {current_balance} ТC",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return

            # Откладываем ответ для длительных операций
            logger.info(f"[BOT] Откладываем ответ для пользователя {interaction.user.id}")
            await interaction.response.defer(ephemeral=True)

            # Получаем или создаем Item для динозавра
            dino_item = await get_or_create_dino_item(dino_name)
            if not dino_item:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось создать Item для динозавра {dino_name}.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
                return

            # Списываем деньги
            await DonationCRUD.remove_tk(interaction.user.id, total_price)
            
            # Добавляем динозавров в инвентарь
            try:
                for _ in range(quantity):
                    await InventoryCRUD.add_item_to_inventory(interaction.user.id, dino_item['id'], 1)
                
                # Получаем новый баланс
                new_balance = await DonationCRUD.get_tk(interaction.user.id)
                
                # Создаем confirmation view
                from views.main_menu import MainMenuView
                empty_embed = discord.Embed(title="", description="")
                temp_main_menu = MainMenuView({"username": "", "avatar": "", "steamid": ""}, 0)
                temp_shop_view = type('TempShopView', (), {
                    'main_menu_embed': empty_embed,
                    'main_menu_view': temp_main_menu
                })()
                
                confirmation_view = DinoPurchaseConfirmationView(
                    temp_shop_view,
                    empty_embed,
                    temp_main_menu
                )

                embed = discord.Embed(
                    title="✅ Покупка успешна",
                    description=f"Вы купили **{quantity}x {dino_name}** за {total_price} ТС!\n\n"
                                f"Динозавры добавлены в ваш инвентарь.\n"
                                f"Перейдите в **Главное меню → Инвентарь**, чтобы активировать их в игру.",
                    color=discord.Color.green()
                )
                embed.add_field(name="💰 Потрачено", value=f"{total_price} ТС", inline=True)
                embed.add_field(name="💳 Осталось", value=f"{new_balance} ТС", inline=True)
                embed.add_field(name="🦖 Динозавр", value=f"{quantity}x {dino_name}", inline=False)
                embed.set_footer(text="Активируйте динозавров из инвентаря для использования в игре")
                
                await interaction.followup.send(embed=embed, view=confirmation_view, ephemeral=True)
            except Exception as e:
                logger.error(f"[BOT] Ошибка при добавлении динозавров в инвентарь: {e}", exc_info=True)
                # Возвращаем деньги при ошибке
                await DonationCRUD.add_tk(interaction.user.id, total_price)
                error_embed = discord.Embed(
                    title="❌ Ошибка покупки",
                    description=f"Не удалось добавить динозавров в инвентарь.\n\n"
                                f"Деньги возвращены на ваш баланс.\n"
                                f"Ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
            
            return  # Важно! Прерываем дальнейшую обработку
        
        elif custom_id == "bonus_code_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно ввода бонус-кода вручную: {custom_id}")
            
            # Извлекаем значение из interaction.data
            code_value = None
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    for item in component.get('components', []):
                        if item.get('type') == 4:  # InputText type
                            code_value = item.get('value')
                            logger.info(f"[BOT] Извлечено значение бонус-кода: {code_value}")
                            break
                    if code_value:
                        break
            
            if not code_value:
                logger.error(f"[BOT] Не удалось извлечь значение из модального окна бонус-кода")
                await interaction.response.send_message(
                    "❌ Ошибка: не удалось получить код из формы. Попробуйте еще раз.",
                    ephemeral=True
                )
                return
            
            # Импортируем необходимые модули
            from database.crud import BonusCodeCRUD, DonationCRUD, InventoryCRUD, ItemCRUD
            
            code = code_value.strip().upper()
            logger.info(f"[BOT] Обработка бонус-кода: {code}")
            
            success, message, reward_data = await BonusCodeCRUD.use_bonus_code(code, interaction.user.id)
            
            if success and reward_data:
                # Обрабатываем награду
                reward_type = reward_data['reward_type']
                reward_value = reward_data['reward_value']
                
                try:
                    if reward_type == 'tk':
                        # Награда в ТС
                        tk_amount = int(reward_value)
                        await DonationCRUD.add_tk(interaction.user.id, tk_amount)
                        
                        embed = discord.Embed(
                            title="🎉 Бонус-код активирован!",
                            description=f"Вы получили **{tk_amount} ТС**!\n\n{reward_data['description']}",
                            color=discord.Color.gold()
                        )
                        
                    elif reward_type == 'item':
                        # Награда - предмет
                        item_data = json.loads(reward_value)
                        item_id = item_data['item_id']
                        quantity = item_data.get('quantity', 1)
                        
                        await InventoryCRUD.add_item_to_inventory(interaction.user.id, item_id, quantity)
                        item_info = await ItemCRUD.get_item_by_id(item_id)
                        
                        embed = discord.Embed(
                            title="🎉 Бонус-код активирован!",
                            description=f"Вы получили **{quantity}x {item_info['name']}**!\n\n{reward_data['description']}",
                            color=discord.Color.gold()
                        )
                        
                    elif reward_type == 'subscription':
                        # Награда - подписка
                        from database.models import SubscriptionTier
                        from database.crud import SubscriptionCRUD
                        
                        sub_data = json.loads(reward_value)
                        tier_str = sub_data['tier']
                        duration_days = sub_data['duration_days']
                        
                        tier_map = {
                            'PLUS': SubscriptionTier.PLUS,
                            'PREMIUM': SubscriptionTier.PREMIUM,
                            'SUPREME': SubscriptionTier.SUPREME
                        }
                        tier = tier_map.get(tier_str.upper())
                        
                        if not tier:
                            raise ValueError(f"Неверный уровень подписки: {tier_str}")
                        
                        sub_result = await SubscriptionCRUD.add_subscription(
                            interaction.user.id,
                            tier,
                            duration_days=duration_days
                        )
                        
                        embed = discord.Embed(
                            title="🎉 Бонус-код активирован!",
                            description=f"Вы получили подписку **{tier_str}** на {duration_days} дней!\n\n{reward_data['description']}",
                            color=discord.Color.gold()
                        )
                    
                    elif reward_type == 'nutrients':
                        # Награда - пополнение нутриентов
                        from utils.scripts import give_nutrients
                        
                        success, error = await give_nutrients(interaction.user.id)
                        if success:
                            embed = discord.Embed(
                                title="🎉 Бонус-код активирован!",
                                description=f"Все нутриенты пополнены!\n\n{reward_data['description']}",
                                color=discord.Color.gold()
                            )
                        else:
                            embed = discord.Embed(
                                title="⚠️ Бонус-код активирован",
                                description=f"Код активирован, но не удалось применить нутриенты: {error}\n\n{reward_data['description']}\n\nУбедитесь, что вы в игре и онлайн.",
                                color=discord.Color.orange()
                            )
                    
                    elif reward_type == 'stats':
                        # Награда - пополнение статистик (здоровье, голод, жажда)
                        from utils.scripts import give_food
                        from utils.rcon_isle import get_player_data
                        from utils.rcon_client import RCONClient
                        import os
                        
                        # Получаем Steam ID
                        from database.crud import get_steam_id_by_discord_id
                        steam_id = await get_steam_id_by_discord_id(interaction.user.id)
                        
                        if not steam_id:
                            embed = discord.Embed(
                                title="❌ Ошибка",
                                description="Не найден привязанный Steam аккаунт.",
                                color=discord.Color.red()
                            )
                        else:
                            # Пополняем еду/воду
                            food_success, food_error = await give_food(interaction.user.id)
                            
                            # Пополняем здоровье через RCON
                            health_success = False
                            HOST = os.getenv("RCON_HOST")
                            PORT = int(os.getenv("RCON_PORT", 0))
                            PASSWORD = os.getenv("RCON_PASSWORD")
                            
                            if HOST and PORT and PASSWORD:
                                try:
                                    rcon = RCONClient(HOST, PORT, PASSWORD)
                                    player_data = await get_player_data(steam_id, rcon)
                                    if player_data:
                                        await rcon.set_health(player_data.name, 100)
                                        health_success = True
                                except Exception as e:
                                    logger.error(f"[BOT] Ошибка при пополнении здоровья: {e}")
                            
                            if food_success or health_success:
                                embed = discord.Embed(
                                    title="🎉 Бонус-код активирован!",
                                    description=f"Статистики пополнены!\n\n{reward_data['description']}",
                                    color=discord.Color.gold()
                                )
                            else:
                                embed = discord.Embed(
                                    title="⚠️ Бонус-код активирован",
                                    description=f"Код активирован, но не удалось применить статистики.\n\n{reward_data['description']}\n\nУбедитесь, что вы в игре и онлайн.",
                                    color=discord.Color.orange()
                                )
                    
                    elif reward_type == 'growth':
                        # Награда - гров на динозавра (рост 98%, голод 98%, жажда 98%)
                        from utils.clicker_api import restore_dino
                        from database.crud import get_steam_id_by_discord_id
                        
                        steam_id = await get_steam_id_by_discord_id(interaction.user.id)
                        
                        if not steam_id:
                            embed = discord.Embed(
                                title="❌ Ошибка",
                                description="Не найден привязанный Steam аккаунт.",
                                color=discord.Color.red()
                            )
                        else:
                            result = await restore_dino(
                                steam_id,
                                growth=98,  # Рост 98%
                                hunger=98,  # Голод 98%
                                thirst=98,  # Жажда 98%
                                health=100  # Здоровье 100%
                            )
                            
                            if isinstance(result, dict) and result.get("success"):
                                embed = discord.Embed(
                                    title="🎉 Бонус-код активирован!",
                                    description=f"Гров применен! Рост: 98%, Голод: 98%, Жажда: 98%\n\n{reward_data['description']}",
                                    color=discord.Color.gold()
                                )
                            else:
                                embed = discord.Embed(
                                    title="⚠️ Бонус-код активирован",
                                    description=f"Код активирован, но не удалось применить гров.\n\n{reward_data['description']}\n\nУбедитесь, что вы в игре и онлайн.",
                                    color=discord.Color.orange()
                                )
                        
                    else:
                        embed = discord.Embed(
                            title="🎉 Бонус-код активирован!",
                            description=f"Награда: {reward_data['description']}",
                            color=discord.Color.gold()
                        )
                        
                except Exception as e:
                    logger.error(f"[BOT] Ошибка обработки награды: {e}", exc_info=True)
                    embed = discord.Embed(
                        title="❌ Ошибка обработки награды",
                        description=f"Код активирован, но произошла ошибка при выдаче награды: {str(e)}",
                        color=discord.Color.red()
                    )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка активации",
                    description=message,
                    color=discord.Color.red()
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return  # Прерываем дальнейшую обработку
        
        elif custom_id == "deposit_modal":
            logger.info(f"[BOT] 🔧 Обрабатываем модальное окно пополнения баланса: {custom_id}")
            
            # Извлекаем сумму из interaction.data
            amount_str = None
            if 'components' in interaction.data:
                for component in interaction.data.get('components', []):
                    for item_component in component.get('components', []):
                        if item_component.get('type') == 4:  # InputText type
                            amount_str = item_component.get('value')
                            logger.info(f"[BOT] Извлечено значение суммы: {amount_str}")
                            break
                    if amount_str:
                        break
            
            if not amount_str:
                logger.error(f"[BOT] Не удалось извлечь сумму из модального окна пополнения")
                await interaction.response.send_message(
                    "❌ Ошибка: не удалось получить сумму из формы. Попробуйте еще раз.",
                    ephemeral=True
                )
                return
            
            # Валидация суммы
            if not amount_str.isdigit():
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Пожалуйста, введите только число без пробелов и других символов.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            amount = int(amount_str)
            
            if amount < 1:
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Минимальная сумма пополнения - 1 рубль.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return
            
            # Используем UnitPay для пополнения
                logger.info(f"[BOT] Обычный режим: генерация URL для пополнения на {amount} руб.")
                
                from views.deposit_view import DepositView
                from utils.unitpay import UnitPayUrlGenerator
                from views.main_menu import MainMenuView
                
                payment_url = UnitPayUrlGenerator.generate_redirect_url(
                    amount=amount,
                    account=f"{interaction.user.id}_discord",
                    description="Вы пополняете счёт для Tapkin Evrima Discord Bot"
                )
                
                empty_embed = discord.Embed(title="", description="")
                temp_main_menu = MainMenuView({"username": "", "avatar": "", "steamid": ""}, 0)
                temp_deposit_view = DepositView(empty_embed, temp_main_menu)
                
                embed = await temp_deposit_view.create_deposit_embed(amount, payment_url)
                view = discord.ui.View(timeout=None)
                
                view.add_item(discord.ui.Button(
                    label="Пополнить",
                    style=discord.ButtonStyle.green,
                    url=payment_url
                ))
                
                view.add_item(discord.ui.Button(
                    label="Главное меню",
                    style=discord.ButtonStyle.blurple,
                    custom_id="back_to_main_menu"
                ))
                
                async def view_interaction_check(interaction: discord.Interaction) -> bool:
                    if interaction.data.get("custom_id") == "back_to_main_menu":
                        from utils.steam_api import steam_api
                        steam_data = await steam_api.get_steam_data(interaction.user.id)
                        view = MainMenuView(steam_data, interaction.user.id)
                        await view.update_player_data(interaction.user.id)
                        await interaction.response.edit_message(embed=view.embed, view=view, content=None)
                    return False
                
                view.interaction_check = view_interaction_check
                
                await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
                return
    
    elif interaction.type == discord.InteractionType.component:
        logger.debug(f"[BOT] Компонент взаимодействия: {interaction.data.get('custom_id', 'unknown')}")

@bot.event
async def on_error(event, *args, **kwargs):
    """Обработчик ошибок событий"""
    logger.error(f"[BOT] Ошибка в событии {event}: {args}", exc_info=True)
    import traceback
    traceback.print_exc()

@bot.event
async def on_application_command_error(ctx, error):
    """Обработка ошибок слэш-команд"""
    logger.error(f"[BOT] Ошибка в команде {ctx.command.name if ctx.command else 'unknown'}: {error}", exc_info=True)
    
    # Проверяем, был ли уже отправлен ответ
    if ctx.response.is_done():
        # Если ответ уже отправлен, используем followup
        try:
            if isinstance(error, commands.MissingPermissions):
                await ctx.followup.send("❌ У вас нет прав для выполнения этой команды!", ephemeral=True)
            elif isinstance(error, commands.MissingRole):
                await ctx.followup.send("❌ У вас нет необходимой роли для выполнения этой команды!", ephemeral=True)
            elif isinstance(error, discord.app_commands.errors.CommandNotFound):
                await ctx.followup.send("❌ Команда не найдена. Возможно, она еще не синхронизирована с Discord. Попробуйте через несколько минут.", ephemeral=True)
            else:
                await ctx.followup.send(f"❌ Произошла ошибка: {str(error)}", ephemeral=True)
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение об ошибке: {e}")
    else:
        # Если ответ еще не отправлен, используем respond
        try:
            if isinstance(error, commands.MissingPermissions):
                await ctx.respond("❌ У вас нет прав для выполнения этой команды!", ephemeral=True)
            elif isinstance(error, commands.MissingRole):
                await ctx.respond("❌ У вас нет необходимой роли для выполнения этой команды!", ephemeral=True)
            elif isinstance(error, discord.app_commands.errors.CommandNotFound):
                await ctx.respond("❌ Команда не найдена. Возможно, она еще не синхронизирована с Discord. Попробуйте через несколько минут.", ephemeral=True)
            else:
                await ctx.respond(f"❌ Произошла ошибка: {str(error)}", ephemeral=True)
        except Exception as e:
            logger.error(f"Не удалось отправить сообщение об ошибке: {e}")


asyncio.run(init_models())
bot.run(TOKEN_TO_USE)
