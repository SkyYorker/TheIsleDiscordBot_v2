import json
from datetime import datetime, timedelta
from typing import Optional

import discord
# Option будет доступен после патча в main.py
try:
    from discord.app_commands import Option
except ImportError:
    from discord.ext.commands import Option
from discord.ext import commands

from database.crud import BonusCodeCRUD


class AdminBonusCodesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(
        name="create_bonus_code",
        description="Создать новый бонус-код"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def create_bonus_code(
        self,
        ctx: discord.ApplicationContext,
        code: Option(str, "Код (например: WELCOME2024)"),
        description: Option(str, "Описание кода"),
        reward_type: Option(str, "Тип награды", choices=["tk", "item", "subscription"]),
        reward_value: Option(str, "Значение награды (число для ТС, JSON для предметов)"),
        max_uses: Option(int, "Максимум использований", min_value=1, default=1),
        expires_days: Option(int, "Дней до истечения (0 = без ограничений)", min_value=0, default=0)
    ):
        try:
            # Валидация reward_value
            if reward_type == "item":
                try:
                    json.loads(reward_value)
                except json.JSONDecodeError:
                    await ctx.respond("❌ Неверный формат JSON для предмета", ephemeral=True)
                    return
            elif reward_type == "tk":
                try:
                    int(reward_value)
                except ValueError:
                    await ctx.respond("❌ Для ТС укажите число", ephemeral=True)
                    return
            
            # Вычисляем дату истечения
            expires_at = None
            if expires_days > 0:
                expires_at = datetime.now() + timedelta(days=expires_days)
            
            # Создаем код
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code,
                description=description,
                reward_type=reward_type,
                reward_value=reward_value,
                max_uses=max_uses,
                expires_at=expires_at,
                created_by=ctx.author.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{bonus_code['code']}`\n**Описание:** {bonus_code['description']}\n**Награда:** {bonus_code['reward_type']} - {bonus_code['reward_value']}\n**Использований:** {bonus_code['max_uses']}",
                color=discord.Color.green()
            )
            if expires_at:
                embed.add_field(name="Истекает", value=expires_at.strftime("%d.%m.%Y %H:%M"), inline=True)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка создания кода",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="list_bonus_codes",
        description="Показать все бонус-коды"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def list_bonus_codes(self, ctx: discord.ApplicationContext):
        try:
            codes = await BonusCodeCRUD.get_all_bonus_codes(active_only=False)
            
            if not codes:
                await ctx.respond("❌ Бонус-коды не найдены", ephemeral=True)
                return
            
            embed = discord.Embed(
                title="🎁 Все бонус-коды",
                description=f"Всего кодов: **{len(codes)}**",
                color=discord.Color.blue()
            )
            
            # Показываем последние 10 кодов
            recent_codes = codes[:10]
            for code in recent_codes:
                status = "✅ Активен" if code['is_active'] else "❌ Неактивен"
                uses = f"{code['current_uses']}/{code['max_uses']}"
                expires = code['expires_at'].strftime("%d.%m.%Y") if code['expires_at'] else "Без ограничений"
                
                embed.add_field(
                    name=f"`{code['code']}` - {status}",
                    value=f"**Использований:** {uses}\n**Истекает:** {expires}\n**Описание:** {code['description'][:50]}...",
                    inline=False
                )
            
            if len(codes) > 10:
                embed.set_footer(text=f"Показаны последние 10 из {len(codes)} кодов")
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка получения кодов",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="update_bonus_code",
        description="Обновить бонус-код"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def update_bonus_code(
        self,
        ctx: discord.ApplicationContext,
        code_id: Option(int, "ID кода"),
        is_active: Option(bool, "Активен ли код", required=False),
        max_uses: Option(int, "Новый максимум использований", min_value=0, required=False),
        description: Option(str, "Новое описание", required=False)
    ):
        try:
            updates = {}
            if is_active is not None:
                updates['is_active'] = is_active
            if max_uses is not None:
                updates['max_uses'] = max_uses
            if description is not None:
                updates['description'] = description
            
            if not updates:
                await ctx.respond("❌ Не указано ни одного поля для обновления", ephemeral=True)
                return
            
            updated_code = await BonusCodeCRUD.update_bonus_code(code_id, updates)
            if not updated_code:
                await ctx.respond(f"❌ Код с ID {code_id} не найден", ephemeral=True)
                return
            
            embed = discord.Embed(
                title="✅ Бонус-код обновлен",
                description=f"**Код:** `{updated_code['code']}`\n**Активен:** {'Да' if updated_code['is_active'] else 'Нет'}\n**Использований:** {updated_code['current_uses']}/{updated_code['max_uses']}",
                color=discord.Color.green()
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка обновления кода",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="delete_bonus_code",
        description="Удалить бонус-код"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def delete_bonus_code(
        self,
        ctx: discord.ApplicationContext,
        code_id: Option(int, "ID кода")
    ):
        try:
            success = await BonusCodeCRUD.delete_bonus_code(code_id)
            if success:
                embed = discord.Embed(
                    title="✅ Бонус-код удален",
                    description=f"Код с ID {code_id} успешно удален",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка удаления",
                    description=f"Код с ID {code_id} не найден",
                    color=discord.Color.red()
                )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка удаления кода",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="bonus_code_stats",
        description="Статистика использования бонус-кода"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def bonus_code_stats(
        self,
        ctx: discord.ApplicationContext,
        code_id: Option(int, "ID кода")
    ):
        try:
            # Получаем информацию о коде
            codes = await BonusCodeCRUD.get_all_bonus_codes(active_only=False)
            code_info = next((c for c in codes if c['id'] == code_id), None)
            
            if not code_info:
                await ctx.respond(f"❌ Код с ID {code_id} не найден", ephemeral=True)
                return
            
            # Получаем статистику использования
            usage_stats = await BonusCodeCRUD.get_code_usage_stats(code_id)
            
            embed = discord.Embed(
                title=f"📊 Статистика кода `{code_info['code']}`",
                description=f"**Описание:** {code_info['description']}\n**Использований:** {code_info['current_uses']}/{code_info['max_uses']}\n**Активен:** {'Да' if code_info['is_active'] else 'Нет'}",
                color=discord.Color.blue()
            )
            
            if usage_stats:
                embed.add_field(
                    name="Последние использования",
                    value="\n".join([
                        f"• <@{usage['discord_id']}> - {usage['used_at'].strftime('%d.%m.%Y %H:%M')}"
                        for usage in usage_stats[:10]
                    ]),
                    inline=False
                )
            else:
                embed.add_field(
                    name="Использования",
                    value="Код еще не использовался",
                    inline=False
                )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка получения статистики",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(AdminBonusCodesCog(bot))
