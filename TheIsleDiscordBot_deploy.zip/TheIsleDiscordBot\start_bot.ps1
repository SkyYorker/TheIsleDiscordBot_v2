Set-Location C:\Servers\servers\TheIsleDiscordBot
.\.venv\Scripts\activate.ps1
python main.py
Pause