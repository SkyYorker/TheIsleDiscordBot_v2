import os
from typing import Optional, Tuple, Union, List, Dict, Any
import asyncio

from database.crud import PlayerDinoCRUD, PendingDinoCRUD, SubscriptionCRUD
from .clicker_api import slay_dino, restore_dino, set_nutrients, set_food
from .rcon_isle import fetch_player_by_id, PlayerData

HOST = os.getenv("RCON_HOST")
PORT = int(os.getenv("RCON_PORT"))
PASSWORD = os.getenv("RCON_PASSWORD")


async def _get_player_data(discord_id: int) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    player = await PlayerDinoCRUD.get_player_info(discord_id)
    if not player:
        return None, "Нет привязки к Steam"

    steam_id = player.get("player", {}).get("steam_id", "")
    if not steam_id:
        return None, "Нет привязки к Steam"

    return player, steam_id


async def _get_isle_player(steam_id: str) -> Tuple[Optional[PlayerData], Optional[str]]:
    isle_player = await fetch_player_by_id(HOST, PORT, PASSWORD, steam_id)
    if not isle_player:
        return None, "Игрок не на сервере"
    return isle_player, None


async def save_dino(discord_id: int) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    isle_player, error = await _get_isle_player(steam_id)
    if error:
        return None, error

    result = await PlayerDinoCRUD.add_dino(
        steam_id,
        isle_player.dino_class,
        min(int(isle_player.growth * 100), 99),
        int(isle_player.hunger * 100),
        int(isle_player.thirst * 100),
        int(isle_player.health * 100)
    )
    return result if result else (None, "Техническая ошибка. Обратитесь к администратору")


async def get_pending_dino(steam_id: str, with_lock: bool = False) -> Union[Dict[str, Any], Tuple[None, str]]:
    """
    Получает pending_dino по steam_id.
    
    Args:
        steam_id: Steam ID игрока
        with_lock: Если True, использует SELECT FOR UPDATE для блокировки строки
                   (предотвращает изменения во время чтения)
    
    Returns:
        Dict с данными pending_dino или кортеж (None, error_message)
    """
    pending_dinos = await PendingDinoCRUD.get_by_steam_id(steam_id, with_lock=with_lock)
    if not pending_dinos:
        return None, "Динозавр для сохранения не найден"
    if len(pending_dinos) > 1:
        return None, "Запущено несколько процессов сохранения динозавров"
    return pending_dinos[0]


async def save_dino_to_db(steam_id: str, dino_class: str, growth: int) -> Tuple[
    Optional[Dict[str, Any]], Optional[str]]:
    # Используем атомарную операцию get_and_delete для предотвращения race condition
    # SELECT FOR UPDATE блокирует строку до конца транзакции
    current_dino = await PendingDinoCRUD.get_and_delete_by_steam_id(steam_id)
    
    if current_dino is None:
        return None, "Динозавр для сохранения не найден"

    if dino_class not in current_dino["dino_class"]:
        return None, "Сохраняемые динозавры отличаются"

    result = await PlayerDinoCRUD.add_dino(
        steam_id,
        current_dino["dino_class"],
        min(growth, 99),
        int(current_dino["thirst"]),
        int(current_dino["hunger"]),
        int(current_dino["health"])
    )
    return result if result else (None, "Техническая ошибка. Обратитесь к администратору")


async def del_pending_dino_by_steamid(steam_id: str) -> int:
    return await PendingDinoCRUD.delete_by_steam_id(steam_id)


async def del_pending_dino_by_discordid(discord_id: int) -> int:
    return await PendingDinoCRUD.delete_by_discord_id(discord_id)


async def check_max_limit_dino(discord_id: int, desired_dinos=1):
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id
    max_dino = 6
    subscribe = await SubscriptionCRUD.get_active_subscription(discord_id)
    if subscribe:
        max_dino += subscribe.get("dino_slots", 0)
    if len(player.get("dinos", [])) + desired_dinos > max_dino:
        return None, "Превышено количество сохраняемых динозавров в слоты. Сперва удалите динозавров из слотов"
    return True


async def pending_save_dino(discord_id: int, callback_url: str) -> Tuple[Optional[bool], Optional[str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    checked = await check_max_limit_dino(discord_id)
    if isinstance(checked, tuple):
        return checked

    isle_player, error = await _get_isle_player(steam_id)
    if error:
        return None, error

    await PendingDinoCRUD.cleanup_old_entries(2)

    await PendingDinoCRUD.add_pending_dino(
        steam_id, discord_id, callback_url,
        isle_player.dino_class,
        min(int(isle_player.growth * 100), 99),
        int(isle_player.hunger * 100),
        int(isle_player.thirst * 100),
        int(isle_player.health * 100)
    )
    return True


async def buy_dino(discord_id: int, dino_class: str, growth: int, hunger: int, thirst: int, health: int) -> Tuple[
    Optional[Dict[str, Any]], Optional[str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    checked = await check_max_limit_dino(discord_id)
    if isinstance(checked, tuple):
        return checked

    result = await PlayerDinoCRUD.add_dino(steam_id, dino_class, growth, hunger, thirst, health)
    return result if result else (None, "Игрок не найден")


async def get_all_dinos(discord_id: int) -> Union[List[Dict[str, Any]], Tuple[None, str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id
    return player.get("dinos", [])


async def del_dino(discord_id: int, dino_id: int) -> Tuple[Optional[bool], Optional[str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    result = await PlayerDinoCRUD.delete_dino(steam_id, dino_id)
    return (True, None) if result else (None, "Ошибка во время удаления динозавра")


async def get_current_dino(discord_id: int) -> Union[PlayerData, Tuple[None, str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    isle_player, error = await _get_isle_player(steam_id)
    return isle_player if isle_player else (None, error)


async def kill_current_dino(discord_id: int) -> Tuple[Optional[bool], Optional[str]]:
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        return None, steam_id

    result = await slay_dino(steam_id)
    if not isinstance(result, dict) or not result.get("success"):
        return None, "Игрока нет на сервере" if isinstance(result,
                                                           dict) else "Неизвестная ошибка во время убийства динозавра"
    return True


async def restore_dino_script(discord_id: int, dino_id: int) -> Tuple[Optional[bool], Optional[str]]:
    current_dino = await get_current_dino(discord_id)
    if isinstance(current_dino, tuple):
        return None, current_dino[1]

    dino = await PlayerDinoCRUD.get_dino_by_id(dino_id)
    if not dino:
        return None, "Динозавр не найден"

    if current_dino.dino_class != dino.dino_class:
        return None, "Активируемый динозавр отличается от того, что выбран сейчас в игре"
    if dino.steam_id != current_dino.player_id:
        return None, "Этот динозавр Вам не принадлежит"

    # Используем Clicker API для восстановления
    result = await restore_dino(
        current_dino.player_id,
        dino.growth, dino.hunger,
        dino.thirst, dino.health
    )

    if not isinstance(result, dict) or not result.get("success"):
        return None, "Игрока нет на сервере" if isinstance(result,
                                                           dict) else "Неизвестная ошибка во время восстановления динозавра"

    delete_result = await del_dino(discord_id, dino_id)

    # Сообщение игроку убрано (ранее отправлялось через RCON)
    return True

async def give_nutrients(discord_id: int) -> Tuple[Optional[bool], Optional[str]]:
    """
    Применяет нутриенты к динозавру игрока через Clicker API.
    Требует, чтобы игрок находился на сервере.
    
    Returns:
        (True, None) - успешно применено
        (None, error_message) - ошибка
    """
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"[give_nutrients] Начало применения нутриентов для discord_id={discord_id}")
    
    # Получаем данные игрока
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        error_msg = steam_id or "Нет привязки к Steam"
        logger.warning(f"[give_nutrients] Ошибка получения данных игрока: {error_msg}")
        return None, error_msg
    
    logger.info(f"[give_nutrients] Найден игрок: steam_id={steam_id}")
    
    # Используем только Clicker API
    try:
        logger.info(f"[give_nutrients] Clicker API set_nutrients для steam_id={steam_id}")
        result = await set_nutrients(steam_id, 100, 100, 100)
        logger.info(f"[give_nutrients] Clicker API ответ: {result}")
        
        if not isinstance(result, dict):
            logger.error(f"[give_nutrients] ❌ Clicker API вернул не dict: {type(result)}")
            return None, "Ошибка при применении нутриентов: неверный формат ответа от сервера"
        
        if not result.get("success"):
            error_msg = result.get("error") or result.get("message") or "Игрок не найден на сервере"
            logger.error(f"[give_nutrients] ❌ Clicker API set_nutrients failed: {error_msg}")
            return None, f"Не удалось применить нутриенты. {error_msg}"
        
        logger.info(f"[give_nutrients] ✅ Clicker API set_nutrients успешно применен")
        logger.info(f"[give_nutrients] ✅ Нутриенты успешно применены через Clicker API для discord_id={discord_id}")
        return True, None
    except Exception as e:
        logger.error(f"[give_nutrients] ❌ Ошибка при вызове Clicker API: {e}", exc_info=True)
        return None, f"Ошибка при применении нутриентов: {str(e)}"

async def give_food(discord_id: int) -> Tuple[Optional[bool], Optional[str]]:
    """
    Применяет еду и воду к динозавру игрока через Clicker API.
    Требует, чтобы игрок находился на сервере.
    
    Returns:
        (True, None) - успешно применено
        (None, error_message) - ошибка
    """
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"[give_food] Начало применения еды/воды для discord_id={discord_id}")
    
    # Получаем данные игрока
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        error_msg = steam_id or "Нет привязки к Steam"
        logger.warning(f"[give_food] Ошибка получения данных игрока: {error_msg}")
        return None, error_msg
    
    logger.info(f"[give_food] Найден игрок: steam_id={steam_id}")
    
    # Используем только Clicker API
    try:
        logger.info(f"[give_food] Clicker API set_food для steam_id={steam_id}")
        result = await set_food(steam_id, 100, 100)
        logger.info(f"[give_food] Clicker API ответ: {result}")
        
        if not isinstance(result, dict):
            logger.error(f"[give_food] ❌ Clicker API вернул не dict: {type(result)}")
            return None, "Ошибка при применении еды/воды: неверный формат ответа от сервера"
        
        if not result.get("success"):
            error_msg = result.get("error") or result.get("message") or "Игрок не найден на сервере"
            logger.error(f"[give_food] ❌ Clicker API set_food failed: {error_msg}")
            return None, f"Не удалось применить еду/воду. {error_msg}"
        
        logger.info(f"[give_food] ✅ Clicker API set_food успешно применен")
        logger.info(f"[give_food] ✅ Еда и вода успешно применены через Clicker API для discord_id={discord_id}")
        return True, None
    except Exception as e:
        logger.error(f"[give_food] ❌ Ошибка при вызове Clicker API: {e}", exc_info=True)
        return None, f"Ошибка при применении еды/воды: {str(e)}"


async def restore_all_dino(discord_id: int) -> Tuple[Optional[bool], Optional[str]]:
    """
    Полное восстановление всех характеристик текущего динозавра:
    - Здоровье (HP) - 100
    - Голод - 100
    - Жажда - 100
    - Нутриенты (белки, углеводы, жиры) - 100
    
    Рост динозавра сохраняется текущим (используется значение 99% по умолчанию).
    """
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"[restore_all_dino] Начало восстановления для discord_id={discord_id}")
    
    player, steam_id = await _get_player_data(discord_id)
    if not player:
        logger.error(f"[restore_all_dino] Не найдены данные игрока для discord_id={discord_id}, ошибка: {steam_id}")
        return None, steam_id
    
    logger.info(f"[restore_all_dino] Найден игрок: steam_id={steam_id}")
    
    # Используем только Clicker API для восстановления
    # Рост устанавливаем на 99% (максимальный для сохранения)
    current_growth = 99
    logger.info(f"[restore_all_dino] Использование Clicker API для восстановления")
    
    try:
        # Восстанавливаем основные характеристики через Clicker API
        result = await restore_dino(
            steam_id,
            growth=current_growth,  # Сохраняем максимальный рост
            hunger=100,  # Максимальный голод
            thirst=100,  # Максимальная жажда
            health=100  # Максимальное здоровье
        )
        logger.info(f"[restore_all_dino] Clicker API restore_dino ответ: {result}")
        
        if not isinstance(result, dict) or not result.get("success"):
            error_msg = result.get("error") or "Игрока нет на сервере" if isinstance(result, dict) else "Неизвестная ошибка во время восстановления динозавра"
            logger.error(f"[restore_all_dino] Clicker API restore_dino failed: {result}, ошибка: {error_msg}")
            return None, error_msg
        
        logger.info(f"[restore_all_dino] Clicker API restore_dino successful")
        
        # Восстанавливаем нутриенты отдельно через Clicker API
        try:
            nutrients_result = await set_nutrients(steam_id, 100, 100, 100)
            logger.info(f"[restore_all_dino] Нутриенты восстановлены через Clicker API: {nutrients_result}")
            if not isinstance(nutrients_result, dict) or not nutrients_result.get("success"):
                logger.warning(f"[restore_all_dino] Failed to restore nutrients via Clicker API: {nutrients_result}")
        except Exception as e:
            logger.error(f"[restore_all_dino] Failed to restore nutrients: {e}", exc_info=True)
        
        logger.info(f"[restore_all_dino] Восстановление успешно завершено через Clicker API")
        return True, None
        
    except Exception as e:
        logger.error(f"[restore_all_dino] Ошибка при вызове Clicker API: {e}", exc_info=True)
        return None, f"Ошибка восстановления: {str(e)}"