"""
Интеграция сервера The Isle с Discord ботом
Работа с файлами сохранений сервера вместо БД
"""

import asyncio
import os
from typing import Optional, Dict, List
from datetime import datetime, timezone

# Совместимость с разными версиями Python
try:
    from datetime import timezone
except ImportError:
    timezone.utc = timezone.utc

from utils.save_file_manager import TheIsleSaveManager
from pathlib import Path
import glob
from database.crud import PlayerDinoCRUD
from data.dinosaurus import find_name_by_class
import logging

logger = logging.getLogger(__name__)


class TheIsleServerIntegration:
    """Основной класс интеграции с сервером The Isle через файлы сохранений"""
    
    def __init__(self):
        self.save_manager: Optional[TheIsleSaveManager] = None
        self.is_connected = False
        self.server_save_path: Optional[Path] = None
        self.server_info = {}
        self._cached_players = {}
        self._last_scan_time = None
        
    async def initialize(self, server_saves_path: str = None) -> bool:
        """Инициализация подключения к серверу через файлы сохранений"""
        try:
            # Если путь не указан, пытаемся найти автоматически
            if not server_saves_path:
                server_saves_path = await self._auto_discover_save_directory()
                
            if not server_saves_path:
                logger.error("Could not find The Isle server save files directory")
                return False
                
            self.server_save_path = Path(server_saves_path)
            
            # Проверяем доступность папки
            if not self.server_save_path.exists():
                logger.error(f"Save directory does not exist: {self.server_save_path}")
                return False
                
            # Инициализируем менеджер файлов сохранений
            self.save_manager = TheIsleSaveManager(str(self.server_save_path))
            
            # Проверяем наличие .sav файлов
            save_files = list(self.server_save_path.glob("*.sav"))
            if save_files:
                self.is_connected = True
                logger.info(f"Successfully connected to server saves: {self.server_save_path}")
                logger.info(f"Found {len(save_files)} save files")
                
                # Запускаем мониторинг
                await self._start_monitoring()
                return True
            else:
                logger.warning(f"No save files found in {self.server_save_path}")
                return False
                
        except Exception as e:
            logger.error(f"Error initializing server integration: {e}")
            return False
    
    async def _auto_discover_save_directory(self) -> Optional[str]:
        """Автоматический поиск папки с файлами сохранений сервера"""
        logger.info("Searching for The Isle server save files...")
        
        # Возможные пути к серверу
        possible_paths = [
            "C:\\WindowsGSM\\servers\\*\\serverfiles\\TheIsle\\Saved\\SaveGames",
            "C:\\GameServers\\TheIsle\\Saved\\SaveGames",
            "D:\\GameServers\\TheIsle\\Saved\\SaveGames",
            "C:\\SteamCMD\\steamapps\\common\\TheIsle\\Saved\\SaveGames",
            # Локальные файлы для тестирования
            ".\\",  # Текущая папка (для тестов)
        ]
        
        for path_pattern in possible_paths:
            try:
                # Используем glob для поиска по маске
                matching_paths = glob.glob(path_pattern)
                
                for path in matching_paths:
                    path_obj = Path(path)
                    if path_obj.exists():
                        # Проверяем наличие .sav файлов
                        save_files = list(path_obj.glob("*.sav"))
                        if save_files:
                            logger.info(f"Found save directory with {len(save_files)} files: {path}")
                            return str(path_obj)
                            
            except Exception as e:
                logger.debug(f"Error checking path {path_pattern}: {e}")
                
        return None
    
    async def _start_monitoring(self):
        """Запуск мониторинга изменений файлов сохранений"""
        if self.server_save_path:
            # Запускаем мониторинг в фоне
            asyncio.create_task(self._monitor_save_files())
            logger.info("Save files monitoring started")
    
    async def _monitor_save_files(self):
        """Мониторинг изменений в файлах сохранений"""
        while self.is_connected:
            try:
                current_time = datetime.now(timezone.utc)
                
                # Обновляем кэш игроков каждые 30 секунд
                if (not self._last_scan_time or 
                    (current_time - self._last_scan_time).seconds > 30):
                    
                    await self._scan_save_files()
                    self._last_scan_time = current_time
                
                await asyncio.sleep(10)  # Проверяем каждые 10 секунд
                
            except Exception as e:
                logger.error(f"Error in save files monitoring: {e}")
                await asyncio.sleep(10)
    
    async def _scan_save_files(self):
        """Сканирование всех файлов сохранений"""
        try:
            save_files = list(self.server_save_path.glob("*.sav"))
            current_players = {}
            
            for save_file in save_files:
                # Извлекаем Steam ID из имени файла
                if save_file.stem.isdigit() and len(save_file.stem) == 17:
                    steam_id = save_file.stem
                    
                    # Получаем информацию о файле
                    file_stat = save_file.stat()
                    current_players[steam_id] = {
                        'steam_id': steam_id,
                        'save_file': str(save_file),
                        'last_modified': datetime.fromtimestamp(file_stat.st_mtime, timezone.utc),
                        'file_size': file_stat.st_size,
                        'is_online': self._is_recently_active(file_stat.st_mtime)
                    }
            
            # Обновляем кэш
            old_players = set(self._cached_players.keys())
            new_players = set(current_players.keys())
            
            # Новые игроки
            for steam_id in new_players - old_players:
                logger.info(f"New player detected: {steam_id}")
                await self._on_player_join(current_players[steam_id])
            
            # Отключившиеся игроки
            for steam_id in old_players - new_players:
                logger.info(f"Player left: {steam_id}")
                await self._on_player_leave(self._cached_players[steam_id])
            
            self._cached_players = current_players
            
        except Exception as e:
            logger.error(f"Error scanning save files: {e}")
    
    def _is_recently_active(self, timestamp: float, threshold_minutes: int = 5) -> bool:
        """Проверяет, был ли файл изменен недавно"""
        current_time = datetime.now(timezone.utc).timestamp()
        return (current_time - timestamp) < (threshold_minutes * 60)
    
    async def _on_player_join(self, player_data: Dict):
        """Обработка подключения игрока"""
        steam_id = player_data['steam_id']
        await self._update_bot_player_data(steam_id, player_data)
    
    async def _on_player_leave(self, player_data: Dict):
        """Обработка отключения игрока"""
        steam_id = player_data['steam_id']
        logger.info(f"Player {steam_id} disconnected")
    
    async def _sync_players_data(self, server_players: List[Dict]):
        """Синхронизация данных игроков между файлами сохранений и ботом"""
        for player in server_players:
            steam_id = player.get('steam_id')
            if steam_id:
                await self._update_bot_player_data(steam_id, player)
    
    async def _update_bot_player_data(self, steam_id: str, server_data: Dict):
        """Обновление данных игрока в БД бота"""
        try:
            # Получаем существующие данные из БД бота
            bot_player = await PlayerDinoCRUD.get_player_by_steam_id(steam_id)
            
            if bot_player:
                # Обновляем последнюю активность
                await PlayerDinoCRUD.update_player_activity(
                    bot_player["discord_id"], 
                    datetime.now(timezone.utc)
                )
                
        except Exception as e:
            logger.debug(f"Error updating bot player data for {steam_id}: {e}")
    
    # Методы для замены RCON функциональности
    
    async def get_player_data(self, steam_id: str) -> Optional[Dict]:
        """Получение данных игрока из файла сохранения"""
        if not self.is_connected:
            return None
            
        # Проверяем кэш
        if steam_id in self._cached_players:
            cached_data = self._cached_players[steam_id]
            
            # Пытаемся расшифровать файл сохранения
            try:
                save_data = await self._parse_save_file(cached_data['save_file'])
                if save_data:
                    return {
                        **cached_data,
                        'game_data': save_data
                    }
            except Exception as e:
                logger.debug(f"Could not parse save file for {steam_id}: {e}")
                
            return cached_data
            
        return None
    
    async def get_all_players(self) -> List[Dict]:
        """Получение всех игроков на сервере"""
        if not self.is_connected:
            return []
            
        # Обновляем кэш перед возвратом
        await self._scan_save_files()
        return list(self._cached_players.values())
    
    async def _parse_save_file(self, save_file_path: str) -> Optional[Dict]:
        """Парсинг файла сохранения (используем наши инструменты)"""
        try:
            if self.save_manager:
                # Используем SaveManager для чтения файла
                save_file = Path(save_file_path)
                steam_id = save_file.stem
                
                save_data = self.save_manager.read_player_save(steam_id)
                if save_data:
                    stats = save_data.get('stats', {})
                    dino_info = save_data.get('dinosaur', {})
                    
                    return {
                        'growth': stats.get('growth', 0.0),
                        'health': stats.get('health', 1.0),
                        'hunger': stats.get('hunger', 1.0),
                        'thirst': stats.get('thirst', 1.0),
                        'stamina': stats.get('stamina', 1.0),
                        'species': dino_info.get('species', 'Unknown'),
                        'location': {
                            'x': dino_info.get('position', [0, 0, 0])[0],
                            'y': dino_info.get('position', [0, 0, 0])[1],
                            'z': dino_info.get('position', [0, 0, 0])[2]
                        } if dino_info.get('position') else {}
                    }
        except Exception as e:
            logger.debug(f"Error parsing save file {save_file_path}: {e}")
            
        return None
    
    async def get_player_dinosaurs(self, steam_id: str) -> List[Dict]:
        """Получение динозавров игрока из файла сохранения"""
        if not self.is_connected:
            return []
            
        player_data = await self.get_player_data(steam_id)
        if not player_data or 'game_data' not in player_data:
            return []
            
        game_data = player_data['game_data']
        
        # Создаем одного динозавра на основе данных сохранения
        dino = {
            "id": 1,
            "dino_class": game_data.get("species", "Unknown"),
            "growth": float(game_data.get("growth", 0)),
            "health": float(game_data.get("health", 100)),
            "hunger": float(game_data.get("hunger", 100)),
            "thirst": float(game_data.get("thirst", 100)),
            "location": game_data.get("location", {})
        }
        
        # Добавляем название динозавра
        if dino["dino_class"]:
            dino["display_name"] = find_name_by_class(dino["dino_class"])
            
        return [dino]
    
    async def spawn_dinosaur(self, steam_id: str, dino_data: Dict) -> bool:
        """Создание динозавра на сервере (через модификацию сохранения)"""
        if not self.is_connected:
            return False
            
        # Пока не реализовано - требует модификацию файлов сохранения
        logger.warning("Dinosaur spawning through save modification not implemented yet")
        return False
    
    async def delete_dinosaur(self, steam_id: str, dino_id: int) -> bool:
        """Удаление динозавра с сервера (через модификацию сохранения)"""
        if not self.is_connected:
            return False
            
        # Пока не реализовано
        logger.warning("Dinosaur deletion through save modification not implemented yet")
        return False
    
    async def send_server_message(self, steam_id: str, message: str) -> bool:
        """Отправка сообщения игроку (если поддерживается)"""
        # Для этого может потребоваться дополнительная интеграция
        # или запись в таблицу сообщений, которую читает сервер
        logger.warning("Direct messaging not implemented yet")
        return False
    
    async def get_server_stats(self) -> Dict:
        """Получение статистики сервера на основе файлов сохранений"""
        if not self.is_connected:
            return {}
            
        try:
            all_players = await self.get_all_players()
            online_players = [p for p in all_players if p.get('is_online', False)]
            
            return {
                "total_players": len(all_players),
                "online_players": len(online_players),
                "total_dinosaurs": len(all_players),  # Один динозавр на файл
                "save_files_found": len(all_players),
                "last_updated": datetime.now(timezone.utc).isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting server stats: {e}")
            return {}
    
    async def disconnect(self):
        """Отключение от сервера"""
        self.is_connected = False
        self._cached_players.clear()
        logger.info("Disconnected from server save files")


# Глобальный экземпляр интеграции
server_integration = TheIsleServerIntegration()


# Функции для замены RCON в существующем коде
async def get_current_dino_from_server(discord_id: int) -> Optional[Dict]:
    """Получение текущего динозавра игрока с сервера"""
    try:
        # Получаем Steam ID игрока
        player = await PlayerDinoCRUD.get_player_info(discord_id)
        if not player or not player.get("player", {}).get("steam_id"):
            return None
            
        steam_id = player["player"]["steam_id"]
        
        # Получаем данные с сервера
        player_data = await server_integration.get_player_data(steam_id)
        if not player_data:
            return None
            
        # Преобразуем в формат, ожидаемый ботом
        return {
            "name": player_data.get("name", "Unknown"),
            "steam_id": steam_id,
            "dino_class": player_data.get("species") or player_data.get("character_class"),
            "growth": float(player_data.get("growth", 0)),
            "health": float(player_data.get("health", 100)),
            "hunger": float(player_data.get("hunger", 100)),
            "thirst": float(player_data.get("thirst", 100)),
            "location": {
                "x": float(player_data.get("pos_x", 0)),
                "y": float(player_data.get("pos_y", 0)),
                "z": float(player_data.get("pos_z", 0))
            } if player_data.get("pos_x") else {}
        }
        
    except Exception as e:
        logger.error(f"Error getting current dino from server: {e}")
        return None


async def get_all_server_players() -> List[Dict]:
    """Получение всех игроков сервера"""
    try:
        return await server_integration.get_all_players()
    except Exception as e:
        logger.error(f"Error getting all server players: {e}")
        return []


# Инициализация интеграции при запуске бота
async def init_server_integration():
    """Инициализация интеграции с сервером через файлы сохранений"""
    try:
        # Получаем путь к папке сохранений из переменных окружения
        saves_path = os.getenv("THEISLE_SERVER_SAVES_PATH")
        
        success = await server_integration.initialize(saves_path)
        if success:
            logger.info("The Isle server integration (save files) initialized successfully")
        else:
            logger.warning("Failed to initialize server integration with save files, falling back to RCON")
            
    except Exception as e:
        logger.error(f"Error initializing server integration: {e}")


# Функция для добавления в main.py
async def setup_server_integration():
    """Настройка интеграции сервера для бота"""
    await init_server_integration()