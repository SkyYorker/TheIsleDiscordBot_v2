import logging
import os

import discord
from discord.ext import commands
from discord.ext import tasks

from views.auth_view import AuthView
from views.main_menu import MainMenuView
from utils.steam_api import steam_api
from discord.ui import View, Button

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

file_handler = logging.FileHandler('bot.log', encoding='utf-8')
file_handler.setLevel(logging.INFO)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

logger.addHandler(file_handler)
logger.addHandler(console_handler)

LOGO_URL = os.getenv("LOGO_URL")


class WelcomeView(View):
    """View для приветственного сообщения с кнопками авторизации и меню"""
    def __init__(self):
        super().__init__(timeout=None)
        
        # Добавляем кнопки программно
        self.add_item(Button(
            label="Открыть меню",
            style=discord.ButtonStyle.green,
            emoji="⚙️",
            custom_id="welcome_open_menu",
            row=0
        ))
        
        self.add_item(Button(
            label="Привязать Steam",
            style=discord.ButtonStyle.green,
            custom_id="welcome_link_steam",
            row=1
        ))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Обработчик всех взаимодействий с view"""
        custom_id = interaction.data.get("custom_id")
        
        if custom_id == "welcome_open_menu":
            logger.info(f"Пользователь {interaction.user.id} нажал 'Открыть меню' из приветственного сообщения")
            
            # Откладываем ответ, чтобы избежать таймаута взаимодействия
            await interaction.response.defer(ephemeral=True)
            
            try:
                # Проверяем привязку Steam (точно так же, как в AuthView.check_steam_link из оригинального бота)
                from database.crud import PlayerDinoCRUD
                player = await PlayerDinoCRUD.get_player_info(interaction.user.id)
                steam_id = ""
                if isinstance(player, dict):
                    steam_id = player.get("player", {}).get("steam_id")
                
                logger.info(f"Проверка привязки Steam для пользователя {interaction.user.id}: {'есть' if player and steam_id else 'нет'}")
                logger.info(f"[DEBUG] player для {interaction.user.id}: {player}")
                logger.info(f"[DEBUG] steam_id для {interaction.user.id}: {steam_id}")
                
                is_linked = player is not None and steam_id
                
                if not is_linked:
                    embed = discord.Embed(
                        title="❌ Steam не привязан",
                        description="Чтобы пользоваться меню, привяжите свой аккаунт Steam через кнопку 'Привязать Steam'.",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    return False
                
                # Если Steam привязан, открываем главное меню
                logger.info(f"[DEBUG] Получаем steam_data для {interaction.user.id}")
                steam_data = await steam_api.get_steam_data(interaction.user.id)
                logger.info(f"[DEBUG] steam_data для {interaction.user.id}: {steam_data}")
                
                if not steam_data:
                    logger.warning(f"[DEBUG] steam_data пустой для {interaction.user.id}")
                    embed = discord.Embed(
                        title="❌ Ошибка",
                        description="Не удалось получить данные Steam. Попробуйте позже.",
                        color=discord.Color.red()
                    )
                    await interaction.followup.send(embed=embed, ephemeral=True)
                    return False
                
                logger.info(f"[DEBUG] Создаем MainMenuView для {interaction.user.id}")
                view = await MainMenuView.create_with_admin_check(steam_data, interaction.user.id, interaction)
                await view.update_player_data(interaction.user.id)
                logger.info(f"[DEBUG] Отправляем меню для {interaction.user.id}")
                await interaction.followup.send(embed=view.embed, view=view, ephemeral=True)
            except Exception as e:
                logger.error(f"Ошибка при открытии меню для {interaction.user.id}: {e}", exc_info=True)
                embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось открыть меню: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=embed, ephemeral=True)
            return False
            
        elif custom_id == "welcome_link_steam":
            logger.info(f"Пользователь {interaction.user.id} нажал 'Привязать Steam' из приветственного сообщения")
            
            await interaction.response.defer(ephemeral=True)
            
            try:
                from utils.steam_auth import SteamAuth
                
                logger.info(f"[DEBUG] Генерируем ссылку для привязки Steam для {interaction.user.id}")
                result = await SteamAuth.generate_auth_link(interaction.user.id)
                logger.info(f"[DEBUG] Результат генерации ссылки для {interaction.user.id}: {result}")
                
                if "error" in result:
                    logger.error(f"Произошла ошибка при привязке Steam у {interaction.user.id}: {result['error']}")
                    await interaction.followup.send(f"❌ Ошибка: {result['error']}", ephemeral=True)
                    return False
                
                auth_url = result.get("Url", "")
                qrcode_base64 = result.get("Qrcode", "")
                
                if not auth_url or not qrcode_base64:
                    logger.warning(f"[DEBUG] Не удалось получить auth_url или qrcode для {interaction.user.id}")
                    await interaction.followup.send("⚠️ Не удалось получить данные аутентификации", ephemeral=True)
                    return False
                
                logger.info(f"[DEBUG] Успешно получены данные аутентификации для {interaction.user.id}, URL: {auth_url[:50]}...")
                
                embed = discord.Embed(
                    title="Steam Аутентификация",
                    description=f"Ссылка для входа: [Нажмите здесь]({auth_url})",
                    color=discord.Color.blue()
                )
                embed.set_footer(text="QR-код действителен в течение 5 минут")
                
                qrcode_file = SteamAuth.create_qrcode_file(qrcode_base64)
                
                await interaction.followup.send(
                    embed=embed,
                    file=qrcode_file,
                    ephemeral=True
                )
                
                logger.info(f"[OK] Успешно отправлена Steam аутентификация для {interaction.user.id}")
            except Exception as e:
                logger.error(f"Ошибка при отправке Steam аутентификации для {interaction.user.id}: {str(e)}", exc_info=True)
                await interaction.followup.send("⚠️ Произошла ошибка при создании сообщения", ephemeral=True)
            return False
        
        return False


class MainMenuCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.menu_message_id = 1395526823135150141
        self.menu_channel_id = 1431019870086234235
        self.menu_embed = self._create_menu_embed()
        self.refresh_auth_view.start()

    def _create_menu_embed(self):
        embed = discord.Embed(
            description="""👋 **Добро пожаловать!**

**TheIsle Discord Bot**

⚙️ Нажмите кнопку ниже, чтобы открыть меню

**Доступные функции:**
• 🎒 Управление инвентарем
• 📦 Покупка предметов
• 🦖 Управление динозаврами
• 🎁 Активация бонус-кодов
• 📊 Просмотр статистики""",
            color=discord.Color.blue(),
        )
        
        # Добавляем footer
        embed.set_footer(text="TAPKIN SUPREME BOT | Нажмите кнопку для начала")

        if LOGO_URL:
            embed.set_image(url=LOGO_URL)

        return embed

    def cog_unload(self):
        self.refresh_auth_view.cancel()

    @commands.slash_command(name="menu", description="Открыть главное меню бота")
    @commands.guild_only()
    async def menu(self, ctx):
        """Команда для открытия главного меню"""
        logger.info(f"Команда menu вызвана пользователем {ctx.author.id}")
        
        # Проверяем привязку Steam
        from database.crud import PlayerDinoCRUD
        player_info = await PlayerDinoCRUD.get_player_info(ctx.author.id)
        
        if not player_info or not player_info.get("player", {}).get("steam_id"):
            embed = discord.Embed(
                title="❌ Steam не привязан",
                description="Чтобы пользоваться меню, привяжите свой аккаунт Steam через кнопку 'Привязать Steam' в основном сообщении бота.",
                color=discord.Color.red()
            )
            await ctx.respond(embed=embed, ephemeral=True)
            return
        
        try:
            steam_data = await steam_api.get_steam_data(ctx.author.id)
            # ctx.interaction может быть None для slash команд, поэтому используем ctx.interaction если доступно
            interaction = getattr(ctx, 'interaction', None)
            view = MainMenuView(steam_data, ctx.author.id, interaction)
            await view.update_player_data(ctx.author.id)
            await ctx.respond(embed=view.embed, view=view, ephemeral=True)
        except Exception as e:
            logger.error(f"Ошибка при открытии меню для {ctx.author.id}: {e}", exc_info=True)
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Не удалось открыть меню. Попробуйте позже.",
                color=discord.Color.red()
            )
            await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(name="setup_menu", description="Обновить сообщение с меню")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def setup_menu(self, ctx):
        logger.info(f"Команда setup_menu вызвана пользователем {ctx.author} в канале {ctx.channel}")

        try:
            channel = self.bot.get_channel(self.menu_channel_id)
            if not channel:
                await ctx.respond("Канал с указанным ID не найден!", ephemeral=True)
                return

            try:
                message = await channel.fetch_message(self.menu_message_id)
                # Обновляем существующее сообщение
                welcome_view = WelcomeView()
                await message.edit(embed=self.menu_embed, view=welcome_view)
                logger.info(f"Сообщение {self.menu_message_id} успешно обновлено")
                await ctx.respond("Меню успешно обновлено!", ephemeral=True)
            except discord.NotFound:
                # Сообщение не найдено, создаем новое
                welcome_view = WelcomeView()
                new_message = await channel.send(embed=self.menu_embed, view=welcome_view)
                # Обновляем ID сообщения
                self.menu_message_id = new_message.id
                logger.info(f"Создано новое сообщение с меню: {new_message.id}")
                await ctx.respond(f"Создано новое сообщение с меню! ID: {new_message.id}\nНе забудьте закрепить его и обновить ID в коде.", ephemeral=True)
        except discord.HTTPException as e:
            logger.error(f"Ошибка при обновлении сообщения: {e}")
            await ctx.respond("Не удалось обновить сообщение!", ephemeral=True)

    @commands.slash_command(name="create_welcome", description="Создать новое приветственное сообщение в текущем канале")
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def create_welcome(self, ctx):
        """Создает новое приветственное сообщение в текущем канале"""
        logger.info(f"Команда create_welcome вызвана пользователем {ctx.author} в канале {ctx.channel}")
        
        try:
            welcome_view = WelcomeView()
            new_message = await ctx.channel.send(embed=self.menu_embed, view=welcome_view)
            logger.info(f"Создано новое приветственное сообщение: {new_message.id} в канале {ctx.channel.id}")
            await ctx.respond(
                f"✅ Приветственное сообщение создано!\n"
                f"ID сообщения: `{new_message.id}`\n"
                f"ID канала: `{ctx.channel.id}`\n\n"
                f"**Не забудьте:**\n"
                f"1. Закрепить сообщение\n"
                f"2. Обновить `menu_message_id` и `menu_channel_id` в коде, если нужно",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Ошибка при создании сообщения: {e}", exc_info=True)
            await ctx.respond(f"❌ Ошибка при создании сообщения: {str(e)}", ephemeral=True)

    @tasks.loop(hours=1)
    async def refresh_auth_view(self):
        try:
            logger.debug("Начинаем обновление view")

            channel = self.bot.get_channel(self.menu_channel_id)
            if not channel:
                logger.warning(f"Канал с ID {self.menu_channel_id} не найден")
                return

            try:
                message = await channel.fetch_message(self.menu_message_id)
            except discord.NotFound:
                logger.warning(f"Сообщение с меню (ID: {self.menu_message_id}) было удалено")
                return

            # Создаем простой view с одной кнопкой "Открыть меню"
            welcome_view = WelcomeView()
            await message.edit(embed=self.menu_embed, view=welcome_view)
            logger.info(f"View и embed успешно обновлены для сообщения {message.id} в канале {channel.name}")

        except discord.HTTPException as e:
            logger.error(f"HTTP ошибка при обновлении view: {e}")
        except Exception as e:
            logger.error(f"Неожиданная ошибка при обновлении view: {e}")

    @refresh_auth_view.before_loop
    async def before_refresh_auth_view(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(MainMenuCog(bot))
