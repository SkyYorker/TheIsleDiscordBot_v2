"""
Менеджер файлов сохранений The Isle
Интеграция с Discord ботом для модификации игровых данных
"""

import os
import struct
import binascii
import hashlib
import zlib
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class DinosaurStats:
    """Статы динозавра"""
    health: float = 1.0      # 0.0 - 1.0
    hunger: float = 1.0      # 0.0 - 1.0 
    thirst: float = 1.0      # 0.0 - 1.0
    growth: float = 0.0      # 0.0 - 1.0
    stamina: float = 1.0     # 0.0 - 1.0


@dataclass
class DinosaurData:
    """Полные данные динозавра"""
    species: str = "BP_Triceratops_C"
    stats: DinosaurStats = None
    position: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    
    def __post_init__(self):
        if self.stats is None:
            self.stats = DinosaurStats()


class TheIsleSaveManager:
    """Менеджер файлов сохранений The Isle"""
    
    def __init__(self, server_saves_path: str = None):
        self.server_saves_path = Path(server_saves_path) if server_saves_path else None
        
        # Известные оффсеты из анализа
        self.stat_offsets = {
            "health": 0x0038,
            "hunger": 0x0040, 
            "thirst": 0x0048,
            "growth": 0x0094,
            "stamina": 0x0050,
        }
        
        # Поддерживаемые виды динозавров
        self.supported_species = {
            "Трицератопс": "BP_Triceratops_C",
            "Карнотавр": "BP_Carnotaurus_C", 
            "Дилофозавр": "BP_Dilophosaurus_C",
            "Стегозавр": "BP_Stegosaurus_C",
            "Цератозавр": "BP_Ceratosaurus_C",
            "Майязавр": "BP_Maiasaura_C"
        }
    
    def read_player_save(self, steam_id: str) -> Optional[Dict]:
        """Читает файл сохранения игрока"""
        save_file = self._get_save_file_path(steam_id)
        
        if not save_file or not save_file.exists():
            logger.warning(f"Save file not found for Steam ID: {steam_id}")
            return None
        
        try:
            # Читаем как hex-строку
            with open(save_file, 'r', encoding='utf-8') as f:
                hex_data = f.read().strip()
            
            # Преобразуем в байты
            data = binascii.unhexlify(hex_data)
            
            # Разделяем заголовок и данные
            header = data[:16]
            payload = data[16:]
            
            # Извлекаем статы
            stats = self._extract_stats(payload)
            
            # Извлекаем другую информацию
            dino_info = self._extract_dinosaur_info(payload)
            
            return {
                "steam_id": steam_id,
                "file_size": len(data),
                "header": header.hex(),
                "stats": stats,
                "dinosaur": dino_info,
                "raw_payload": payload
            }
            
        except Exception as e:
            logger.error(f"Error reading save file for {steam_id}: {e}")
            return None
    
    def write_player_save(self, steam_id: str, save_data: Dict) -> bool:
        """Записывает модифицированные данные в файл сохранения игрока"""
        save_file = self._get_save_file_path(steam_id)
        
        if not save_file:
            logger.error(f"Cannot determine save file path for Steam ID: {steam_id}")
            return False
        
        try:
            # Получаем модифицированный payload
            payload = save_data["raw_payload"]
            
            # Применяем изменения статов
            if "stats" in save_data:
                payload = self._apply_stats_changes(payload, save_data["stats"])
            
            # Применяем изменения динозавра
            if "dinosaur" in save_data:
                payload = self._apply_dinosaur_changes(payload, save_data["dinosaur"])
            
            # Пересчитываем заголовок (контрольную сумму) правильно
            header = self._calculate_header(payload)
            
            # Объединяем заголовок и данные
            full_data = header + payload
            
            # Создаем backup
            self._create_backup(save_file)
            
            # Записываем как hex-строку
            hex_data = full_data.hex().upper()
            
            with open(save_file, 'w', encoding='utf-8') as f:
                f.write(hex_data)
            
            logger.info(f"Successfully updated save file for Steam ID: {steam_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error writing save file for {steam_id}: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def modify_dinosaur_stats(self, steam_id: str, new_stats: DinosaurStats) -> Tuple[bool, str]:
        """Изменяет статы динозавра игрока"""
        save_data = self.read_player_save(steam_id)
        
        if not save_data:
            return False, "Файл сохранения не найден"
        
        try:
            # Обновляем статы
            save_data["stats"] = {
                "health": max(0.0, min(1.0, new_stats.health)),
                "hunger": max(0.0, min(1.0, new_stats.hunger)),
                "thirst": max(0.0, min(1.0, new_stats.thirst)),
                "growth": max(0.0, min(1.0, new_stats.growth)),
                "stamina": max(0.0, min(1.0, new_stats.stamina))
            }
            
            # Применяем изменения
            success = self.write_player_save(steam_id, save_data)
            
            if success:
                return True, "Статы динозавра успешно изменены"
            else:
                return False, "Ошибка при записи файла сохранения"
                
        except Exception as e:
            return False, f"Ошибка при изменении статов: {str(e)}"
    
    def create_dinosaur(self, steam_id: str, dino_data: DinosaurData) -> bool:
        """Создает нового динозавра для игрока"""
        save_data = self.read_player_save(steam_id)
        
        if save_data:
            # Если файл существует, модифицируем
            save_data["stats"] = {
                "health": dino_data.stats.health,
                "hunger": dino_data.stats.hunger,
                "thirst": dino_data.stats.thirst,
                "growth": dino_data.stats.growth,
                "stamina": dino_data.stats.stamina
            }
            save_data["dinosaur"] = {
                "species": dino_data.species,
                "position": dino_data.position,
                "rotation": dino_data.rotation
            }
        else:
            # Создаем новый файл
            save_data = self._create_new_save_data(steam_id, dino_data)
        
        return self.write_player_save(steam_id, save_data)
    
    def heal_dinosaur(self, steam_id: str, full_heal: bool = False) -> bool:
        """Лечит динозавра игрока"""
        save_data = self.read_player_save(steam_id)
        
        if not save_data:
            return False
        
        if full_heal:
            # Полное восстановление
            save_data["stats"] = {
                "health": 1.0,
                "hunger": 1.0,
                "thirst": 1.0,
                "growth": save_data["stats"].get("growth", 0.0),  # Рост не трогаем
                "stamina": 1.0
            }
        else:
            # Частичное восстановление
            current_stats = save_data["stats"]
            save_data["stats"] = {
                "health": min(1.0, current_stats.get("health", 0.0) + 0.5),
                "hunger": min(1.0, current_stats.get("hunger", 0.0) + 0.3),
                "thirst": min(1.0, current_stats.get("thirst", 0.0) + 0.3),
                "growth": current_stats.get("growth", 0.0),
                "stamina": 1.0
            }
        
        return self.write_player_save(steam_id, save_data)
    
    def boost_growth(self, steam_id: str, growth_amount: float = 0.1) -> bool:
        """Увеличивает рост динозавра"""
        save_data = self.read_player_save(steam_id)
        
        if not save_data:
            return False
        
        current_growth = save_data["stats"].get("growth", 0.0)
        new_growth = min(1.0, current_growth + growth_amount)
        
        save_data["stats"]["growth"] = new_growth
        
        return self.write_player_save(steam_id, save_data)
    
    def _get_save_file_path(self, steam_id: str) -> Optional[Path]:
        """Получает путь к файлу сохранения игрока"""
        if not self.server_saves_path:
            # Пытаемся найти автоматически
            possible_paths = [
                Path("C:/WindowsGSM/servers"),
                Path("C:/GameServers"),
                Path("D:/WindowsGSM/servers"),
                Path("D:/GameServers"),
                Path("./")  # Текущая директория для тестов
            ]
            
            for base_path in possible_paths:
                if base_path.exists():
                    save_file = base_path / f"{steam_id}.sav"
                    if save_file.exists():
                        return save_file
            
            return None
        
        return self.server_saves_path / f"{steam_id}.sav"
    
    def _extract_stats(self, payload: bytes) -> Dict[str, float]:
        """Извлекает статы из payload"""
        stats = {}
        
        # Ищем статы динамически, а не по жестко заданным оффсетам
        # Ищем значения 0.0-1.0 в последовательных блоках
        for i in range(0, len(payload) - 16, 4):
            try:
                # Читаем 4 последовательных float значения
                values = struct.unpack('<ffff', payload[i:i+16])
                
                # Проверяем, похожи ли они на статы динозавра
                if all(0.0 <= v <= 1.0 for v in values) and any(v > 0.0 for v in values):
                    # Нашли потенциальные статы
                    stat_names = ["health", "hunger", "thirst", "growth"]
                    for j, name in enumerate(stat_names):
                        if i + j*4 not in [offset for offset in self.stat_offsets.values()]:
                            self.stat_offsets[name] = i + j*4
                        stats[name] = values[j]
                    break
            except:
                continue
        
        # Если не нашли динамически, используем старый метод как резерв
        if not stats:
            for stat_name, offset in self.stat_offsets.items():
                if offset < len(payload) - 4:
                    try:
                        value = struct.unpack('<f', payload[offset:offset+4])[0]
                        # Проверяем, что значение в разумных пределах
                        if 0.0 <= value <= 1.0:
                            stats[stat_name] = value
                        else:
                            stats[stat_name] = 0.0
                    except:
                        stats[stat_name] = 0.0
                else:
                    stats[stat_name] = 0.0
        
        return stats
    
    def _extract_dinosaur_info(self, payload: bytes) -> Dict:
        """Извлекает информацию о динозавре"""
        # Поиск строки с классом динозавра
        species = "Unknown"
        
        # Ищем паттерны BP_*_C
        payload_str = payload.hex()
        for name, class_name in self.supported_species.items():
            class_hex = class_name.encode().hex()
            if class_hex in payload_str:
                species = class_name
                break
        
        return {
            "species": species,
            "position": (0.0, 0.0, 0.0),  # TODO: извлечь реальную позицию
            "rotation": (0.0, 0.0, 0.0)   # TODO: извлечь реальную ротацию
        }
    
    def _apply_stats_changes(self, payload: bytes, new_stats: Dict[str, float]) -> bytes:
        """Применяет изменения статов к payload"""
        payload_array = bytearray(payload)
        
        for stat_name, value in new_stats.items():
            if stat_name in self.stat_offsets:
                offset = self.stat_offsets[stat_name]
                if offset < len(payload_array) - 4:
                    # Записываем float значение
                    struct.pack_into('<f', payload_array, offset, float(value))
        
        return bytes(payload_array)
    
    def _apply_dinosaur_changes(self, payload: bytes, dino_changes: Dict) -> bytes:
        """Применяет изменения данных динозавра"""
        # TODO: Реализовать изменение вида динозавра и позиции
        # Пока возвращаем без изменений
        return payload
    
    def _calculate_header(self, payload: bytes) -> bytes:
        """Вычисляет заголовок (контрольную сумму) для payload"""
        # Используем CRC32 как основу для заголовка
        crc = zlib.crc32(payload) & 0xffffffff
        crc_bytes = struct.pack('<I', crc)
        
        # Добавляем timestamp
        import time
        timestamp = int(time.time())
        timestamp_bytes = struct.pack('<I', timestamp)
        
        # Создаем более реалистичный заголовок
        # Первые 4 байта - CRC32
        # Следующие 4 байта - timestamp
        # Остальные 8 байт - дополнительные данные (может быть версия, и т.д.)
        version_info = struct.pack('<I', 1)  # Версия формата
        reserved = struct.pack('<I', 0)      # Зарезервировано
        
        header = crc_bytes + timestamp_bytes + version_info + reserved
        return header

    def _create_backup(self, save_file: Path):
        """Создает резервную копию файла сохранения"""
        if save_file.exists():
            backup_file = save_file.with_suffix('.sav.bak')
            import shutil
            shutil.copy2(save_file, backup_file)
    
    def _create_new_save_data(self, steam_id: str, dino_data: DinosaurData) -> Dict:
        """Создает данные для нового файла сохранения"""
        # Базовый шаблон payload (упрощенный)
        # В реальности нужно создать правильную структуру UE4
        base_payload = b'\x00' * 4496  # Размер как у существующих файлов
        
        return {
            "steam_id": steam_id,
            "file_size": 4512,
            "header": "00000000000000000000000000000000",
            "stats": {
                "health": dino_data.stats.health,
                "hunger": dino_data.stats.hunger,
                "thirst": dino_data.stats.thirst,
                "growth": dino_data.stats.growth,
                "stamina": dino_data.stats.stamina
            },
            "dinosaur": {
                "species": dino_data.species,
                "position": dino_data.position,
                "rotation": dino_data.rotation
            },
            "raw_payload": base_payload
        }


# Интеграция с Discord ботом
class SaveManagerIntegration:
    """Интеграция менеджера сохранений с Discord ботом"""
    
    def __init__(self, save_manager: TheIsleSaveManager):
        self.save_manager = save_manager
    
    async def handle_heal_request(self, discord_id: int, full_heal: bool = False) -> Tuple[bool, str]:
        """Обработка запроса на лечение динозавра"""
        from database.crud import PlayerDinoCRUD
        
        try:
            # Получаем Steam ID игрока
            player = await PlayerDinoCRUD.get_player_info(discord_id)
            if not player or not player.get("player", {}).get("steam_id"):
                return False, "Игрок не найден или не привязан Steam аккаунт"
            
            steam_id = player["player"]["steam_id"]
            
            # Выполняем лечение
            success = self.save_manager.heal_dinosaur(steam_id, full_heal)
            
            if success:
                heal_type = "полное" if full_heal else "частичное"
                return True, f"Выполнено {heal_type} лечение динозавра"
            else:
                return False, "Не удалось вылечить динозавра (файл сохранения не найден)"
                
        except Exception as e:
            logger.error(f"Error in heal request: {e}")
            return False, f"Ошибка при лечении: {str(e)}"
    
    async def handle_growth_boost(self, discord_id: int, growth_amount: float = 0.1) -> Tuple[bool, str]:
        """Обработка запроса на увеличение роста"""
        from database.crud import PlayerDinoCRUD
        
        try:
            player = await PlayerDinoCRUD.get_player_info(discord_id)
            if not player or not player.get("player", {}).get("steam_id"):
                return False, "Игрок не найден или не привязан Steam аккаунт"
            
            steam_id = player["player"]["steam_id"]
            
            success = self.save_manager.boost_growth(steam_id, growth_amount)
            
            if success:
                return True, f"Рост динозавра увеличен на {growth_amount*100:.1f}%"
            else:
                return False, "Не удалось увеличить рост динозавра"
                
        except Exception as e:
            logger.error(f"Error in growth boost: {e}")
            return False, f"Ошибка при увеличении роста: {str(e)}"
    
    async def handle_dino_creation(self, discord_id: int, species: str, stats: DinosaurStats = None) -> Tuple[bool, str]:
        """Обработка создания нового динозавра"""
        from database.crud import PlayerDinoCRUD
        
        try:
            player = await PlayerDinoCRUD.get_player_info(discord_id)
            if not player or not player.get("player", {}).get("steam_id"):
                return False, "Игрок не найден или не привязан Steam аккаунт"
            
            steam_id = player["player"]["steam_id"]
            
            if stats is None:
                stats = DinosaurStats()
            
            dino_data = DinosaurData(species=species, stats=stats)
            success = self.save_manager.create_dinosaur(steam_id, dino_data)
            
            if success:
                return True, f"Создан новый динозавр: {species}"
            else:
                return False, "Не удалось создать динозавра"
                
        except Exception as e:
            logger.error(f"Error in dino creation: {e}")
            return False, f"Ошибка при создании динозавра: {str(e)}"


# Глобальные экземпляры
save_manager = TheIsleSaveManager()
save_integration = SaveManagerIntegration(save_manager)