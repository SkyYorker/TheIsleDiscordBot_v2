import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

import discord
from discord.ui import View, Button, Modal, Select
try:
    from discord.ui import InputText
except ImportError:
    from discord.ui import TextInput as InputText

from database.crud import BonusCodeCRUD, DonationCRUD, InventoryCRUD, ItemCRUD

logger = logging.getLogger(__name__)


async def safe_respond(interaction: discord.Interaction, /, *args, **kwargs):
    """Send a message to the interaction safely.

    If the interaction hasn't been responded to yet, use interaction.response.send_message,
    otherwise fall back to interaction.followup.send. Exceptions are logged.
    """
    try:
        if not interaction.response.is_done():
            await interaction.response.send_message(*args, **kwargs)
        else:
            await interaction.followup.send(*args, **kwargs)
    except Exception as e:
        logger.error(f"[safe_respond] Не удалось отправить ответ: {e}", exc_info=True)


class BonusCodeModal(Modal):
    def __init__(self):
        super().__init__(title="Ввод бонус-кода", custom_id="bonus_code_modal")
        
        self.code_input = InputText(
            label="Введите бонус-код",
            placeholder="Например: WELCOME2024",
            required=True,
            max_length=50
        )
        self.add_item(self.code_input)

    async def callback(self, interaction: discord.Interaction):
        # Получаем значение с fallback на self.children
        code_value = self.code_input.value
        if not code_value and self.children:
            code_value = self.children[0].value
        
        # Проверка на None/пустое значение
        if not code_value or (isinstance(code_value, str) and code_value.strip() == ""):
            embed = discord.Embed(
                title="❌ Ошибка",
                description="Пожалуйста, введите бонус-код.",
                color=discord.Color.red()
            )
            await safe_respond(interaction, embed=embed, ephemeral=True)
            return
        
        code = code_value.strip().upper()
        logger.debug(f"[BonusCodeModal] Получен код: {code}")
        
        success, message, reward_data = await BonusCodeCRUD.use_bonus_code(code, interaction.user.id)
        
        if success and reward_data:
            # Обрабатываем награду
            reward_type = reward_data['reward_type']
            reward_value = reward_data['reward_value']
            
            try:
                if reward_type == 'tk':
                    # Награда в ТС
                    tk_amount = int(reward_value)
                    await DonationCRUD.add_tk(interaction.user.id, tk_amount)
                    
                    embed = discord.Embed(
                        title="🎉 Бонус-код активирован!",
                        description=f"Вы получили **{tk_amount} ТС**!\n\n{reward_data['description']}",
                        color=discord.Color.gold()
                    )
                    
                elif reward_type == 'item':
                    # Награда - предмет
                    item_data = json.loads(reward_value)
                    item_id = item_data['item_id']
                    quantity = item_data.get('quantity', 1)
                    
                    await InventoryCRUD.add_item_to_inventory(interaction.user.id, item_id, quantity)
                    item_info = await ItemCRUD.get_item_by_id(item_id)
                    
                    embed = discord.Embed(
                        title="🎉 Бонус-код активирован!",
                        description=f"Вы получили **{quantity}x {item_info['name']}**!\n\n{reward_data['description']}",
                        color=discord.Color.gold()
                    )
                    
                elif reward_type == 'subscription':
                    # Награда - подписка (пока не реализовано)
                    embed = discord.Embed(
                        title="🎉 Бонус-код активирован!",
                        description=f"Награда: {reward_data['description']}\n\nОбратитесь к администратору для активации подписки.",
                        color=discord.Color.gold()
                    )
                    
                else:
                    embed = discord.Embed(
                        title="🎉 Бонус-код активирован!",
                        description=f"Награда: {reward_data['description']}",
                        color=discord.Color.gold()
                    )
                    
            except Exception as e:
                embed = discord.Embed(
                    title="❌ Ошибка обработки награды",
                    description=f"Код активирован, но произошла ошибка при выдаче награды: {str(e)}",
                    color=discord.Color.red()
                )
        else:
            embed = discord.Embed(
                title="❌ Ошибка активации",
                description=message,
                color=discord.Color.red()
            )
        
        await safe_respond(interaction, embed=embed, ephemeral=True)


class BonusCodeView(View):
    def __init__(self, main_menu_embed: discord.Embed, main_menu_view):
        super().__init__(timeout=None)
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        
        # Добавляем кнопки
        self.add_item(Button(
            label="Ввести код",
            style=discord.ButtonStyle.green,
            emoji="🎁",
            custom_id="enter_code",
            row=0
        ))
        
        self.add_item(Button(
            label="В главное меню",
            style=discord.ButtonStyle.grey,
            emoji="🏠",
            custom_id="back_to_menu",
            row=0
        ))

    @property
    def embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="🎁 Бонус-коды",
            description="""### Введите бонус-код для получения наград!

**Доступные типы наград:**
💰 **ТС** - игровая валюта
🎒 **Предметы** - для использования в игре
⭐ **Специальные награды** - уникальные бонусы

**Как использовать:**
1. Нажмите кнопку "Ввести код"
2. Введите ваш бонус-код
3. Получите награду!

*Каждый код можно использовать только один раз*""",
            color=discord.Color.purple()
        )
        
        embed.set_footer(text="Следите за новостями сервера для получения новых кодов!")
        return embed

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        if custom_id == "enter_code":
            logger.info(f"[BonusCodeView] Пользователь {interaction.user.id} нажал 'Ввести код'")
            modal = BonusCodeModal()
            try:
                await interaction.response.send_modal(modal)
                logger.info(f"[BonusCodeView] Модальное окно успешно отправлено")
            except Exception as e:
                logger.error(f"[BonusCodeView] Ошибка при отправке модального окна: {e}", exc_info=True)
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            
        elif custom_id == "back_to_menu":
            logger.info(f"[BonusCodeView] Пользователь {interaction.user.id} нажал 'В главное меню'")
            from views.main_menu import MainMenuView
            from utils.steam_api import steam_api
            
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = await MainMenuView.create_with_admin_check(steam_data, interaction.user.id, interaction)
            await view.update_player_data(interaction.user.id)
            await interaction.response.edit_message(embed=view.embed, view=view, content=None)
        
        return False


class AdminBonusCodeView(View):
    def __init__(self, main_menu_embed: discord.Embed, main_menu_view):
        super().__init__(timeout=None)
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        self.bonus_codes: List[Dict[str, Any]] = []
        self.current_page: int = 0
        self.codes_per_page: int = 25  # Discord ограничение на количество опций в Select

    async def load_bonus_codes(self, page: int = 0):
        self.bonus_codes = await BonusCodeCRUD.get_all_bonus_codes(active_only=False)
        max_pages = self.get_max_pages()
        self.current_page = max(0, min(page, max_pages - 1)) if max_pages > 0 else 0
        self.update_view()

    def get_max_pages(self) -> int:
        """Вычисляет максимальное количество страниц"""
        if not self.bonus_codes:
            return 1
        return max(1, (len(self.bonus_codes) + self.codes_per_page - 1) // self.codes_per_page)

    def get_current_page_codes(self) -> List[Dict[str, Any]]:
        """Получает коды для текущей страницы"""
        start_idx = self.current_page * self.codes_per_page
        end_idx = start_idx + self.codes_per_page
        return self.bonus_codes[start_idx:end_idx]

    def update_view(self):
        """Обновляет элементы интерфейса (Select меню и кнопки)"""
        self.clear_items()
        
        # Select меню для выбора кода (если есть коды)
        if self.bonus_codes:
            current_codes = self.get_current_page_codes()
            max_pages = self.get_max_pages()
            
            select = discord.ui.Select(
                placeholder=f"Выберите код для просмотра... (Страница {self.current_page + 1}/{max_pages})",
                min_values=1,
                max_values=1,
                options=[
                    discord.SelectOption(
                        label=f"{code['code']}",
                        value=str(code['id']),
                        description=f"{'✅' if code['is_active'] else '❌'} {code['current_uses']}/{code['max_uses']} | {code['description'][:50]}"
                    )
                    for code in current_codes
                ],
                custom_id="select_bonus_code"
            )
            select.callback = self.on_code_select
            self.add_item(select)
            
            # Кнопки навигации по страницам (если больше одной страницы)
            if max_pages > 1:
                nav_row = 1
                self.add_item(Button(
                    label="⬅️ Назад",
                    style=discord.ButtonStyle.secondary,
                    custom_id="prev_page",
                    row=nav_row,
                    disabled=self.current_page == 0
                ))
                self.add_item(Button(
                    label="➡️ Вперед",
                    style=discord.ButtonStyle.secondary,
                    custom_id="next_page",
                    row=nav_row,
                    disabled=self.current_page >= max_pages - 1
                ))
                self.add_item(Button(
                    label="🔍 Поиск кода",
                    style=discord.ButtonStyle.blurple,
                    custom_id="search_code",
                    row=nav_row
                ))
        
        # Кнопки управления
        control_row = 2 if self.get_max_pages() > 1 else 1
        self.add_item(Button(
            label="➕ Создать код",
            style=discord.ButtonStyle.green,
            custom_id="create_code_menu",
            row=control_row
        ))
        
        self.add_item(Button(
            label="🔄 Обновить список",
            style=discord.ButtonStyle.blurple,
            custom_id="refresh_codes",
            row=control_row
        ))
        
        self.add_item(Button(
            label="🏠 Главное меню",
            style=discord.ButtonStyle.grey,
            custom_id="back_to_menu",
            row=control_row + 1
        ))

    async def on_code_select(self, interaction: discord.Interaction):
        """Обработчик выбора кода из Select меню"""
        try:
            code_id = int(interaction.data['values'][0])
            selected_code = next((c for c in self.bonus_codes if c['id'] == code_id), None)
            
            if not selected_code:
                await interaction.response.send_message(
                    "❌ Код не найден.",
                    ephemeral=True
                )
                return
            
            # Создаем детальный embed для выбранного кода
            status = "✅ Активен" if selected_code['is_active'] else "❌ Неактивен"
            uses = f"{selected_code['current_uses']}/{selected_code['max_uses']}"
            expires = selected_code['expires_at'].strftime("%d.%m.%Y %H:%M") if selected_code['expires_at'] else "Без ограничений"
            created = selected_code['created_at'].strftime("%d.%m.%Y %H:%M") if selected_code.get('created_at') else "Неизвестно"
            
            embed = discord.Embed(
                title=f"📋 Информация о коде: `{selected_code['code']}`",
                color=discord.Color.green() if selected_code['is_active'] else discord.Color.red()
            )
            
            embed.add_field(name="Статус", value=status, inline=True)
            embed.add_field(name="Использований", value=uses, inline=True)
            embed.add_field(name="Истекает", value=expires, inline=True)
            embed.add_field(name="Описание", value=selected_code['description'], inline=False)
            embed.add_field(name="Тип награды", value=selected_code['reward_type'], inline=True)
            embed.add_field(name="Награда", value=selected_code['reward_value'], inline=True)
            embed.add_field(name="Создан", value=created, inline=True)
            
            embed.set_footer(text=f"ID: {selected_code['id']}")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"[AdminBonusCodeView] Ошибка при выборе кода: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Произошла ошибка: {str(e)}",
                ephemeral=True
            )

    @property
    def embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="🎁 Управление бонус-кодами",
            description="Используйте выпадающее меню ниже для выбора и просмотра кода",
            color=discord.Color.blue()
        )
        
        if self.bonus_codes:
            active_count = sum(1 for code in self.bonus_codes if code['is_active'])
            inactive_count = len(self.bonus_codes) - active_count
            total_uses = sum(code['current_uses'] for code in self.bonus_codes)
            max_pages = self.get_max_pages()
            
            embed.add_field(
                name="📊 Статистика",
                value=f"**Всего кодов:** {len(self.bonus_codes)}\n"
                      f"**✅ Активных:** {active_count}\n"
                      f"**❌ Неактивных:** {inactive_count}\n"
                      f"**📈 Всего использований:** {total_uses}",
                inline=False
            )
            
            if max_pages > 1:
                current_codes = self.get_current_page_codes()
                embed.add_field(
                    name="📄 Навигация",
                    value=f"**Страница:** {self.current_page + 1}/{max_pages}\n"
                          f"**Показано кодов:** {len(current_codes)}\n"
                          f"*Используйте кнопки ⬅️➡️ для навигации*",
                    inline=False
                )
        else:
            embed.add_field(
                name="Нет кодов",
                value="Создайте первый бонус-код, нажав кнопку ниже!",
                inline=False
            )
        
        return embed

    def _check_admin_permissions(self, interaction: discord.Interaction) -> bool:
        """Проверка прав администратора на сервере"""
        if not interaction.guild:
            return False
        
        try:
            user = interaction.user
            guild = interaction.guild
            
            # 1. Проверяем напрямую через interaction.user
            if isinstance(user, discord.Member):
                if hasattr(user, 'guild_permissions') and user.guild_permissions:
                    if user.guild_permissions.administrator:
                        return True
            
            # 2. Проверяем владельца сервера
            if hasattr(guild, 'owner_id') and guild.owner_id == user.id:
                return True
            
            # 3. Проверяем через get_member (может работать для кэшированных участников)
            try:
                member = guild.get_member(user.id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (AttributeError, TypeError):
                pass
                
        except Exception as e:
            logger.debug(f"Ошибка при проверке прав администратора: {e}")
        
            return False
        
    async def _check_admin_permissions_async(self, interaction: discord.Interaction) -> bool:
        """Асинхронная проверка прав администратора с fetch_member"""
        if not interaction.guild:
            return False
        
        try:
            user = interaction.user
            guild = interaction.guild
            
            # 1. Проверяем напрямую через interaction.user
            if isinstance(user, discord.Member):
                if hasattr(user, 'guild_permissions') and user.guild_permissions:
                    if user.guild_permissions.administrator:
                        return True
            
            # 2. Проверяем владельца сервера
            if hasattr(guild, 'owner_id') and guild.owner_id == user.id:
                return True
            
            # 3. Пытаемся получить участника через fetch_member (требует интент GUILD_MEMBERS)
            try:
                member = await guild.fetch_member(user.id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (discord.Forbidden, discord.HTTPException, AttributeError, TypeError):
                # Если нет прав или участник не найден, продолжаем
                pass
            
            # 4. Проверяем через get_member (кэшированные участники)
            try:
                member = guild.get_member(user.id)
                if member and hasattr(member, 'guild_permissions') and member.guild_permissions:
                    if member.guild_permissions.administrator:
                        return True
            except (AttributeError, TypeError):
                pass
                
        except Exception as e:
            logger.debug(f"Ошибка при асинхронной проверке прав администратора: {e}")
        
        return False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        
        # Разрешаем обработку выбора кода через callback
        if custom_id == "select_bonus_code":
            # Проверяем права админа (асинхронно для более надежной проверки)
            if not await self._check_admin_permissions_async(interaction):
                error_embed = discord.Embed(
                    title="❌ Доступ запрещен",
                    description="Только администраторы сервера могут просматривать бонус-коды.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return False
            # Разрешаем callback обработать выбор
            return True
        
        # Проверяем права админа для всех действий
        if custom_id in ["create_code_menu", "refresh_codes", "search_code"]:
            if not await self._check_admin_permissions_async(interaction):
                error_embed = discord.Embed(
                    title="❌ Доступ запрещен",
                    description="Только администраторы сервера могут управлять бонус-кодами.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
                return False
        
        if custom_id == "create_code_menu":
            # Показываем меню выбора типа награды (заменяем текущее сообщение)
            view = CreateCodeTypeSelectView(self)
            embed = discord.Embed(
                title="🎁 Создание бонус-кода",
                description="Выберите тип награды:",
                color=discord.Color.blurple()
            )
            await interaction.response.edit_message(embed=embed, view=view)
            
        elif custom_id == "refresh_codes":
            await self.load_bonus_codes(page=0)
            await interaction.response.edit_message(embed=self.embed, view=self)
            
        elif custom_id == "prev_page":
            if self.current_page > 0:
                await self.load_bonus_codes(page=self.current_page - 1)
                await interaction.response.edit_message(embed=self.embed, view=self)
            else:
                await interaction.response.defer()
            
        elif custom_id == "next_page":
            max_pages = self.get_max_pages()
            if self.current_page < max_pages - 1:
                await self.load_bonus_codes(page=self.current_page + 1)
                await interaction.response.edit_message(embed=self.embed, view=self)
            else:
                await interaction.response.defer()
            
        elif custom_id == "search_code":
            # Показываем модальное окно для поиска
            modal = SearchBonusCodeModal(self)
            await interaction.response.send_modal(modal)
            
        elif custom_id == "back_to_menu":
            from views.main_menu import MainMenuView
            from utils.steam_api import steam_api
            
            steam_data = await steam_api.get_steam_data(interaction.user.id)
            view = await MainMenuView.create_with_admin_check(steam_data, interaction.user.id, interaction)
            await view.update_player_data(interaction.user.id)
            await interaction.response.edit_message(embed=view.embed, view=view, content=None)
        
        return False


class CreateCodeTypeSelectView(View):
    """Меню выбора типа награды"""
    def __init__(self, admin_view=None):
        super().__init__(timeout=60)
        self.admin_view = admin_view  # Сохраняем ссылку на AdminBonusCodeView для возврата
        # Кнопки навигации добавляются через @discord.ui.button декораторы
    
    @discord.ui.button(
        label="💰 Награда ТС",
        style=discord.ButtonStyle.success,
        custom_id="create_tk_code",
        row=0
    )
    async def tk_button(self, interaction: discord.Interaction, button: Button):
        logger.info(f"[CreateCodeTypeSelectView] Пользователь {interaction.user.id} выбрал 'Награда ТС'")
        try:
            if not interaction.response.is_done():
                modal = CreateBonusCodeTkModal()
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateCodeTypeSelectView] Модальное окно успешно отправлено")
            else:
                logger.warning(f"[CreateCodeTypeSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateCodeTypeSelectView] Ошибка при отправке модального окна: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    
    @discord.ui.button(
        label="⬅️ Назад",
        style=discord.ButtonStyle.grey,
        custom_id="back_to_admin_codes",
        row=2
    )
    async def back_button(self, interaction: discord.Interaction, button: Button):
        """Кнопка возврата к списку кодов"""
        if self.admin_view:
            await self.admin_view.load_bonus_codes()
            await interaction.response.edit_message(embed=self.admin_view.embed, view=self.admin_view)
        else:
            # Если admin_view не передан, возвращаемся к списку кодов
            from views.bonus_code_view import AdminBonusCodeView
            empty_embed = discord.Embed(title="", description="")
            admin_view = AdminBonusCodeView(empty_embed, None)
            await admin_view.load_bonus_codes()
            await interaction.response.edit_message(embed=admin_view.embed, view=admin_view)
    
    @discord.ui.button(
        label="🏠 Главное меню",
        style=discord.ButtonStyle.blurple,
        custom_id="back_to_main_menu_from_create",
        row=2
    )
    async def main_menu_button(self, interaction: discord.Interaction, button: Button):
        """Кнопка возврата в главное меню"""
        from views.main_menu import MainMenuView
        from utils.steam_api import steam_api
        
        steam_data = await steam_api.get_steam_data(interaction.user.id)
        view = MainMenuView(steam_data, interaction.user.id, interaction)
        await view.update_player_data(interaction.user.id)
        await interaction.response.edit_message(embed=view.embed, view=view, content=None)
    
    @discord.ui.button(
        label="⭐ Награда подписка",
        style=discord.ButtonStyle.blurple,
        custom_id="create_subscription_code",
        row=0
    )
    async def subscription_button(self, interaction: discord.Interaction, button: Button):
        logger.info(f"[CreateCodeTypeSelectView] Пользователь {interaction.user.id} выбрал 'Награда подписка'")
        try:
            if not interaction.response.is_done():
                modal = CreateBonusCodeSubscriptionModal()
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateCodeTypeSelectView] Модальное окно подписки успешно отправлено")
            else:
                logger.warning(f"[CreateCodeTypeSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateCodeTypeSelectView] Ошибка при отправке модального окна подписки: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    @discord.ui.button(
        label="🍖 Пополнение нутриентов",
        style=discord.ButtonStyle.blurple,
        custom_id="create_nutrients_code",
        row=0
    )
    async def nutrients_button(self, interaction: discord.Interaction, button: Button):
        logger.info(f"[CreateCodeTypeSelectView] Пользователь {interaction.user.id} выбрал 'Пополнение нутриентов'")
        try:
            if not interaction.response.is_done():
                modal = CreateBonusCodeNutrientsModal()
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateCodeTypeSelectView] Модальное окно нутриентов успешно отправлено")
            else:
                logger.warning(f"[CreateCodeTypeSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateCodeTypeSelectView] Ошибка при отправке модального окна нутриентов: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    @discord.ui.button(
        label="💚 Пополнение статистик",
        style=discord.ButtonStyle.blurple,
        custom_id="create_stats_code",
        row=1
    )
    async def stats_button(self, interaction: discord.Interaction, button: Button):
        logger.info(f"[CreateCodeTypeSelectView] Пользователь {interaction.user.id} выбрал 'Пополнение статистик'")
        try:
            if not interaction.response.is_done():
                modal = CreateBonusCodeStatsModal()
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateCodeTypeSelectView] Модальное окно статистик успешно отправлено")
            else:
                logger.warning(f"[CreateCodeTypeSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateCodeTypeSelectView] Ошибка при отправке модального окна статистик: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    @discord.ui.button(
        label="📈 Гров на динозавра",
        style=discord.ButtonStyle.blurple,
        custom_id="create_growth_code",
        row=1
    )
    async def growth_button(self, interaction: discord.Interaction, button: Button):
        logger.info(f"[CreateCodeTypeSelectView] Пользователь {interaction.user.id} выбрал 'Гров на динозавра'")
        try:
            if not interaction.response.is_done():
                modal = CreateBonusCodeGrowthModal()
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateCodeTypeSelectView] Модальное окно грова успешно отправлено")
            else:
                logger.warning(f"[CreateCodeTypeSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateCodeTypeSelectView] Ошибка при отправке модального окна грова: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Не удалось открыть форму ввода кода. Ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)


class CreateBonusCodeTkModal(Modal):
    """Простая форма для кодов с ТС"""
    def __init__(self):
        super().__init__(title="Создать код (награда ТС)", custom_id="create_bonus_code_tk_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="WELCOME2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Приветственный бонус",
            required=True,
            max_length=200
        )
        self.amount = InputText(
            label="Количество ТС",
            placeholder="500",
            required=True,
            max_length=10
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.amount)
        self.add_item(self.max_uses)
    
    async def callback(self, interaction: discord.Interaction):
        logger.info(f"[CreateBonusCodeTkModal] ⚡ CALLBACK ВЫЗВАН для пользователя {interaction.user.id}")
        logger.info(f"[CreateBonusCodeTkModal] interaction.data: {interaction.data}")
        logger.info(f"[CreateBonusCodeTkModal] self.code: {self.code}, value: {getattr(self.code, 'value', 'NO VALUE')}")
        logger.info(f"[CreateBonusCodeTkModal] self.children: {self.children}")
        
        try:
            logger.info(f"[CreateBonusCodeTkModal] Начало обработки создания кода для пользователя {interaction.user.id}")
            
            # Получаем значения с fallback на self.children и interaction.data
            code_value = self.code.value
            description_value = self.description.value
            amount_value = self.amount.value
            max_uses_value = self.max_uses.value
            
            # Fallback через self.children если значения пустые
            if not code_value and len(self.children) > 0:
                code_value = self.children[0].value
                logger.debug(f"[CreateBonusCodeTkModal] Использован fallback через self.children[0].value для code: {code_value}")
            if not description_value and len(self.children) > 1:
                description_value = self.children[1].value
                logger.debug(f"[CreateBonusCodeTkModal] Использован fallback через self.children[1].value для description: {description_value}")
            if not amount_value and len(self.children) > 2:
                amount_value = self.children[2].value
                logger.debug(f"[CreateBonusCodeTkModal] Использован fallback через self.children[2].value для amount: {amount_value}")
            if not max_uses_value and len(self.children) > 3:
                max_uses_value = self.children[3].value
                logger.debug(f"[CreateBonusCodeTkModal] Использован fallback через self.children[3].value для max_uses: {max_uses_value}")
            
            # Fallback через interaction.data если значения все еще пустые
            if (not code_value or not description_value or not amount_value or not max_uses_value) and interaction.data.get('components'):
                try:
                    input_values = []
                    for component in interaction.data['components']:
                        if component.get('components'):
                            for sub_component in component['components']:
                                if sub_component.get('type') == 4:  # InputText type
                                    value = sub_component.get('value')
                                    if value:
                                        input_values.append(value)
                    
                    # Присваиваем значения по порядку
                    if input_values:
                        if not code_value and len(input_values) > 0:
                            code_value = input_values[0]
                            logger.debug(f"[CreateBonusCodeTkModal] Использовано значение из interaction.data для code: {code_value}")
                        if not description_value and len(input_values) > 1:
                            description_value = input_values[1]
                            logger.debug(f"[CreateBonusCodeTkModal] Использовано значение из interaction.data для description: {description_value}")
                        if not amount_value and len(input_values) > 2:
                            amount_value = input_values[2]
                            logger.debug(f"[CreateBonusCodeTkModal] Использовано значение из interaction.data для amount: {amount_value}")
                        if not max_uses_value and len(input_values) > 3:
                            max_uses_value = input_values[3]
                            logger.debug(f"[CreateBonusCodeTkModal] Использовано значение из interaction.data для max_uses: {max_uses_value}")
                except Exception as e:
                    logger.warning(f"[CreateBonusCodeTkModal] Ошибка при извлечении значений из interaction.data: {e}")
            
            # Проверка на None/пустые значения
            if not code_value or (isinstance(code_value, str) and code_value.strip() == ""):
                logger.warning(f"[CreateBonusCodeTkModal] Пустое значение code для пользователя {interaction.user.id}")
                await safe_respond(interaction, "❌ Пожалуйста, введите код.", ephemeral=True)
                return
            
            if not description_value or (isinstance(description_value, str) and description_value.strip() == ""):
                logger.warning(f"[CreateBonusCodeTkModal] Пустое значение description для пользователя {interaction.user.id}")
                await safe_respond(interaction, "❌ Пожалуйста, введите описание.", ephemeral=True)
                return
            
            if not amount_value or (isinstance(amount_value, str) and amount_value.strip() == ""):
                logger.warning(f"[CreateBonusCodeTkModal] Пустое значение amount для пользователя {interaction.user.id}")
                await safe_respond(interaction, "❌ Пожалуйста, введите количество ТС.", ephemeral=True)
                return
            
            if not max_uses_value or (isinstance(max_uses_value, str) and max_uses_value.strip() == ""):
                logger.warning(f"[CreateBonusCodeTkModal] Пустое значение max_uses для пользователя {interaction.user.id}")
                await safe_respond(interaction, "❌ Пожалуйста, введите максимальное количество использований.", ephemeral=True)
                return
            
            # Обрабатываем значения
            code = code_value.strip().upper() if isinstance(code_value, str) else str(code_value).strip().upper()
            description = description_value.strip() if isinstance(description_value, str) else str(description_value).strip()
            amount_str = amount_value.strip() if isinstance(amount_value, str) else str(amount_value).strip()
            max_uses_str = max_uses_value.strip() if isinstance(max_uses_value, str) else str(max_uses_value).strip()
            
            logger.debug(f"[CreateBonusCodeTkModal] Полученные значения: code={code}, desc={description}, amount={amount_str}, max_uses={max_uses_str}")
            
            # Валидация числовых значений
            try:
                amount = int(amount_str)
                if amount <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[CreateBonusCodeTkModal] Некорректное количество ТС: {amount_str} (ошибка: {e})")
                await safe_respond(interaction, "❌ Количество ТС должно быть положительным числом.", ephemeral=True)
                return
            
            try:
                max_uses = int(max_uses_str)
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError) as e:
                logger.warning(f"[CreateBonusCodeTkModal] Некорректное максимальное количество использований: {max_uses_str} (ошибка: {e})")
                await safe_respond(interaction, "❌ Макс использований должно быть положительным числом.", ephemeral=True)
                return
            
            logger.debug(f"[CreateBonusCodeTkModal] Создание кода: {code}, сумма: {amount}, макс: {max_uses}")
            
            # Создаем код
            logger.info(f"[CreateBonusCodeTkModal] Начинаю создание кода в БД...")
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code,
                description=description,
                reward_type='tk',
                reward_value=str(amount),
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            logger.info(f"[CreateBonusCodeTkModal] Код успешно создан в БД: {bonus_code}")
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code}`\n**Описание:** {description}\n**Награда:** {amount} ТС\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            logger.info(f"[CreateBonusCodeTkModal] Отправляю успешное сообщение пользователю {interaction.user.id}")
            await safe_respond(interaction, embed=embed, ephemeral=True)
            logger.info(f"[CreateBonusCodeTkModal] Код создан успешно: {code}")
            
        except Exception as e:
            logger.error(f"[CreateBonusCodeTkModal] Ошибка: {e}", exc_info=True)
            embed = discord.Embed(
                title="❌ Ошибка создания",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
            await safe_respond(interaction, embed=embed, ephemeral=True)


class CreateBonusCodeItemSelectView(View):
    """Select dropdown для выбора предмета"""
    def __init__(self, items: List[Dict], admin_view=None, type_select_view=None):
        super().__init__(timeout=300)
        self.items = items
        self.selected_item = None
        self.admin_view = admin_view  # Для возврата к списку кодов
        self.type_select_view = type_select_view  # Для возврата к выбору типа награды

        # Создаем Select dropdown
        select = discord.ui.Select(
            placeholder="Выберите предмет...",
            min_values=1,
            max_values=1,
            options=[
                discord.SelectOption(
                    label=f"{item['name']}",
                    value=str(item['id']),
                    description=item['description'][:100] if item['description'] else "Без описания"
                )
                for item in items[:25]
            ],
            custom_id="select_item_for_bonus"
        )

        select.callback = self.on_item_select
        self.add_item(select)
        
        # Кнопки навигации добавляются через @discord.ui.button декораторы

    async def on_item_select(self, interaction: discord.Interaction):
        try:
            item_id = int(interaction.data['values'][0])
            self.selected_item = next((i for i in self.items if i['id'] == item_id), None)

            if not self.selected_item:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "❌ Предмет не найден.",
                        ephemeral=True
                    )
                else:
                    await interaction.followup.send(
                        "❌ Предмет не найден.",
                        ephemeral=True
                    )
                return

            logger.info(f"[CreateBonusCodeItemSelectView] Пользователь {interaction.user.id} выбрал предмет: {self.selected_item['name']}")

            # Показываем форму для завершения
            if not interaction.response.is_done():
                modal = CreateBonusCodeItemModal(self.selected_item)
                await interaction.response.send_modal(modal)
                logger.info(f"[CreateBonusCodeItemSelectView] Модальное окно успешно отправлено")
            else:
                logger.warning(f"[CreateBonusCodeItemSelectView] Response уже использован")
                error_embed = discord.Embed(
                    title="❌ Ошибка",
                    description="Не удалось открыть форму. Попробуйте еще раз.",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=error_embed, ephemeral=True)
        except Exception as e:
            logger.error(f"[CreateBonusCodeItemSelectView] Ошибка: {e}", exc_info=True)
            error_embed = discord.Embed(
                title="❌ Ошибка",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=error_embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=error_embed, ephemeral=True)
    
    @discord.ui.button(
        label="⬅️ Назад",
        style=discord.ButtonStyle.grey,
        custom_id="back_to_type_select",
        row=1
    )
    async def back_button(self, interaction: discord.Interaction, button: Button):
        """Кнопка возврата к выбору типа награды"""
        if self.type_select_view:
            embed = discord.Embed(
                title="🎁 Создание бонус-кода",
                description="Выберите тип награды:",
                color=discord.Color.blurple()
            )
            await interaction.response.edit_message(embed=embed, view=self.type_select_view)
        else:
            # Если type_select_view не передан, создаем новый
            embed = discord.Embed(
                title="🎁 Создание бонус-кода",
                description="Выберите тип награды:",
                color=discord.Color.blurple()
            )
            view = CreateCodeTypeSelectView(self.admin_view)
            await interaction.response.edit_message(embed=embed, view=view)
    
    @discord.ui.button(
        label="🏠 Главное меню",
        style=discord.ButtonStyle.blurple,
        custom_id="back_to_main_menu_from_item_select",
        row=1
    )
    async def main_menu_button(self, interaction: discord.Interaction, button: Button):
        """Кнопка возврата в главное меню"""
        from views.main_menu import MainMenuView
        from utils.steam_api import steam_api
        
        steam_data = await steam_api.get_steam_data(interaction.user.id)
        view = MainMenuView(steam_data, interaction.user.id, interaction)
        await view.update_player_data(interaction.user.id)
        await interaction.response.edit_message(embed=view.embed, view=view, content=None)


class CreateBonusCodeItemModal(Modal):
    """Форма для кодов с предметами"""
    def __init__(self, item: Dict):
        # Включаем item_id в custom_id для извлечения в main.py
        super().__init__(title=f"Код с {item['name']}", custom_id=f"create_item_code_modal_{item['id']}")

        self.item = item

        self.code = InputText(
            label="Код",
            placeholder="SWORD2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Награда за активность",
            required=True,
            max_length=200
        )
        self.quantity = InputText(
            label="Количество предметов",
            placeholder="1",
            required=True,
            max_length=10
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )

        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.quantity)
        self.add_item(self.max_uses)

    async def callback(self, interaction: discord.Interaction):
        logger.info(f"[CreateBonusCodeItemModal] callback начат для пользователя {interaction.user.id}")
        try:
            logger.debug(f"[CreateBonusCodeItemModal] Получение значений из полей...")
            code = self.code.value.strip().upper()
            description = self.description.value.strip()
            quantity_str = self.quantity.value.strip()
            max_uses_str = self.max_uses.value.strip()
            logger.debug(f"[CreateBonusCodeItemModal] Полученные значения: code={code}, desc={description}, quantity={quantity_str}, max_uses={max_uses_str}")

            # Валидация
            if not code:
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите код.",
                    ephemeral=True
                )
                return

            if not description:
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите описание.",
                    ephemeral=True
                )
                return

            try:
                quantity = int(quantity_str)
                if quantity <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message(
                    "❌ Количество должно быть положительным числом.",
                    ephemeral=True
                )
                return

            try:
                max_uses = int(max_uses_str)
                if max_uses <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                await interaction.response.send_message(
                    "❌ Макс использований должно быть положительным числом.",
                    ephemeral=True
                )
                return

            logger.debug(f"[CreateBonusCodeItemModal] Создание кода: {code}, предмет: {self.item['name']}, кол-во: {quantity}, макс: {max_uses}")

            # Создаем JSON автоматически (без участия админа)
            reward_value = json.dumps({
                "item_id": self.item['id'],
                "quantity": quantity
            })
            logger.debug(f"[CreateBonusCodeItemModal] JSON создан: {reward_value}")

            # Создаем код
            logger.info(f"[CreateBonusCodeItemModal] Начинаю создание кода в БД...")
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code,
                description=description,
                reward_type='item',
                reward_value=reward_value,
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            logger.info(f"[CreateBonusCodeItemModal] Код успешно создан в БД: {bonus_code}")

            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code}`\n**Описание:** {description}\n**Награда:** {quantity}x {self.item['name']}\n**Максимум использований:** {max_uses}",
                color=discord.Color.green()
            )
            logger.info(f"[CreateBonusCodeItemModal] Отправляю успешное сообщение пользователю {interaction.user.id}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[CreateBonusCodeItemModal] Код создан успешно: {code}, награда: {quantity}x {self.item['name']}")

        except Exception as e:
            logger.error(f"[CreateBonusCodeItemModal] Ошибка: {e}", exc_info=True)
            embed = discord.Embed(
                title="❌ Ошибка создания",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)


class CreateBonusCodeSubscriptionModal(Modal):
    """Форма для кодов с подписками"""
    def __init__(self):
        super().__init__(title="Создать код (награда подписка)", custom_id="create_bonus_code_subscription_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="PREMIUM2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Премиум подписка на 30 дней",
            required=True,
            max_length=200
        )
        self.tier = InputText(
            label="Уровень подписки",
            placeholder="PLUS, PREMIUM, или SUPREME",
            required=True,
            max_length=20
        )
        self.duration = InputText(
            label="Длительность (дней)",
            placeholder="30",
            required=True,
            max_length=10
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.tier)
        self.add_item(self.duration)
        self.add_item(self.max_uses)


class CreateBonusCodeNutrientsModal(Modal):
    """Форма для кодов с нутриентами"""
    def __init__(self):
        super().__init__(title="Создать код (пополнение нутриентов)", custom_id="create_bonus_code_nutrients_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="NUTRIENTS2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Пополнение всех нутриентов",
            required=True,
            max_length=200
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.max_uses)


class CreateBonusCodeStatsModal(Modal):
    """Форма для кодов с пополнением статистик"""
    def __init__(self):
        super().__init__(title="Создать код (пополнение статистик)", custom_id="create_bonus_code_stats_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="STATS2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Пополнение здоровья, голода и жажды",
            required=True,
            max_length=200
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.max_uses)


class CreateBonusCodeGrowthModal(Modal):
    """Форма для кодов с гровом на динозавра"""
    def __init__(self):
        super().__init__(title="Создать код (гров на динозавра)", custom_id="create_bonus_code_growth_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="GROWTH2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Гров: рост 98%, голод 98%, жажда 98%",
            required=True,
            max_length=200
        )
        self.max_uses = InputText(
            label="Макс использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.max_uses)


class CreateBonusCodeModal(Modal):
    def __init__(self):
        super().__init__(title="Создание бонус-кода", custom_id="create_bonus_code_modal")
        
        self.code = InputText(
            label="Код",
            placeholder="WELCOME2024",
            required=True,
            max_length=50
        )
        self.description = InputText(
            label="Описание",
            placeholder="Приветственный бонус для новых игроков",
            required=True,
            max_length=200
        )
        self.reward_type = InputText(
            label="Тип награды",
            placeholder="tk, item, subscription",
            required=True,
            max_length=20
        )
        self.reward_value = InputText(
            label="Значение награды",
            placeholder='100 или {"item_id": 1, "quantity": 1}',
            required=True,
            max_length=500
        )
        self.max_uses = InputText(
            label="Максимум использований",
            placeholder="1",
            required=True,
            max_length=10
        )
        
        self.add_item(self.code)
        self.add_item(self.description)
        self.add_item(self.reward_type)
        self.add_item(self.reward_value)
        self.add_item(self.max_uses)

    async def callback(self, interaction: discord.Interaction):
        try:
            # Получаем значения с fallback на self.children
            code_value = self.code.value
            description_value = self.description.value
            reward_type_value = self.reward_type.value
            reward_value_value = self.reward_value.value
            max_uses_value = self.max_uses.value
            
            # Fallback через self.children если значения пустые
            if not code_value and len(self.children) > 0:
                code_value = self.children[0].value
            if not description_value and len(self.children) > 1:
                description_value = self.children[1].value
            if not reward_type_value and len(self.children) > 2:
                reward_type_value = self.children[2].value
            if not reward_value_value and len(self.children) > 3:
                reward_value_value = self.children[3].value
            if not max_uses_value and len(self.children) > 4:
                max_uses_value = self.children[4].value
            
            # Проверка на None/пустые значения
            if not code_value or (isinstance(code_value, str) and code_value.strip() == ""):
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите код бонус-кода.",
                    ephemeral=True
                )
                return
            
            if not description_value or (isinstance(description_value, str) and description_value.strip() == ""):
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите описание бонус-кода.",
                    ephemeral=True
                )
                return
            
            if not reward_type_value or (isinstance(reward_type_value, str) and reward_type_value.strip() == ""):
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите тип награды.",
                    ephemeral=True
                )
                return
            
            if not reward_value_value or (isinstance(reward_value_value, str) and reward_value_value.strip() == ""):
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите значение награды.",
                    ephemeral=True
                )
                return
            
            if not max_uses_value or (isinstance(max_uses_value, str) and max_uses_value.strip() == ""):
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите максимальное количество использований.",
                    ephemeral=True
                )
                return
            
            code = code_value.strip().upper()
            description = description_value.strip()
            reward_type = reward_type_value.strip().lower()
            reward_value = reward_value_value.strip()
            
            try:
                max_uses = int(max_uses_value.strip())
            except (ValueError, TypeError) as e:
                await interaction.response.send_message(
                    "❌ Неверное значение для максимального количества использований. Введите целое число.",
                    ephemeral=True
                )
                return
            
            logger.debug(f"[CreateBonusCodeModal] Получены значения: code={code}, description={description}, reward_type={reward_type}, reward_value={reward_value}, max_uses={max_uses}")
            
            # Валидация
            if reward_type not in ['tk', 'item', 'subscription']:
                await interaction.response.send_message(
                    "❌ Неверный тип награды. Используйте: tk, item, subscription",
                    ephemeral=True
                )
                return
            
            if reward_type == 'item':
                # Проверяем JSON для предметов
                try:
                    json.loads(reward_value)
                except json.JSONDecodeError:
                    await interaction.response.send_message(
                        "❌ Неверный формат JSON для предмета",
                        ephemeral=True
                    )
                    return
            
            # Создаем код
            bonus_code = await BonusCodeCRUD.create_bonus_code(
                code=code,
                description=description,
                reward_type=reward_type,
                reward_value=reward_value,
                max_uses=max_uses,
                created_by=interaction.user.id
            )
            
            embed = discord.Embed(
                title="✅ Бонус-код создан",
                description=f"**Код:** `{code}`\n**Описание:** {description}\n**Награда:** {reward_type} - {reward_value}\n**Использований:** {max_uses}",
                color=discord.Color.green()
            )
            
        except ValueError as e:
            embed = discord.Embed(
                title="❌ Ошибка валидации",
                description=str(e),
                color=discord.Color.red()
            )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка создания",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)


class SearchBonusCodeModal(Modal):
    """Модальное окно для поиска бонус-кода"""
    def __init__(self, admin_view: AdminBonusCodeView):
        super().__init__(title="Поиск бонус-кода", custom_id="search_bonus_code_modal")
        self.admin_view = admin_view
        
        self.search_input = InputText(
            label="Введите код или часть кода",
            placeholder="Например: WELCOME или 2024",
            required=True,
            max_length=50
        )
        self.add_item(self.search_input)
    
    async def callback(self, interaction: discord.Interaction):
        try:
            search_query = self.search_input.value.strip().upper()
            if not search_query:
                await interaction.response.send_message(
                    "❌ Пожалуйста, введите код для поиска.",
                    ephemeral=True
                )
                return
            
            # Ищем коды, содержащие запрос
            matching_codes = [
                code for code in self.admin_view.bonus_codes
                if search_query in code['code'].upper() or search_query in code['description'].upper()
            ]
            
            if not matching_codes:
                embed = discord.Embed(
                    title="🔍 Результаты поиска",
                    description=f"Коды, содержащие `{search_query}`, не найдены.",
                    color=discord.Color.orange()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Если найдено несколько кодов, показываем список
            if len(matching_codes) > 10:
                embed = discord.Embed(
                    title="🔍 Результаты поиска",
                    description=f"Найдено **{len(matching_codes)}** кодов, содержащих `{search_query}`.\n"
                              f"Показаны первые 10:",
                    color=discord.Color.blue()
                )
                for code in matching_codes[:10]:
                    status = "✅" if code['is_active'] else "❌"
                    embed.add_field(
                        name=f"{status} `{code['code']}`",
                        value=f"Использований: {code['current_uses']}/{code['max_uses']}\n"
                              f"Описание: {code['description'][:50]}...",
                        inline=False
                    )
            else:
                embed = discord.Embed(
                    title="🔍 Результаты поиска",
                    description=f"Найдено **{len(matching_codes)}** кодов:",
                    color=discord.Color.blue()
                )
                for code in matching_codes:
                    status = "✅" if code['is_active'] else "❌"
                    embed.add_field(
                        name=f"{status} `{code['code']}`",
                        value=f"Использований: {code['current_uses']}/{code['max_uses']}\n"
                              f"Описание: {code['description'][:50]}...",
                        inline=False
                    )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"[SearchBonusCodeModal] Ошибка при поиске: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Произошла ошибка при поиске: {str(e)}",
                ephemeral=True
            )
