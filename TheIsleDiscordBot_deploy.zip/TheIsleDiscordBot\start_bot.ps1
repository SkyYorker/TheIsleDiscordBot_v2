# Переходим в папку, где находится этот скрипт
Set-Location $PSScriptRoot
.\.venv\Scripts\activate.ps1
python main.py
Pause