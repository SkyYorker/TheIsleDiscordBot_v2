"""
Discord команды для управления заявками
Teleport, Set Growth, Give Item через систему заявок
"""

import discord
from discord.ext import commands
# Option будет доступен после патча в main.py
try:
    from discord.app_commands import Option
except ImportError:
    from discord.ext.commands import Option
from item_requests_system import request_system, create_teleport_request, create_growth_request, create_item_request
from database.crud import PlayerDinoCRUD

class AdminRequestsCog(commands.Cog):
    """Управление заявками на команды"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.slash_command(
        name="request_teleport",
        description="Создать заявку на телепорт игрока"
    )
    async def request_teleport(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        x: Option(float, "Координата X"),
        y: Option(float, "Координата Y"),
        z: Option(float, "Координата Z"),
        reason: Option(str, "Причина телепорта", required=False, default="")
    ):
        """Создает заявку на телепорт игрока"""
        
        try:
            await ctx.response.defer()
            
            # Получаем Steam ID или имя игрока
            player = await PlayerDinoCRUD.get_player_info(discord_user.id)
            if player and player.get("player", {}).get("steam_id"):
                target_player = player["player"]["steam_id"]
            else:
                target_player = discord_user.display_name
            
            # Создаем заявку
            success, message, request_id = await create_teleport_request(
                ctx.user.id, target_player, x, y, z, reason
            )
            
            if success:
                embed = discord.Embed(
                    title="🚀 Заявка на телепорт создана",
                    description=f"**Заявка #{request_id}**\n{message}",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="👤 Игрок",
                    value=f"{discord_user.mention}",
                    inline=True
                )
                embed.add_field(
                    name="📍 Координаты",
                    value=f"X: {x:.1f}\nY: {y:.1f}\nZ: {z:.1f}",
                    inline=True
                )
                if reason:
                    embed.add_field(
                        name="📝 Причина",
                        value=reason,
                        inline=False
                    )
                embed.set_footer(text="Админ рассмотрит заявку в ближайшее время")
            else:
                embed = discord.Embed(
                    title="❌ Ошибка создания заявки",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed)
            
        except Exception as e:
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )
    
    @commands.slash_command(
        name="request_growth",
        description="Создать заявку на установку роста динозавра"
    )
    async def request_growth(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        growth: Option(float, "Рост (0.0 = 0%, 1.0 = 100%)", min_value=0.0, max_value=1.0),
        reason: Option(str, "Причина изменения роста", required=False, default="")
    ):
        """Создает заявку на установку роста"""
        
        try:
            await ctx.response.defer()
            
            # Получаем Steam ID или имя игрока
            player = await PlayerDinoCRUD.get_player_info(discord_user.id)
            if player and player.get("player", {}).get("steam_id"):
                target_player = player["player"]["steam_id"]
            else:
                target_player = discord_user.display_name
            
            # Создаем заявку
            success, message, request_id = await create_growth_request(
                ctx.user.id, target_player, growth, reason
            )
            
            if success:
                embed = discord.Embed(
                    title="📈 Заявка на рост создана",
                    description=f"**Заявка #{request_id}**\n{message}",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="👤 Игрок",
                    value=f"{discord_user.mention}",
                    inline=True
                )
                embed.add_field(
                    name="📊 Рост",
                    value=f"{growth*100:.1f}%",
                    inline=True
                )
                if reason:
                    embed.add_field(
                        name="📝 Причина",
                        value=reason,
                        inline=False
                    )
                embed.set_footer(text="Админ рассмотрит заявку в ближайшее время")
            else:
                embed = discord.Embed(
                    title="❌ Ошибка создания заявки",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed)
            
        except Exception as e:
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )
    
    @commands.slash_command(
        name="request_item",
        description="Создать заявку на выдачу предмета"
    )
    async def request_item(
        self,
        ctx: discord.ApplicationContext,
        discord_user: Option(discord.Member, "Discord пользователь"),
        item_name: Option(str, "Название предмета"),
        quantity: Option(int, "Количество", min_value=1, max_value=100, default=1),
        reason: Option(str, "Причина выдачи предмета", required=False, default="")
    ):
        """Создает заявку на выдачу предмета"""
        
        try:
            await ctx.response.defer()
            
            # Получаем Steam ID или имя игрока
            player = await PlayerDinoCRUD.get_player_info(discord_user.id)
            if player and player.get("player", {}).get("steam_id"):
                target_player = player["player"]["steam_id"]
            else:
                target_player = discord_user.display_name
            
            # Создаем заявку
            success, message, request_id = await create_item_request(
                ctx.user.id, target_player, item_name, quantity, reason
            )
            
            if success:
                embed = discord.Embed(
                    title="🎁 Заявка на предмет создана",
                    description=f"**Заявка #{request_id}**\n{message}",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="👤 Игрок",
                    value=f"{discord_user.mention}",
                    inline=True
                )
                embed.add_field(
                    name="🎁 Предмет",
                    value=f"{item_name} x{quantity}",
                    inline=True
                )
                if reason:
                    embed.add_field(
                        name="📝 Причина",
                        value=reason,
                        inline=False
                    )
                embed.set_footer(text="Админ рассмотрит заявку в ближайшее время")
            else:
                embed = discord.Embed(
                    title="❌ Ошибка создания заявки",
                    description=message,
                    color=discord.Color.red()
                )
            
            await ctx.followup.send(embed=embed)
            
        except Exception as e:
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )
    
    @commands.slash_command(
        name="list_requests",
        description="Показать список ожидающих заявок"
    )
    @commands.has_permissions(administrator=True)
    async def list_requests(self, ctx: discord.ApplicationContext):
        """Показывает список ожидающих заявок для админов"""
        
        try:
            await ctx.response.defer()
            
            requests = await request_system.get_pending_requests()
            
            if not requests:
                embed = discord.Embed(
                    title="📋 Список заявок",
                    description="Нет ожидающих заявок",
                    color=discord.Color.blue()
                )
            else:
                embed = discord.Embed(
                    title="📋 Список заявок",
                    description=f"Найдено {len(requests)} ожидающих заявок",
                    color=discord.Color.blue()
                )
                
                for req in requests[:10]:  # Показываем первые 10
                    field_name = f"#{req['id']} - {req['request_type'].upper()}"
                    field_value = f"**Игрок:** {req['target_player']}\n"
                    field_value += f"**Параметры:** {req['parameters']}\n"
                    field_value += f"**Создано:** {req['created_at'].strftime('%d.%m.%Y %H:%M')}"
                    
                    if req['reason']:
                        field_value += f"\n**Причина:** {req['reason']}"
                    
                    embed.add_field(
                        name=field_name,
                        value=field_value,
                        inline=False
                    )
                
                if len(requests) > 10:
                    embed.set_footer(text=f"И еще {len(requests) - 10} заявок...")
            
            await ctx.followup.send(embed=embed)
            
        except Exception as e:
            await ctx.followup.send(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )

def setup(bot):
    bot.add_cog(AdminRequestsCog(bot))
