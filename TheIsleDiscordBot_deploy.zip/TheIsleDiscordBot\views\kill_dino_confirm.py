import logging

import discord
from discord.ui import View, Button

from data.dinosaurus import find_name_by_class, DINOSAURS
from utils.rcon_isle import PlayerData
from utils.steam_api import steam_api

logger = logging.getLogger(__name__)


class KillDinoConfirmView(View):
    def __init__(self, dino_data: PlayerData, main_menu_embed: discord.Embed, main_menu_view: View,
                 on_confirm_callback):
        super().__init__(timeout=None)
        self.dino_data = dino_data
        self.main_menu_embed = main_menu_embed
        self.main_menu_view = main_menu_view
        self.on_confirm_callback = on_confirm_callback

        self.add_item(Button(
            label="Подтвердить убийство",
            style=discord.ButtonStyle.red,
            emoji="💀",
            custom_id="confirm_kill",
            row=0
        ))
        self.add_item(Button(
            label="Главное меню",
            style=discord.ButtonStyle.green,
            emoji="🏠",
            custom_id="back_to_main_menu",
            row=0
        ))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        custom_id = interaction.data.get("custom_id")
        if custom_id == "confirm_kill":
            await self.on_confirm_callback(interaction, self.dino_data)
        elif custom_id == "back_to_main_menu":
            # Откладываем ответ, так как следующие операции могут занять время
            await interaction.response.defer()
            
            try:
                steam_data = await steam_api.get_steam_data(interaction.user.id)
                from views.main_menu import MainMenuView
                view = MainMenuView(steam_data, interaction.user.id)
                await view.update_player_data(interaction.user.id)
                # Используем followup.edit_message после defer()
                await interaction.followup.edit_message(interaction.message.id, embed=view.embed, view=view, content=None)
            except Exception as e:
                # Если сообщение уже удалено или истекло, пытаемся отправить новое
                logger.error(f"Ошибка при возврате в главное меню: {e}", exc_info=True)
                try:
                    error_embed = discord.Embed(
                        title="⚠️ Ошибка",
                        description="Не удалось вернуться в главное меню. Попробуйте открыть главное меню через команду.",
                        color=discord.Color.orange()
                    )
                    await interaction.followup.send(embed=error_embed, ephemeral=True)
                except:
                    pass
        return False


def kill_dino_confirm_embed(dino_data: PlayerData) -> discord.Embed:
    dino_name = find_name_by_class(dino_data.dino_class)
    dino_image = DINOSAURS.get(dino_name, {}).get("image")
    embed = discord.Embed(
        title="Подтверждение убийства динозавра",
        description=f"Вы действительно хотите убить текущего динозавра?\n\n"
                    f"**Вид:** {dino_name}\n"
                    f"**Рост:** {dino_data.growth}%\n"
                    f"**Голод:** {dino_data.hunger}%\n"
                    f"**Жажда:** {dino_data.thirst}%",
        color=discord.Color.red()
    )
    embed.set_image(url=dino_image)
    embed.set_footer(text="Это действие необратимо!")
    return embed
