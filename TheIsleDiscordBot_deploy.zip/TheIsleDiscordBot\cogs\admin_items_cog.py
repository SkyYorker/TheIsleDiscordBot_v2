import json
from typing import Optional

import discord
# Option будет доступен после патча в main.py
try:
    from discord.app_commands import Option
except ImportError:
    from discord.ext.commands import Option
from discord.ext import commands

from database.crud import ItemCRUD, InventoryCRUD, ItemType


class AdminItemsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(
        name="create_item",
        description="Создать новый предмет в магазине"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def create_item(
        self,
        ctx: discord.ApplicationContext,
        name: Option(str, "Название предмета"),
        description: Option(str, "Описание предмета"),
        item_type: Option(str, "Тип предмета", choices=["dinosaur", "nutrients", "food_water", "currency", "special"]),
        price: Option(int, "Цена в ТС", min_value=0),
        max_stack: Option(int, "Максимальный стек", min_value=1, default=1),
        game_data: Option(str, "JSON данные для игры (опционально)", required=False)
    ):
        try:
            # Валидация JSON если предоставлен
            if game_data:
                try:
                    json.loads(game_data)
                except json.JSONDecodeError:
                    await ctx.respond("❌ Неверный формат JSON в game_data", ephemeral=True)
                    return
            
            # Создаем предмет
            item = await ItemCRUD.create_item(
                name=name,
                description=description,
                item_type=ItemType(item_type),
                price=price,
                max_stack=max_stack,
                game_data=game_data
            )
            
            embed = discord.Embed(
                title="✅ Предмет создан",
                description=f"**Название:** {item['name']}\n**Тип:** {item['item_type']}\n**Цена:** {item['price']} ТС\n**Макс. стек:** {item['max_stack']}",
                color=discord.Color.green()
            )
            if game_data:
                embed.add_field(name="Игровые данные", value=f"```json\n{game_data}\n```", inline=False)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка создания предмета",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="list_items",
        description="Показать все предметы в магазине"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def list_items(self, ctx: discord.ApplicationContext):
        try:
            items = await ItemCRUD.get_all_items(active_only=False)
            
            if not items:
                await ctx.respond("❌ Предметы не найдены", ephemeral=True)
                return
            
            embed = discord.Embed(
                title="📦 Все предметы в магазине",
                description=f"Всего предметов: **{len(items)}**",
                color=discord.Color.blue()
            )
            
            # Группируем по типам
            items_by_type = {}
            for item in items:
                item_type = item['item_type']
                if item_type not in items_by_type:
                    items_by_type[item_type] = []
                items_by_type[item_type].append(item)
            
            for item_type, type_items in items_by_type.items():
                type_emoji = {
                    'dinosaur': '🦖',
                    'nutrients': '💊',
                    'food_water': '🍖',
                    'currency': '💰',
                    'special': '⭐'
                }.get(item_type, '📦')
                
                items_text = "\n".join([
                    f"• **{item['name']}** - {item['price']} ТС (ID: {item['id']})"
                    for item in type_items[:10]  # Показываем первые 10
                ])
                if len(type_items) > 10:
                    items_text += f"\n• ... и еще {len(type_items) - 10} предметов"
                
                embed.add_field(
                    name=f"{type_emoji} {item_type.title()} ({len(type_items)})",
                    value=items_text,
                    inline=False
                )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка получения предметов",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="give_item",
        description="Выдать предмет игроку"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def give_item(
        self,
        ctx: discord.ApplicationContext,
        user: Option(discord.Member, "Пользователь"),
        item_id: Option(int, "ID предмета"),
        quantity: Option(int, "Количество", min_value=1, default=1)
    ):
        try:
            # Проверяем существование предмета
            item = await ItemCRUD.get_item_by_id(item_id)
            if not item:
                await ctx.respond(f"❌ Предмет с ID {item_id} не найден", ephemeral=True)
                return
            
            if not item['is_active']:
                await ctx.respond(f"❌ Предмет '{item['name']}' неактивен", ephemeral=True)
                return
            
            # Выдаем предмет
            inventory_item = await InventoryCRUD.add_item_to_inventory(
                user.id, item_id, quantity
            )
            
            embed = discord.Embed(
                title="✅ Предмет выдан",
                description=f"Выдано **{quantity}x {item['name']}** пользователю {user.mention}",
                color=discord.Color.green()
            )
            embed.add_field(name="ID в инвентаре", value=str(inventory_item['inventory_id']), inline=True)
            embed.add_field(name="Количество", value=str(quantity), inline=True)
            
        except ValueError as e:
            embed = discord.Embed(
                title="❌ Ошибка выдачи предмета",
                description=str(e),
                color=discord.Color.red()
            )
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка выдачи предмета",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="update_item",
        description="Обновить предмет"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def update_item(
        self,
        ctx: discord.ApplicationContext,
        item_id: Option(int, "ID предмета"),
        name: Option(str, "Новое название (опционально)", required=False),
        description: Option(str, "Новое описание (опционально)", required=False),
        price: Option(int, "Новая цена (опционально)", min_value=0, required=False),
        is_active: Option(bool, "Активен ли предмет (опционально)", required=False)
    ):
        try:
            updates = {}
            if name is not None:
                updates['name'] = name
            if description is not None:
                updates['description'] = description
            if price is not None:
                updates['price'] = price
            if is_active is not None:
                updates['is_active'] = is_active
            
            if not updates:
                await ctx.respond("❌ Не указано ни одного поля для обновления", ephemeral=True)
                return
            
            updated_item = await ItemCRUD.update_item(item_id, updates)
            if not updated_item:
                await ctx.respond(f"❌ Предмет с ID {item_id} не найден", ephemeral=True)
                return
            
            embed = discord.Embed(
                title="✅ Предмет обновлен",
                description=f"**ID:** {updated_item['id']}\n**Название:** {updated_item['name']}\n**Цена:** {updated_item['price']} ТС\n**Активен:** {'Да' if updated_item['is_active'] else 'Нет'}",
                color=discord.Color.green()
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка обновления предмета",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)

    @commands.slash_command(
        name="delete_item",
        description="Удалить предмет"
    )
    @commands.has_permissions(administrator=True)
    @commands.guild_only()
    async def delete_item(
        self,
        ctx: discord.ApplicationContext,
        item_id: Option(int, "ID предмета")
    ):
        try:
            success = await ItemCRUD.delete_item(item_id)
            if success:
                embed = discord.Embed(
                    title="✅ Предмет удален",
                    description=f"Предмет с ID {item_id} успешно удален",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="❌ Ошибка удаления",
                    description=f"Предмет с ID {item_id} не найден",
                    color=discord.Color.red()
                )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Ошибка удаления предмета",
                description=f"Произошла ошибка: {str(e)}",
                color=discord.Color.red()
            )
        
        await ctx.respond(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(AdminItemsCog(bot))
